﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH
{
    public partial class bearbeitenarbeitskartekopf : Form
    {
        OleDbCommand cmd = null;


        private readonly string connectionString;
        private readonly OleDbConnection con = new OleDbConnection();
        private DataGridViewRow selectedRow;
        public DataGridViewRow UpdatedRow { get; private set; }
        public bearbeitenarbeitskartekopf(DataGridViewRow selectedRow, string connectionString)
        {
            InitializeComponent();
            this.selectedRow = selectedRow;
            this.connectionString = connectionString;
        }

        private void bearbeitenarbeitskartekopf_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = connectionString;
                con.Open();

                // Hier rufe ich eine Methode auf, um die Daten in den Textboxen anzuzeigen
                AnzeigenDerDaten();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler: " + ex.Message);
            }
        }
        private void AnzeigenDerDaten()
        {
            try
            {


                
                tbx_pid.Text = selectedRow.Cells["P_id"].Value.ToString();
                tbx_prob.Text = selectedRow.Cells["Prob_id"].Value.ToString();
                tbx_fertdat.Text = selectedRow.Cells["P_fertigstellung_dat"].Value.ToString();
                tbx_fertzeitid.Text = selectedRow.Cells["P_fertigstellung_zeit_id"].Value.ToString();
                tbx_abnahme_dat.Text = selectedRow.Cells["P_abnahme_dat"].Value.ToString();
                tbx_chargeid.Text = selectedRow.Cells["P_charge_id"].Value.ToString();
                tbx_bemerkung.Text = selectedRow.Cells["P_bemerkung"].Value.ToString();
                tbx_sonstige1.Text = selectedRow.Cells["P_sonstige1"].Value.ToString();
                tbx_sonstige2.Text = selectedRow.Cells["P_sonstige2"].Value.ToString();
                tbx_sonstige3.Text = selectedRow.Cells["P_sonstige3"].Value.ToString();
                tbx_anzahl.Text = selectedRow.Cells["P_anzahl"].Value.ToString();
                tbx_eingang.Text = selectedRow.Cells["P_eingang"].Value.ToString();
                tbx_abgeschlossen.Text = selectedRow.Cells["P_abgeschlossen"].Value.ToString();
                tbx_abnahme_id.Text = selectedRow.Cells["Abnahme_id"].Value.ToString();
               
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler beim Anzeigen der Daten: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate that all fields are filled
                if (string.IsNullOrWhiteSpace(tbx_prob.Text) || string.IsNullOrWhiteSpace(tbx_eingang.Text) || string.IsNullOrWhiteSpace(tbx_fertdat.Text) || string.IsNullOrWhiteSpace(tbx_fertzeitid.Text) ||
                    string.IsNullOrWhiteSpace(tbx_abnahme_dat.Text) || string.IsNullOrWhiteSpace(tbx_chargeid.Text) || string.IsNullOrWhiteSpace(tbx_bemerkung.Text) || string.IsNullOrWhiteSpace(tbx_sonstige1.Text) ||
                    string.IsNullOrWhiteSpace(tbx_sonstige2.Text) || string.IsNullOrWhiteSpace(tbx_sonstige3.Text) || string.IsNullOrWhiteSpace(tbx_anzahl.Text) || string.IsNullOrWhiteSpace(tbx_abgeschlossen.Text) ||
                    string.IsNullOrWhiteSpace(tbx_abnahme_id.Text))
                {
                    MessageBox.Show("Bitte füllen Sie alle Felder aus.");
                    return; //schließt die methode damit keine weiter fehlermeldung hintereinander kommt
                }

                // nummerische zahlen überprüfen
                int probId, fertzeitId, chargeId, anzahl, abnahmeId , Pid;

                if (!int.TryParse(tbx_prob.Text, out probId))
                {
                    MessageBox.Show("Bitte geben Sie eine gültige Zahl für Prob_id ein.");
                    return;
                }

                if (!int.TryParse(tbx_fertzeitid.Text, out fertzeitId))
                {
                    MessageBox.Show("Bitte geben Sie eine gültige Zahl für P_fertigstellung_zeit_id ein.");
                    return;
                }

                if (!int.TryParse(tbx_chargeid.Text, out chargeId))
                {
                    MessageBox.Show("Bitte geben Sie eine gültige Zahl für P_charge_id ein.");
                    return;
                }

                if (!int.TryParse(tbx_anzahl.Text, out anzahl))
                {
                    MessageBox.Show("Bitte geben Sie eine gültige Zahl für P_anzahl ein.");
                    return;
                }

                if (!int.TryParse(tbx_abnahme_id.Text, out abnahmeId))
                {
                    MessageBox.Show("Bitte geben Sie eine gültige Zahl für Abnahme_id ein.");
                    return;
                }
                if (!int.TryParse(tbx_pid.Text, out Pid))
                {
                    MessageBox.Show("Bitte geben Sie eine gültige Zahl für P_id_id ein.");
                    return;
                }

                
                cmd = new OleDbCommand("UPDATE Probe_kopf SET Prob_id=?, P_eingang=?, P_fertigstellung_dat=?, P_fertigstellung_zeit_id=?, P_abnahme_dat=?, P_charge_id=?, P_bemerkung=?, P_sonstige1=?, P_sonstige2=?, P_sonstige3=?, P_anzahl=?, P_abgeschlossen=?, Abnahme_id=? WHERE P_id=?", con);

                // Füge die Parameter hinzu
                cmd.Parameters.AddWithValue("@Prob_id", probId);
                cmd.Parameters.AddWithValue("@P_eingang", tbx_eingang.Text);
                cmd.Parameters.AddWithValue("@P_fertigstellung_dat", tbx_fertdat.Text);
                cmd.Parameters.AddWithValue("@P_fertigstellung_zeit_id", fertzeitId);
                cmd.Parameters.AddWithValue("@P_abnahme_dat", tbx_abnahme_dat.Text);
                cmd.Parameters.AddWithValue("@P_charge_id", chargeId);
                cmd.Parameters.AddWithValue("@P_bemerkung", tbx_bemerkung.Text);
                cmd.Parameters.AddWithValue("@P_sonstige1", tbx_sonstige1.Text);
                cmd.Parameters.AddWithValue("@P_sonstige2", tbx_sonstige2.Text);
                cmd.Parameters.AddWithValue("@P_sonstige3", tbx_sonstige3.Text);
                cmd.Parameters.AddWithValue("@P_anzahl", anzahl);
                cmd.Parameters.AddWithValue("@P_abgeschlossen", tbx_abgeschlossen.Text);
                cmd.Parameters.AddWithValue("@Abnahme_id", abnahmeId);
                cmd.Parameters.AddWithValue("@P_id", Pid);

                // Führe das Update-Statement aus
                cmd.ExecuteNonQuery();

                MessageBox.Show("Erfolgreich bearbeitet!");

                // Setze UpdatedRow auf die aktualisierte Zeile
                UpdatedRow = selectedRow;

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler beim Bearbeiten: " + a.Message);
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
