﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class Auftragbearbeiten : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Kunze.accdb;";
        public Auftragbearbeiten() {
            InitializeComponent();
        }

        private void Auftragbearbeiten_Load(object sender, EventArgs e) {
            LoadData();
        }
        private void LoadData() {
            using (OleDbConnection connection = new OleDbConnection(connectionString)) {
                connection.Open();

                string query = "select Auf_id, Auf_angenommen, Auf_liefertermin, K_id, Status_id, W_id, N_id, Aus_bestell_id, Auf_prüflos, Anspr_id, Prob_id, Auf_menge  from Auftrag"; 
                using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection)) {
                    dataSet = new DataSet();
                    adapter.Fill(dataSet, "Auftrag");
                    dgbearbeiten.DataSource = dataSet.Tables["Auftrag"];
                }
            }
            dgbearbeiten.Columns["Auf_id"].HeaderText = "Nummer";
            dgbearbeiten.Columns["Auf_angenommen"].HeaderText = "Angenommen";
            dgbearbeiten.Columns["Auf_liefertermin"].HeaderText = "Liefertermin";
            dgbearbeiten.Columns["K_id"].HeaderText = "Kundennummer";
            dgbearbeiten.Columns["Status_id"].HeaderText = "Statusnummer";
            dgbearbeiten.Columns["W_id"].HeaderText = "Werkstoffnummer";
            dgbearbeiten.Columns["N_id"].HeaderText = "Normnummer";
            dgbearbeiten.Columns["Aus_bestell_id"].HeaderText = "Auftrag_bestellnummer";
            dgbearbeiten.Columns["Auf_prüflos"].HeaderText = "Prüflos";
            dgbearbeiten.Columns["Anspr_id"].HeaderText = "Ansprechspartner";
            dgbearbeiten.Columns["Prob_id"].HeaderText = "Probnummer";
            dgbearbeiten.Columns["Auf_menge"].HeaderText = "Menge";
            dgbearbeiten.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
        }

        private void dgbearbeiten_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            if (e.RowIndex >= 0) {
                // Hier bekommst du den ausgewählten Mitarbeiter
                DataGridViewRow selectedRow = dgbearbeiten.Rows[e.RowIndex];

             
                Bearbeitenauftrag bearbeitenForm = new Bearbeitenauftrag(selectedRow, connectionString);
                DialogResult result = bearbeitenForm.ShowDialog();

                // Wenn die Bearbeitung abgeschlossen ist, lade die aktualisierten Daten
                if (result == DialogResult.OK) {
                    LoadData();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
