﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class Werkstoffhinzufügen : Form {
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Kunze.accdb;";
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;
        public Werkstoffhinzufügen() {
            InitializeComponent();
        }

        private void Werkstoffhinzufügen_Load(object sender, EventArgs e) {
            LoadData();
        }
        public void RefreshData() {
            LoadData();
        }
        private void LoadData() {
            using (OleDbConnection connection = new OleDbConnection(connectionString)) {
                connection.Open();
                string query = "SELECT W_id, W_name, W_kurz, W_kennzeichen, W_oberfläche, W_höhe, W_breite, W_länge, W_gewicht FROM Werkstoff";

                using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection)) {
                    dataSet = new DataSet();
                    adapter.Fill(dataSet, "Werkstoff");
                    dghinzufügen.DataSource = dataSet.Tables["Werkstoff"];
                }
            }
            dghinzufügen.Columns["W_id"].HeaderText = "Nummer";
            dghinzufügen.Columns["W_name"].HeaderText = "Name";
            dghinzufügen.Columns["W_kurz"].HeaderText = "Kurz";
            dghinzufügen.Columns["W_kennzeichen"].HeaderText = "Kennzeichen";
            dghinzufügen.Columns["W_oberfläche"].HeaderText = "Oberfläche";
            dghinzufügen.Columns["W_höhe"].HeaderText = "Höhe";
            dghinzufügen.Columns["W_breite"].HeaderText = "Breite";
            dghinzufügen.Columns["W_länge"].HeaderText = "Länge";
            dghinzufügen.Columns["W_gewicht"].HeaderText = "Gewicht";
            dghinzufügen.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
        }

        private void dghinzufügen_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            if (e.RowIndex >= 0) {
                // Hier bekommst du den ausgewählten Mitarbeiter
                DataGridViewRow selectedRow = dghinzufügen.Rows[e.RowIndex];

                //Öffne ein Formular zum Bearbeiten mit den Daten der ausgewählten Zeile
                hinzufügenwerkstoff bearbeitenForm = new hinzufügenwerkstoff(selectedRow);
                DialogResult result = bearbeitenForm.ShowDialog();

                // Wenn die Bearbeitung abgeschlossen ist, lade die aktualisierten Daten
                if (result == DialogResult.OK) {
                    LoadData();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
