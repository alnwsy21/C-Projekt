﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH
{

    public partial class hinzufügenangebot : Form
    {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;
        private mitarbeiteradd mainForm;
        private DataGridViewRow selectedRow;
        public hinzufügenangebot()
        {
            InitializeComponent();
            this.mainForm = mainForm;
        }

        public hinzufügenangebot(DataGridViewRow selectedRow) : this()
        {
            this.selectedRow = selectedRow;
 
        }
        private void hinzufügenangebot_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";

                con.Open();
            }
            catch (Exception a)
            {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Überprüfe, ob alle Textboxen ausgefüllt sind
                if (string.IsNullOrWhiteSpace(tbx_ang_id.Text) || string.IsNullOrWhiteSpace(tbx_pe_typ_id.Text) || string.IsNullOrWhiteSpace(tbx_preis.Text) || string.IsNullOrWhiteSpace(tbx_menge.Text) || string.IsNullOrWhiteSpace(tbx_kommentar.Text))
                {
                    // Zeige eine Meldung an, dass alle Felder ausgefüllt werden müssen
                    MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    // Führe die Datenbankoperation nur aus, wenn alle Felder ausgefüllt sind

                    // Überprüfe, ob die Kunden-ID bereits existiert
                    using (OleDbCommand checkCmd = new OleDbCommand("SELECT COUNT(*) FROM Angebotposition WHERE Ang_id = @Ang_id", con))
                    {
                        checkCmd.Parameters.AddWithValue("@Ang_id", Convert.ToInt32(tbx_ang_id.Text));

                        int existingRecords = (int)checkCmd.ExecuteScalar();

                        if (existingRecords > 0)
                        {
                            // Die Kunden-ID existiert bereits, zeige eine entsprechende Meldung an
                            MessageBox.Show("Die Ang_id existiert bereits. Bitte wählen Sie eine andere ID.", "Duplikate verhindern", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                        else
                        {
                            // Füge den neuen Datensatz ein
                            using (OleDbCommand insertCmd = new OleDbCommand("INSERT INTO Angebotposition(Ang_id, Pe_typ_id, Rp_preis, Menge, Kommentar) VALUES (@ANg_id, @Pe_typ_id, @Rp_preis, @Menge, @Kommentar)", con))
                            {
                                insertCmd.Parameters.AddWithValue("@Ang_id", Convert.ToInt32(tbx_ang_id.Text));
                                insertCmd.Parameters.AddWithValue("@Pe_typ_id", Convert.ToInt32(tbx_pe_typ_id.Text));
                                insertCmd.Parameters.AddWithValue("@Rp_preis", Convert.ToInt32(tbx_preis.Text));
                                insertCmd.Parameters.AddWithValue("@Menge", tbx_menge.Text);
                                insertCmd.Parameters.AddWithValue("@Kommentar", tbx_kommentar.Text);

                                insertCmd.ExecuteNonQuery();
                            }

                            MessageBox.Show("Erfolgreich");

                            // Rufe die RefreshData-Methode des Hauptformulars auf
                            mainForm?.RefreshData();

                            this.DialogResult = DialogResult.OK;
                            this.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Behandele Ausnahmen hier, wenn die Datenbankoperation fehlschlägt
                MessageBox.Show("Fehler beim Speichern der Daten: " + ex.Message, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            lblfehlermeldung();
        }
        public void lblfehlermeldung()
        {

            if (tbx_ang_id.Text == "")
            {
                lbl_fehlermeldung.Visible = true;
                lbl_fehlermeldung.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_fehlermeldung.Visible = false;
            }

            if (tbx_pe_typ_id.Text == "")
            {
                lbl_fehlername.Visible = true;
                lbl_fehlername.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_fehlername.Visible = false;
            }

            if (tbx_preis.Text == "")
            {
                lbl_fehlerust.Visible = true;
                lbl_fehlerust.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_fehlerust.Visible = false;
            }

            if (tbx_menge.Text == "")
            {
                lbl_fehleradresse.Visible = true;
                lbl_fehleradresse.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_fehleradresse.Visible = false;
            }

            if (tbx_kommentar.Text == "")
            {
                lbl_fehlerliefadresse.Visible = true;
                lbl_fehlerliefadresse.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_fehlerliefadresse.Visible = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
