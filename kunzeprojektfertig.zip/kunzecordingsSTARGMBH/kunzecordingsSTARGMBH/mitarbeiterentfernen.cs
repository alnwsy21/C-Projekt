﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH
{
    public partial class mitarbeiterentfernen : Form
    {


        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = null;
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();

        string mnr = "";
        bool clicked;
        public mitarbeiterentfernen()
        {
            InitializeComponent();
      
        }
       
      
      
        private void mitarbeiterentfernen_Load(object sender, EventArgs e)
        {
            try
            { // Verbindung zur Datenbank öffnen
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";
                con.Open();
                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            try
            {
                ds.Clear();

                con.Open();
                ada = new OleDbDataAdapter("SELECT M_id, M_vname, M_nname, M_pass, M_admin FROM Mitarbeiter where M_gelöscht=false", con);

                ada.Fill(ds, "Mitarbeiterübersicht");
                dg.DataSource = ds;
                dg.DataMember = "Mitarbeiterübersicht";
        
                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler beim laden der Mitarbeiter Informationen. Bitte wenden sie sich an die IT-Abteilung" + a);
            }

        }

        private void dg_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dg_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (clicked == true)
            {
                con.Open();
                cmd = new OleDbCommand("Update Mitarbeiter set M_gelöscht = true where M_id = " + mnr + "", con);
                cmd.ExecuteNonQuery();
                ds.Clear();
                ada.Fill(ds, "Mitarbeiterübersicht");
                dg.DataSource = ds;
                dg.DataMember = "Mitarbeiterübersicht";
                con.Close();
                dg.Columns["M_id"].HeaderText = "Nummer";
                dg.Columns["M_vname"].HeaderText = "Vorname";
                dg.Columns["M_pass"].HeaderText = "Password";
                dg.Columns["M_admin"].HeaderText = "Benutzernamen";
                dg.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            }
            else
            {
                MessageBox.Show("Sie müssen doppelt auf den gewünschten Mitarbeiter Klicken damit sie ihn löschen können");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            entfernenmitarbeiter mItarbeitergelöscht = new entfernenmitarbeiter();
            mItarbeitergelöscht.ShowDialog();
            ds.Clear();
            ada.Fill(ds, "Mitarbeiterübersicht");
            dg.DataSource = ds;
            dg.DataMember = "Mitarbeiterübersicht";
        }

        private void dg_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            clicked = true;
            if (e.RowIndex >= 0)
            {
                dg.CurrentRow.Selected = true;
                mnr = dg.Rows[e.RowIndex].Cells["M_id"].FormattedValue.ToString();
                label3.Text = dg.Rows[e.RowIndex].Cells["M_id"].FormattedValue.ToString();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
