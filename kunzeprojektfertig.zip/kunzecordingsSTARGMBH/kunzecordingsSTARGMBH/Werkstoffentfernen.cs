﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class Werkstoffentfernen : Form {
        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = null;
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();

        string mnr = "";
        bool clicked;
        public Werkstoffentfernen() {
            InitializeComponent();
        }

        private void Werkstoffentfernen_Load(object sender, EventArgs e) {
            try { // Verbindung zur Datenbank öffnen
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";
                con.Open();
                con.Close();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            try {
                ds.Clear();

                con.Open();
                ada = new OleDbDataAdapter("select W_id, W_name, W_kurz, W_kennzeichen, W_oberfläche, W_höhe, W_breite, W_länge, W_gewicht from Werkstoff where W_gelöscht=false", con);

                ada.Fill(ds, "Mitarbeiterübersicht");
                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "Mitarbeiterübersicht";
     
                con.Close();
                dgentfernen.Columns["W_id"].HeaderText = "Nummer";
                dgentfernen.Columns["W_name"].HeaderText = "Name";
                dgentfernen.Columns["W_kurz"].HeaderText = "Kurz";
                dgentfernen.Columns["W_kennzeichen"].HeaderText = "Kennzeichen";
                dgentfernen.Columns["W_oberfläche"].HeaderText = "Oberfläche";
                dgentfernen.Columns["W_höhe"].HeaderText = "Höhe";
                dgentfernen.Columns["W_breite"].HeaderText = "Breite";
                dgentfernen.Columns["W_länge"].HeaderText = "Länge";
                dgentfernen.Columns["W_gewicht"].HeaderText = "Gewicht";
                dgentfernen.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            }
            catch (Exception a) {
                MessageBox.Show("Fehler beim laden der W_id Informationen. Bitte wenden sie sich an die IT-Abteilung" + a);
            }
        }

        private void button1_Click(object sender, EventArgs e) {
            if (clicked == true) {
                con.Open();
                cmd = new OleDbCommand("Update Werkstoff set W_gelöscht = true where W_id = " + mnr + "", con);
                cmd.ExecuteNonQuery();
                ds.Clear();
                ada.Fill(ds, "Mitarbeiterübersicht");
                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "Mitarbeiterübersicht";
                con.Close();
            }
            else {
                MessageBox.Show("Sie müssen doppelt auf den gewünschten Werkstoff Klicken damit sie ihn löschen können");
            }
        }

        private void button2_Click(object sender, EventArgs e) {
            entfernenwerkstoff mItarbeitergelöscht = new entfernenwerkstoff();
            mItarbeitergelöscht.ShowDialog();
            ds.Clear();
            ada.Fill(ds, "Mitarbeiterübersicht");
            dgentfernen.DataSource = ds;
            dgentfernen.DataMember = "Mitarbeiterübersicht";  
        }

        private void dgentfernen_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            clicked = true;
            if (e.RowIndex >= 0) {
                dgentfernen.CurrentRow.Selected = true;
                mnr = dgentfernen.Rows[e.RowIndex].Cells["W_id"].FormattedValue.ToString();
                label3.Text = dgentfernen.Rows[e.RowIndex].Cells["W_id"].FormattedValue.ToString();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
