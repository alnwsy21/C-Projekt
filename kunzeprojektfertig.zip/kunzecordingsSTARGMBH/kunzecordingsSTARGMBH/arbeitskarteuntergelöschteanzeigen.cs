﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH
{
    public partial class arbeitskarteuntergelöschteanzeigen : Form
    {
        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = null;
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();


        bool clicked;
        string mnr = "";
        public arbeitskarteuntergelöschteanzeigen()
        {
            InitializeComponent();
        }

        private void arbeitskarteuntergelöschteanzeigen_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source= Kunze.accdb";
                con.Open();
                con.Close();
            }
            catch
            {
                MessageBox.Show("Die Datenbank konnte nicht geöffnet werden");
            }
            try
            {
                con.Open();
                ada = new OleDbDataAdapter("select * from Probe_unter where P_unter_gelöscht = true", con);
                ada.Fill(ds, "P_id");
                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "P_id";
                con.Close();
                //spaltenformatierung();
                dgentfernen.Columns["P_id"].HeaderText = "Prüfungs_nummer";
                dgentfernen.Columns["Pe_id"].HeaderText = "Prüfung_einzel_Nr.";
                dgentfernen.Columns["Pe_typ_id"].HeaderText = "Prüfungeinzel_typ_Nr.";
                dgentfernen.Columns["M_id"].HeaderText = "Mitarbeiternummer";
            }
            catch
            {
                MessageBox.Show("Der Datensatz konnte nicht gelöscht werden");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgentfernen.SelectedRows.Count > 0)
                {
                    con.Open();
                    int mnr = Convert.ToInt32(dgentfernen.SelectedRows[0].Cells["P_id"].Value);
                    cmd = new OleDbCommand("Update Probe_unter set P_unter_gelöscht = false where P_id = " + mnr, con);
                    cmd.ExecuteNonQuery();
                    ds.Clear();
                    ada.Fill(ds, "P_id");
                    dgentfernen.DataSource = ds;
                    dgentfernen.DataMember = "P_id";
                    con.Close();
                }
                else
                {
                    MessageBox.Show("Bitte wählen Sie einen Datensatz aus, um ihn zu aktualisieren.");
                }
            }
            catch (Exception a)
            {
                MessageBox.Show("Der Datensatz konnte nicht hinzugefügt werden" + a);
            }

        }

        private void dgentfernen_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            clicked = true;

            if (e.RowIndex >= 0 && e.ColumnIndex >= 0 && e.RowIndex < dgentfernen.Rows.Count)
            {
                if (dgentfernen.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                {
                    dgentfernen.CurrentRow.Selected = true;
                    mnr = dgentfernen.Rows[e.RowIndex].Cells["P_id"].FormattedValue.ToString();
                    label3.Text = dgentfernen.Rows[e.RowIndex].Cells["P_id"].FormattedValue.ToString();
                }
                else
                {
                    clicked = false; // Setze clicked auf false, da kein Wert in der Zelle gefunden wurde
                    MessageBox.Show("Bitte doppelt auf den gewünschten P_id klicken, um ihn zu löschen.");
                }
            }
            else
            {
                clicked = false; // Setze clicked auf false, da ungültige Indizes
                MessageBox.Show("Ungültige Indizes. Bitte doppelt auf den gewünschten P_id klicken, um ihn zu löschen.");
            }

        }
    }
}
