﻿                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class Kundenanzeigen : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public Kundenanzeigen() {
            InitializeComponent();
        }

        private void Kundenanzeigen_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";

                con.Open();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }

            try {
                ds.Clear();

                ada = new OleDbDataAdapter("select K_id, K_name, K_ust_id, K_adresse, K_lief_adresse from Kunden", con);
                ada.Fill(ds, "kunden1");
                dganzeigen.DataSource = ds;
                dganzeigen.DataMember = "kunden1";
                con.Close();
                dganzeigen.Columns["K_id"].HeaderText = "Nummer";
                dganzeigen.Columns["K_name"].HeaderText = "Name";
                dganzeigen.Columns["K_ust_id"].HeaderText = "Umsatzsteuer_nummer";
                dganzeigen.Columns["K_adresse"].HeaderText = "Adresse";
                dganzeigen.Columns["K_lief_adresse"].HeaderText = "Liefer_adresse";
                dganzeigen.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            }
            catch (Exception) {

                MessageBox.Show("fehler");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
