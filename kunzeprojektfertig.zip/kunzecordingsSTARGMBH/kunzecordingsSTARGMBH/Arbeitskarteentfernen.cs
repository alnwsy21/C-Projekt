﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH
{
    public partial class Arbeitskarteentfernen : Form
    {
        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = null;
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
 

        string mnr = "";
   
        bool clicked;
       
        public Arbeitskarteentfernen()
        {
            InitializeComponent();
        }

        private void Arbeitskarteentfernen_Load(object sender, EventArgs e)
        {
            try
            { // Verbindung zur Datenbank öffnen
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";
                con.Open();
                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }

            try
            {
                ds.Clear();

                con.Open();
                ada = new OleDbDataAdapter(" SELECT P_id, Prob_id, P_eingang, P_fertigstellung_dat, P_fertigstellung_zeit_id, P_abnahme_dat, P_charge_id, P_bemerkung, P_sonstige1, P_sonstige2, P_sonstige3, P_anzahl, P_abgeschlossen, Abnahme_id from Probe_kopf where P_kopf_gelöscht=false", con);

                ada.Fill(ds, "P_id");
                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "P_id";
                //spaltenformatierung();
                dgentfernen.Columns["P_id"].HeaderText = "Prüfungs_nummer";
                dgentfernen.Columns["Prob_id"].HeaderText = "Probe_nummer";
                dgentfernen.Columns["P_eingang"].HeaderText = "Prüfnugs_eingang";
                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler beim laden der Mitarbeiter Informationen. Bitte wenden sie sich an die IT-Abteilung" + a);
            }

          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (clicked == true)
            {
                con.Open();
                cmd = new OleDbCommand("Update Probe_kopf set P_kopf_gelöscht = true where P_id = " + mnr + "", con);
                cmd.ExecuteNonQuery();
                ds.Clear();
                ada.Fill(ds, "P_id");
                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "P_id";
                con.Close();
            }
            else
            {
                MessageBox.Show("Sie müssen doppelt auf den gewünschten P_id Klicken damit sie ihn löschen können");
            }

        }

        private void dgentfernen_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            clicked = true;
            if (e.RowIndex >= 0)
            {
                dgentfernen.CurrentRow.Selected = true;
                mnr = dgentfernen.Rows[e.RowIndex].Cells["P_id"].FormattedValue.ToString();
                label3.Text = dgentfernen.Rows[e.RowIndex].Cells["P_id"].FormattedValue.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            entfernenarbeitskartekopf kopf = new entfernenarbeitskartekopf();
            kopf.ShowDialog();
            ds.Clear();
            ada.Fill(ds, "P_id");
            dgentfernen.DataSource = ds;
            dgentfernen.DataMember = "P_id";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            arbeitskarteunterentfernendaten anzeigen = new arbeitskarteunterentfernendaten();
            anzeigen.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
