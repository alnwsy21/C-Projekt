﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kunzecordingsSTARGMBH {
    public partial class Mitarbeiter : UserControl {
        public Mitarbeiter() {
            InitializeComponent();
        }

        private void btn_prüfung_Click(object sender, EventArgs e) {
            Mitarbeitershow anzeigen = new Mitarbeitershow();
            anzeigen.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e) {
            mitarbeiteradd hinzufügen = new mitarbeiteradd();
            hinzufügen.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e) {
            mitarbeiterbearbeiten bearbeitenm = new mitarbeiterbearbeiten();
            bearbeitenm.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e) {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e) {
            mitarbeiterentfernen entfernen = new mitarbeiterentfernen();
            entfernen.ShowDialog();
        }
    }
}
