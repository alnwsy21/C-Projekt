﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;    
namespace kunzecordingsSTARGMBH {
    public partial class löschenmitarbeiter : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

     
      
        private DataGridViewRow selectedRow;

        public löschenmitarbeiter(DataGridViewRow selectedRow) {
            InitializeComponent();
            this.selectedRow = selectedRow;
        }

        private void löschenbearbeiten_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";

                con.Open();
              
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            try {
                //der tabelname das kein - enthalten

                cmd = new OleDbCommand("select M_id from Mitarbeiter", con);
                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                //liest die datensätze bis zum tabelle
                while (dr.Read()) {
                    cbx_mnr.Items.Add(dr.GetInt32(0));
                }
            }

            catch (Exception a) {
                MessageBox.Show("Tabellen-Zugriffsfehler(Sequentielles suchen):" + a);
            }
            tbx_mlp.PasswordChar = '•';
        }

        private void LöschenAbschließen() {
            try {
                // Führe die Logik zum Löschen der Daten durch
                // ...
                try {
                    cmd = new OleDbCommand("delete * from Mitarbeiter where M_id=" + int.Parse(cbx_mnr.SelectedItem.ToString()) + "", con);
                    cmd.ExecuteNonQuery();
                    listefüllen();
                }
                catch (Exception a) {
                    MessageBox.Show("Fehler" + a);
                }
                // Setze DialogResult auf OK, um anzuzeigen, dass das Löschen erfolgreich war
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex) {
                MessageBox.Show("Fehler beim Löschen: " + ex.Message);
            }
        }
        private void listefüllen() {
            try {
                cbx_mnr.Items.Clear();
                //der tabelname das kein - enthalten

                cmd = new OleDbCommand("select * from Mitarbeiter order by M_id asc", con);
                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                MessageBox.Show("geschafft");
                //liest die datensätze bis zum tabelle
                while (dr.Read()) {
                    cbx_mnr.Items.Add(dr.GetInt32(0));
                }
            }
            catch (Exception a) {
                MessageBox.Show("Tabellen-Zugriffsfehler(Sequentielles suchen):" + a);
            }

        }

        private void btn_anzeigen_Click(object sender, EventArgs e) {
            LöschenAbschließen();
        }

        private void cbx_mnr_SelectedIndexChanged(object sender, EventArgs e) {
            try {
                int vergleich = System.Convert.ToInt32(cbx_mnr.SelectedItem.ToString());

                //es wird ein neuer zugriff (direktzugriff) auf die datenbank ausführt

                cmd = new OleDbCommand("select * from Mitarbeiter where M_id =" + vergleich, con);
                dr = cmd.ExecuteReader();


                dr.Read();
                tbx_vname.Text = dr.GetString(1);
                tbx_nname.Text = dr.GetString(2);
                tbx_mlp.Text = dr.GetString(3);
                tbx_mlname.Text = dr.GetString(4);

            }
            catch (Exception a) {
                MessageBox.Show("tabellen-zugriffsfehler(direkt suchen)" + a);
            }
        }
    }
}
