﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class Löschenkunde : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;



        private DataGridViewRow selectedRow;
        public Löschenkunde(DataGridViewRow selectedRow) {
            InitializeComponent();
            this.selectedRow = selectedRow;
        }

        private void Löschenkunde_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";

                con.Open();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            try {
                //der tabelname das kein - enthalten

                cmd = new OleDbCommand("select K_id from Kunden", con);
                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                //liest die datensätze bis zum tabelle
                while (dr.Read()) {
                    cbx_kdnr.Items.Add(dr.GetInt32(0));
                }
            }

            catch (Exception a) {
                MessageBox.Show("Tabellen-Zugriffsfehler(Sequentielles suchen):" + a);
            }
        }
        private void LöschenAbschließen() {
            try {
                // Führe die Logik zum Löschen der Daten durch
                // ...
                try {
                    cmd = new OleDbCommand("delete * from Kunden where K_id=" + int.Parse(cbx_kdnr.SelectedItem.ToString()) + "", con);
                    cmd.ExecuteNonQuery();
                    listefüllen();
                }
                catch (Exception a) {
                    MessageBox.Show("Fehler" + a);
                }
                // Setze DialogResult auf OK, um anzuzeigen, dass das Löschen erfolgreich war
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex) {
                MessageBox.Show("Fehler beim Löschen: " + ex.Message);
            }
        }
        private void listefüllen() {
            try {
                cbx_kdnr.Items.Clear();
                //der tabelname das kein - enthalten

                cmd = new OleDbCommand("select * from Kunden order by K_id asc", con);
                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                MessageBox.Show("geschafft");
                //liest die datensätze bis zum tabelle
                while (dr.Read()) {
                    cbx_kdnr.Items.Add(dr.GetInt32(0));
                }
            }
            catch (Exception a) {
                MessageBox.Show("Tabellen-Zugriffsfehler(Sequentielles suchen):" + a);
            }

        }

        private void button1_Click(object sender, EventArgs e) {
            LöschenAbschließen();
        }

        private void cbx_kdnr_SelectedIndexChanged(object sender, EventArgs e) {
            try {
                int vergleich = System.Convert.ToInt32(cbx_kdnr.SelectedItem.ToString());

                //es wird ein neuer zugriff (direktzugriff) auf die datenbank ausführt

                cmd = new OleDbCommand("select * from Kunden where K_id =" + vergleich, con);
                dr = cmd.ExecuteReader();


                dr.Read();
                tbx_kname.Text = dr.GetString(1);
                tbx_ust.Text = dr.GetInt32(2).ToString();
                tbx_adresse.Text = dr.GetString(3);
                tbx_liefadresse.Text = dr.GetString(4);

            }
            catch (Exception a) {
                MessageBox.Show("tabellen-zugriffsfehler(direkt suchen)" + a);
            }
        }
    }
}
