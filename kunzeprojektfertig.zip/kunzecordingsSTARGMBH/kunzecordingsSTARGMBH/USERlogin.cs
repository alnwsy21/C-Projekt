﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class USERlogin : UserControl {
        private OleDbConnection verbindung;
        private string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= Kunze.accdb;";

        public USERlogin() {
            InitializeComponent();
            verbindung = new OleDbConnection(connectionString);
        }

        private void USERlogin_Load(object sender, EventArgs e) {
          //  string connectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";
            OleDbConnection connection = new OleDbConnection(connectionString);


            tbx_password.PasswordChar = '•'; // oder textBox1.PasswordChar = '.';
            tbx_show.PasswordChar = '•'; // oder textBox1.PasswordChar = '.';
                                         // cbx_passwshow.CheckedChanged += checkBox1_CheckedChanged;
        }

        private void tbx_password_TextChanged(object sender, EventArgs e) {
      
            tbx_show.Text = tbx_password.Text;
        }

        private void cbx_passwshow_CheckedChanged(object sender, EventArgs e) {
            if (cbx_passwshow.Checked && tbx_show.Visible == false) {
                tbx_show.PasswordChar = '\0'; // Zeigt den Text in tbx_show sichtbar
                tbx_show.Visible = true;
            }
            else {
                tbx_show.PasswordChar = '*'; // Verdeckt den Text in tbx_show
                tbx_show.Visible = false;
            }
        }

        private void button2_Click(object sender, EventArgs e) {
            tbx_password.Clear();
            tbx_name.Clear();
            cbx_passwshow.Checked = false;
        }

        private void button1_Click(object sender, EventArgs e) {

            if (tbx_name.Text == "")
            {
                lbl_fehler1.Visible = true;
                lbl_fehler1.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_fehler1.Visible = false;
            }

            if (tbx_password.Text == "")
            {
                lbl_fehler2.Visible = true;
                lbl_fehler2.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_fehler2.Visible = false;
            }

            // Zusätzliche Überprüfung für leere Felder
            if (tbx_name.Text == "" || tbx_password.Text == "")
            {
                MessageBox.Show("Bitte füllen Sie alle Felder aus.");
                return; // Verlassen Sie die Methode, da nicht alle Felder ausgefüllt sind
            }

            string benutzername = tbx_name.Text;
            string passwort = tbx_password.Text;

            if (ÜberprüfeAnmeldung(benutzername, passwort))
            {
                
                Hauptmenü haupt = new Hauptmenü();
                haupt.ShowDialog();
              
                tbx_name.Clear();
                tbx_password.Clear();
            }
            else
            {
                MessageBox.Show("Fehler bei der Anmeldung! Überprüfen Sie Ihre Daten.");
                tbx_password.Clear();
                tbx_name.Clear();
            }

        }
        private bool ÜberprüfeAnmeldung(string benutzername, string passwort) {
            using (OleDbConnection verbindung = new OleDbConnection(connectionString)) {
                // ... andere Code ...
                try {
                    verbindung.Open();
                    OleDbCommand befehl = new OleDbCommand("SELECT Benutzername FROM Mitarbeiter WHERE M_admin = @Benutzername AND M_pass = @Passwort", verbindung);
                    befehl.Parameters.AddWithValue("@Benutzername", benutzername);
                    befehl.Parameters.AddWithValue("@Passwort", passwort);
                    OleDbDataReader leser = befehl.ExecuteReader();

                    if (leser.HasRows) {
                        leser.Close();
                        verbindung.Close();
                        return true;
                    }
                }
                catch (Exception ex) {
                    MessageBox.Show("Fehler bei der Anmeldung: " + ex.Message);
                }
                finally {
                    verbindung.Close();
                }
                return false;
            }
        }

        private void tbx_name_TextChanged(object sender, EventArgs e)
        {
 
        }
    }
}
