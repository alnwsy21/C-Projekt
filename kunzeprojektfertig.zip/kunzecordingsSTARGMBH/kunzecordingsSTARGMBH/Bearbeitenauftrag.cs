﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class Bearbeitenauftrag : Form {
        OleDbCommand cmd = null;


        private readonly string connectionString;
        private readonly OleDbConnection con = new OleDbConnection();
        private DataGridViewRow selectedRow;
        public DataGridViewRow UpdatedRow { get; private set; }
        public Bearbeitenauftrag(DataGridViewRow selectedRow, string connectionString) {
            InitializeComponent();
            this.selectedRow = selectedRow;
            this.connectionString = connectionString;
        }

        private void Bearbeitenauftrag_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = connectionString;
                con.Open();

                // Hier rufe ich eine Methode auf, um die Daten in den Textboxen anzuzeigen
                AnzeigenDerDaten();
            }
            catch (Exception ex) {
                MessageBox.Show("Fehler: " + ex.Message);
            }
        }
        private void AnzeigenDerDaten() {
            try {


               
                tbx_anr.Text = selectedRow.Cells["Auf_id"].Value.ToString();
                tbx_aangenommen.Text = selectedRow.Cells["Auf_angenommen"].Value.ToString();
                tbx_liefertermin.Text = selectedRow.Cells["Auf_liefertermin"].Value.ToString();
                tbx_kdnr.Text = selectedRow.Cells["K_id"].Value.ToString();
                tbx_status.Text = selectedRow.Cells["Status_id"].Value.ToString();
                tbx_wnr.Text = selectedRow.Cells["W_id"].Value.ToString();
                tbx_norm.Text = selectedRow.Cells["N_id"].Value.ToString();
                tbx_ausbestellid.Text = selectedRow.Cells["Aus_bestell_id"].Value.ToString();
                tbx_aprüflos.Text = selectedRow.Cells["Auf_prüflos"].Value.ToString();
                tbx_anspr.Text = selectedRow.Cells["Anspr_id"].Value.ToString();
                tbx_probe.Text = selectedRow.Cells["Prob_id"].Value.ToString();
              
            }
            catch (Exception ex) {
                MessageBox.Show("Fehler beim Anzeigen der Daten: " + ex.Message);
            }
        }

        private void btn_anzeigen_Click(object sender, EventArgs e) {
            BearbeitungAbschließen();
        }
        private void BearbeitungAbschließen() {

            try
            {
                // Überprüfe, ob alle Textboxen ausgefüllt sind
                if (string.IsNullOrWhiteSpace(tbx_anr.Text) || string.IsNullOrWhiteSpace(tbx_aangenommen.Text) || string.IsNullOrWhiteSpace(tbx_liefertermin.Text) ||
                    string.IsNullOrWhiteSpace(tbx_kdnr.Text) || string.IsNullOrWhiteSpace(tbx_status.Text) || string.IsNullOrWhiteSpace(tbx_wnr.Text) ||
                    string.IsNullOrWhiteSpace(tbx_norm.Text) || string.IsNullOrWhiteSpace(tbx_ausbestellid.Text) || string.IsNullOrWhiteSpace(tbx_aprüflos.Text) ||
                    string.IsNullOrWhiteSpace(tbx_anspr.Text) || string.IsNullOrWhiteSpace(tbx_probe.Text))
                {
                    // Zeige eine Meldung an, dass alle Felder ausgefüllt werden müssen
                    MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    // Überprüfe, ob die Zahlenfelder gültige Zahlen enthalten
                    int anr, kdnr, status, wnr, norm, ausbestellid, aprueflos, anspr, probe;

                    if (!int.TryParse(tbx_anr.Text, out anr))
                    {
                        MessageBox.Show("Bitte geben Sie eine gültige Zahl für Auftragsnummer ein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (!int.TryParse(tbx_kdnr.Text, out kdnr))
                    {
                        MessageBox.Show("Bitte geben Sie eine gültige Zahl für Kundennummer ein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (!int.TryParse(tbx_status.Text, out status))
                    {
                        MessageBox.Show("Bitte geben Sie eine gültige Zahl für Status ein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (!int.TryParse(tbx_wnr.Text, out wnr))
                    {
                        MessageBox.Show("Bitte geben Sie eine gültige Zahl für Werkstoffnummer ein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (!int.TryParse(tbx_norm.Text, out norm))
                    {
                        MessageBox.Show("Bitte geben Sie eine gültige Zahl für Norm ein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (!int.TryParse(tbx_ausbestellid.Text, out ausbestellid))
                    {
                        MessageBox.Show("Bitte geben Sie eine gültige Zahl für Aus Bestell-ID ein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (!int.TryParse(tbx_aprüflos.Text, out aprueflos))
                    {
                        MessageBox.Show("Bitte geben Sie eine gültige Zahl für Prüflos ein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (!int.TryParse(tbx_anspr.Text, out anspr))
                    {
                        MessageBox.Show("Bitte geben Sie eine gültige Zahl für Ansprechpartner ein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (!int.TryParse(tbx_probe.Text, out probe))
                    {
                        MessageBox.Show("Bitte geben Sie eine gültige Zahl für Probe ein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    cmd = new OleDbCommand("UPDATE Auftrag SET Auf_angenommen='" + tbx_aangenommen.Text + "', Auf_liefertermin='" + tbx_liefertermin.Text +
                        "', K_id=" + kdnr + ", Status_id=" + status + ", W_id=" + wnr + ", N_id=" + norm + ", Aus_bestell_id=" + ausbestellid +
                        ", Auf_prüflos=" + aprueflos + ", Anspr_id=" + anspr + ", Prob_id=" + probe + " WHERE Auf_id=" + anr, con);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Erfolgreich bearbeitet!");

                    // Setze UpdatedRow auf die aktualisierte Zeile
                    UpdatedRow = selectedRow;

                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler beim Bearbeiten: " + ex.Message, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
