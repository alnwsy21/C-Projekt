﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH
{
    public partial class arbeitskarteunterentfernendaten : Form
    {
        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = null;
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();


        string mnr = "";

        bool clicked;

        public arbeitskarteunterentfernendaten()
        {
            InitializeComponent();
        }

        private void arbeitskarteunterentfernendaten_Load(object sender, EventArgs e)
        {
            try
            { // Verbindung zur Datenbank öffnen
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";
                con.Open();
                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }

            try
            {
                ds.Clear();

                con.Open();
                ada = new OleDbDataAdapter(" SELECT P_id, Pe_id, Pe_typ_id, Pe_anzahl, Pe_temp, Pe_probenform, Pe_probenlage, Pe_norm, Pe_bemerkung, M_id, P_ergebnis_text from Probe_unter where P_unter_gelöscht=false", con);

                ada.Fill(ds, "P_id");
                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "P_id";
                //spaltenformatierung();
                dgentfernen.Columns["P_id"].HeaderText = "Prüfungs_nummer";
                dgentfernen.Columns["Pe_id"].HeaderText = "Prüfung_einzel_Nr.";
                dgentfernen.Columns["Pe_typ_id"].HeaderText = "Prüfungeinzel_typ_Nr.";
                dgentfernen.Columns["M_id"].HeaderText = "Mitarbeiternummer";
                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler beim laden der Mitarbeiter Informationen. Bitte wenden sie sich an die IT-Abteilung" + a);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (clicked == true)
            {
                con.Open();
                cmd = new OleDbCommand("Update Probe_unter set P_unter_gelöscht = true where P_id = " + mnr + "", con);
                cmd.ExecuteNonQuery();
                ds.Clear();
                ada.Fill(ds, "P_id");
                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "P_id";
                con.Close();
            }
            else
            {
                MessageBox.Show("Sie müssen doppelt auf den gewünschten P_id Klicken damit sie ihn löschen können");
            }
        }

        private void dgentfernen_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            clicked = true;

            if (e.RowIndex >= 0 && e.ColumnIndex >= 0 && e.RowIndex < dgentfernen.Rows.Count)
            {
                if (dgentfernen.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                {
                    dgentfernen.CurrentRow.Selected = true;
                    mnr = dgentfernen.Rows[e.RowIndex].Cells["P_id"].FormattedValue.ToString();
                    label3.Text = dgentfernen.Rows[e.RowIndex].Cells["P_id"].FormattedValue.ToString();
                }
                else
                {
                    clicked = false; // Setze clicked auf false, da kein Wert in der Zelle gefunden wurde
                    MessageBox.Show("Bitte doppelt auf den gewünschten P_id klicken, um ihn zu löschen.");
                }
            }
            else
            {
                clicked = false; // Setze clicked auf false, da ungültige Indizes
                MessageBox.Show("Ungültige Indizes. Bitte doppelt auf den gewünschten P_id klicken, um ihn zu löschen.");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            arbeitskarteuntergelöschteanzeigen kopf = new arbeitskarteuntergelöschteanzeigen();
            kopf.ShowDialog();
            ds.Clear();
            ada.Fill(ds, "P_id");
            dgentfernen.DataSource = ds;
            dgentfernen.DataMember = "P_id";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
