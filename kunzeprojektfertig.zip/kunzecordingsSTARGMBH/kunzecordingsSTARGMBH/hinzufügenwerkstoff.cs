﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class hinzufügenwerkstoff : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;


        private Werkstoffhinzufügen mainForm;
        private DataGridViewRow selectedRow;
        public hinzufügenwerkstoff() {
            InitializeComponent();
            this.mainForm = mainForm;
        }
        public hinzufügenwerkstoff(DataGridViewRow selectedRow) : this() {
            this.selectedRow = selectedRow;
            
        }

        private void hinzufügenwerkstoff_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";
                con.Open();
                
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
        }

        private void btn_anzeigen_Click(object sender, EventArgs e) {
            try
            {
                // Überprüfe, ob alle Textboxen ausgefüllt sind
                if (string.IsNullOrWhiteSpace(tbx_wnr.Text) || string.IsNullOrWhiteSpace(tbx_wname.Text) || string.IsNullOrWhiteSpace(tbx_wkurz.Text) || string.IsNullOrWhiteSpace(tbx_wkennzeichen.Text) || string.IsNullOrWhiteSpace(tbx_woberfläche.Text) || string.IsNullOrWhiteSpace(tbx_whöhe.Text) || string.IsNullOrWhiteSpace(tbx_wbreite.Text) || string.IsNullOrWhiteSpace(tbx_wlänge.Text) || string.IsNullOrWhiteSpace(tbx_wgewicht.Text))
                {
                    // Zeige eine Meldung an, dass alle Felder ausgefüllt werden müssen
                    MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    // Führe die Datenbankoperation nur aus, wenn alle Felder ausgefüllt sind

                    // Überprüfe, ob die Werkstoff-ID bereits existiert
                    using (OleDbCommand checkCmd = new OleDbCommand("SELECT COUNT(*) FROM Werkstoff WHERE W_id = @W_id", con))
                    {
                        // Überprüfe, ob die Werkstoff-ID eine ganze Zahl ist
                        if (!int.TryParse(tbx_wnr.Text, out int wId))
                        {
                            MessageBox.Show("Die Werkstoff-ID muss eine ganze Zahl sein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        if (!int.TryParse(tbx_wbreite.Text, out int wbreite))
                        {
                            MessageBox.Show("Die Breite muss eine ganze Zahl sein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        if (!int.TryParse(tbx_wgewicht.Text, out int wgewicht))
                        {
                            MessageBox.Show("Die Gewicht muss eine ganze Zahl sein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        if (!int.TryParse(tbx_whöhe.Text, out int höhe))
                        {
                            MessageBox.Show("Die höhe muss eine ganze Zahl sein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        if (!int.TryParse(tbx_wlänge.Text, out int wlänge))
                        {
                            MessageBox.Show("Die Länge muss eine ganze Zahl sein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        if (!int.TryParse(tbx_woberfläche.Text, out int woberfläche))
                        {
                            MessageBox.Show("Die Oberfläche muss eine ganze Zahl sein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }

                        checkCmd.Parameters.AddWithValue("@W_id", wId);

                        int existingRecords = (int)checkCmd.ExecuteScalar();

                        if (existingRecords > 0)
                        {
                            // Die Werkstoff-ID existiert bereits, zeige eine entsprechende Meldung an
                            MessageBox.Show("Die Werkstoff-ID existiert bereits. Bitte wählen Sie eine andere ID.", "Duplikate verhindern", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                        else
                        {
                            // Füge den neuen Datensatz ein
                            using (OleDbCommand insertCmd = new OleDbCommand("INSERT INTO Werkstoff(W_id, W_name, W_kurz, W_kennzeichen, W_oberfläche, W_höhe, W_breite, W_länge, W_gewicht) VALUES (@W_id, @W_name, @W_kurz, @W_kennzeichen, @W_oberfläche, @W_höhe, @W_breite, @W_länge, @W_gewicht)", con))
                            {
                                insertCmd.Parameters.AddWithValue("@W_id", wId);
                                insertCmd.Parameters.AddWithValue("@W_name", tbx_wname.Text);
                                insertCmd.Parameters.AddWithValue("@W_kurz", tbx_wkurz.Text);
                                insertCmd.Parameters.AddWithValue("@W_kennzeichen", tbx_wkennzeichen.Text);

                                // Überprüfe, ob die numerischen Felder ganze Zahlen sind
                                if (!int.TryParse(tbx_woberfläche.Text, out int wOberfläche) || !int.TryParse(tbx_whöhe.Text, out int wHöhe) || !int.TryParse(tbx_wbreite.Text, out int wBreite) || !int.TryParse(tbx_wlänge.Text, out int wLänge) || !int.TryParse(tbx_wgewicht.Text, out int wGewicht))
                                {
                                    MessageBox.Show("Die numerischen Felder müssen ganze Zahlen sein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    return;
                                }

                                insertCmd.Parameters.AddWithValue("@W_oberfläche", wOberfläche);
                                insertCmd.Parameters.AddWithValue("@W_höhe", wHöhe);
                                insertCmd.Parameters.AddWithValue("@W_breite", wBreite);
                                insertCmd.Parameters.AddWithValue("@W_länge", wLänge);
                                insertCmd.Parameters.AddWithValue("@W_gewicht", wGewicht);

                                insertCmd.ExecuteNonQuery();
                            }

                            MessageBox.Show("Erfolgreich");

                            // Rufe die RefreshData-Methode des Hauptformulars auf
                            mainForm?.RefreshData();

                            this.DialogResult = DialogResult.OK;
                            this.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Behandele Ausnahmen hier, wenn die Datenbankoperation fehlschlägt
                MessageBox.Show("Fehler beim Speichern der Daten: " + ex.Message, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



        }

        public void meldung() {
            try {
                // Überprüfe, ob alle Textboxen ausgefüllt sind
                if (string.IsNullOrEmpty(tbx_wnr.Text) || string.IsNullOrEmpty(tbx_wname.Text) || string.IsNullOrEmpty(tbx_wkurz.Text) || string.IsNullOrEmpty(tbx_wkennzeichen.Text) || string.IsNullOrEmpty(tbx_woberfläche.Text) || string.IsNullOrEmpty(tbx_whöhe.Text) || string.IsNullOrEmpty(tbx_wbreite.Text) || string.IsNullOrEmpty(tbx_wlänge.Text) || string.IsNullOrEmpty(tbx_wgewicht.Text)) {
                    // Zeige eine Meldung an, dass alle Felder ausgefüllt werden müssen
                    MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else {
                    // Überprüfe, ob die Zahlenfelder gültige Zahlen enthalten
                    int wnr, oberfläche, höhe, breite, länge, gewicht;
                    if (!int.TryParse(tbx_wnr.Text, out wnr) || !int.TryParse(tbx_woberfläche.Text, out oberfläche) || !int.TryParse(tbx_whöhe.Text, out höhe) || !int.TryParse(tbx_wbreite.Text, out breite) || !int.TryParse(tbx_wlänge.Text, out länge) || !int.TryParse(tbx_wgewicht.Text, out gewicht)) {
                        MessageBox.Show("Bitte geben Sie gültige Zahlen für Werkstoffnummer, Oberfläche, Höhe, Breite, Länge und Gewicht ein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return; // Beende die Methode, da ungültige Zahlen eingegeben wurden
                    }

                    // Führe die Datenbankoperation nur aus, wenn alle Felder ausgefüllt sind und gültige Zahlen eingegeben wurden
                    cmd = new OleDbCommand("insert into Werkstoff(W_id, W_name, W_kurz, W_kennzeichen, W_oberfläche, W_höhe, W_breite, W_länge, W_gewicht) values (" + wnr + ",'" + tbx_wname.Text + "','" + tbx_wkurz.Text + "','" + tbx_wkennzeichen.Text + "'," + oberfläche + "," + höhe + "," + breite + "," + länge + "," + gewicht + ")", con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Erfolgreich");

                    // Rufe die RefreshData-Methode des Hauptformulars auf
                    mainForm?.RefreshData();

                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            catch (Exception ex) {
                MessageBox.Show("Fehler beim Hinzufügen: " + ex.Message, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            fehlermeldung();

        }
        public void fehlermeldung() {
            if (tbx_wnr.Text == "") {
                lbl_fehlermeldung.Visible = true;
                lbl_fehlermeldung.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lbl_fehlermeldung.Visible = false;
            }

            if (tbx_wkurz.Text == "") {
                lblkurzfehlermeldung.Visible = true;
                lblkurzfehlermeldung.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lblkurzfehlermeldung.Visible = false;
            }

            if (tbx_wname.Text == "") {
                lblnamefehlermeldung.Visible = true;
                lblnamefehlermeldung.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lblnamefehlermeldung.Visible = false;
            }

            if (tbx_wbreite.Text == "") {
                lblbreitefehlermeldung.Visible = true;
                lblbreitefehlermeldung.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lblbreitefehlermeldung.Visible = false;
            }

            if (tbx_wgewicht.Text == "") {
                lblgewichtfehlermeldung.Visible = true;
                lblgewichtfehlermeldung.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lblgewichtfehlermeldung.Visible = false;
            }
            if (tbx_whöhe.Text == "") {
                lblhöhefehlermeldung.Visible = true;
                lblhöhefehlermeldung.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lblhöhefehlermeldung.Visible = false;
            }
            if (tbx_wkennzeichen.Text == "") {
                lblkennfehlermeldung.Visible = true;
                lblkennfehlermeldung.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lblkennfehlermeldung.Visible = false;
            }
            if (tbx_wlänge.Text == "") {
                lbllängefehlermeldung.Visible = true;
                lbllängefehlermeldung.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lbllängefehlermeldung.Visible = false;
            }
            if (tbx_woberfläche.Text == "") {
                lbloberfehlermeldung.Visible = true;
                lbloberfehlermeldung.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lbloberfehlermeldung.Visible = false;
            }
        }
        private void lbl_fehlermeldung_Click(object sender, EventArgs e) {

        }

        private void button2_Click(object sender, EventArgs e) {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e) {
            this.Close();
        }
    }
}
