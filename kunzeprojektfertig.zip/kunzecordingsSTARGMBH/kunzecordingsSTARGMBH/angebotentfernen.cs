﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH
{
    public partial class angebotentfernen : Form
    {
        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = null;
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();

        string mnr = "";
        bool clicked;
        public angebotentfernen()
        {
            InitializeComponent();
        }

        private void angebotentfernen_Load(object sender, EventArgs e)
        {
            try
            { // Verbindung zur Datenbank öffnen
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";
                con.Open();
                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            try
            {
                ds.Clear();

                con.Open();
                ada = new OleDbDataAdapter("select Ang_id, Pe_typ_id, Kommentar, Menge, Rp_preis from Angebotposition where Ang_gelöscht=false", con);

                ada.Fill(ds, "Angebotposition");
                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "Angebotposition";
                //spaltenformatierung();
                dgentfernen.Columns["Pe_typ_id"].HeaderText = "Prüfungs_nummer";
                dgentfernen.Columns["Ang_id"].HeaderText = "Angebot_nummer";
                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler beim laden der Angebot Informationen. Bitte wenden sie sich an die IT-Abteilung" + a);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (clicked == true)
            {
                con.Open();
                cmd = new OleDbCommand("Update Angebotposition set Ang_gelöscht = true where Ang_id = " + mnr + "", con);
                cmd.ExecuteNonQuery();
                ds.Clear();
                ada.Fill(ds, "Angebotposition");
                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "Angebotposition";

                
                con.Close();
            }
            else
            {
                MessageBox.Show("Sie müssen doppelt auf den gewünschten Angebot Klicken damit sie ihn löschen können");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            entfernenangebot kundengelöscht = new entfernenangebot();
            kundengelöscht.ShowDialog();
            ds.Clear();
            ada.Fill(ds, "Mitarbeiterübersicht");
            dgentfernen.DataSource = ds;
            dgentfernen.DataMember = "Mitarbeiterübersicht";
        }

        private void dgentfernen_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            clicked = true;
            if (e.RowIndex >= 0)
            {
                dgentfernen.CurrentRow.Selected = true;
                mnr = dgentfernen.Rows[e.RowIndex].Cells["Ang_id"].FormattedValue.ToString();
                label3.Text = dgentfernen.Rows[e.RowIndex].Cells["Ang_id"].FormattedValue.ToString();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
