﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class löschenansprechspartner : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;



        private DataGridViewRow selectedRow;
        public löschenansprechspartner(DataGridViewRow selectedRow) {
            InitializeComponent();
            this.selectedRow = selectedRow;
        }

        private void löschenansprechspartner_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";

                con.Open();
                con.Close();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            try {
                //der tabelname das kein - enthalten

                cmd = new OleDbCommand("select Anspr_id from Ansprechspartner", con);
                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                //liest die datensätze bis zum tabelle
                while (dr.Read()) {
                    cbx_id.Items.Add(dr.GetInt32(0));
                }
            }

            catch (Exception a) {
                MessageBox.Show("Tabellen-Zugriffsfehler(Sequentielles suchen):" + a);
            }
        }
        private void LöschenAbschließen() {
            try {
                // Führe die Logik zum Löschen der Daten durch
                // ...
                try {
                    cmd = new OleDbCommand("delete * from Ansprechspartner where Anspr_id=" + int.Parse(cbx_id.SelectedItem.ToString()) + "", con);
                    cmd.ExecuteNonQuery();
                    listefüllen();
                }
                catch (Exception a) {
                    MessageBox.Show("Fehler" + a);
                }
                // Setze DialogResult auf OK, um anzuzeigen, dass das Löschen erfolgreich war
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex) {
                MessageBox.Show("Fehler beim Löschen: " + ex.Message);
            }
        }
        private void listefüllen() {
            try {
                cbx_id.Items.Clear();
                //der tabelname das kein - enthalten

                cmd = new OleDbCommand("select * from Ansprechspartner order by Anspr_id asc", con);
                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                MessageBox.Show("geschafft");
                //liest die datensätze bis zum tabelle
                while (dr.Read()) {
                    cbx_id.Items.Add(dr.GetInt32(0));
                }
            }
            catch (Exception a) {
                MessageBox.Show("Tabellen-Zugriffsfehler(Sequentielles suchen):" + a);
            }

        }

        private void btn_speichern_Click(object sender, EventArgs e) {
            LöschenAbschließen();
        }

        private void cbx_id_SelectedIndexChanged(object sender, EventArgs e) {
            try {
                int vergleich = System.Convert.ToInt32(cbx_id.SelectedItem.ToString());

                //es wird ein neuer zugriff (direktzugriff) auf die datenbank ausführt

                cmd = new OleDbCommand("select * from Ansprechspartner where Anspr_id =" + vergleich, con);
                dr = cmd.ExecuteReader();


                dr.Read();
                tbx_avname.Text = dr.GetString(1);
                tbx_anname.Text = dr.GetString(2);
                tbx_tel.Text = dr.GetInt32(3).ToString();
                tbx_email.Text = dr.GetString(4);
                tbx_position.Text = dr.GetString(5);


            }
            catch (Exception a) {
                MessageBox.Show("tabellen-zugriffsfehler(direkt suchen)" + a);
            }
        }
    }
}
