﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class hinzufügenkunde : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        private mitarbeiteradd mainForm;
        private DataGridViewRow selectedRow;
        public hinzufügenkunde() {
            InitializeComponent();
            this.mainForm = mainForm;
        }
        public hinzufügenkunde(DataGridViewRow selectedRow) : this() {
            this.selectedRow = selectedRow;
           
        }

        private void hinzufügenkunde_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";

                con.Open();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
        }

        private void button1_Click(object sender, EventArgs e) {
            try {
                // Überprüfe, ob alle Textboxen ausgefüllt sind
                if (string.IsNullOrWhiteSpace(tbx_kdnr.Text) || string.IsNullOrWhiteSpace(tbx_kname.Text) || string.IsNullOrWhiteSpace(tbx_kust.Text) || string.IsNullOrWhiteSpace(tbx_kadresse.Text) || string.IsNullOrWhiteSpace(tbx_kliefadresse.Text)) {
                    // Zeige eine Meldung an, dass alle Felder ausgefüllt werden müssen
                    MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else {
                    // Führe die Datenbankoperation nur aus, wenn alle Felder ausgefüllt sind

                    // Überprüfe, ob die Kunden-ID bereits existiert
                    using (OleDbCommand checkCmd = new OleDbCommand("SELECT COUNT(*) FROM Kunden WHERE K_id = @K_id", con)) {
                        checkCmd.Parameters.AddWithValue("@K_id", Convert.ToInt32(tbx_kdnr.Text));

                        int existingRecords = (int)checkCmd.ExecuteScalar();

                        if (existingRecords > 0) {
                            // Die Kunden-ID existiert bereits, zeige eine entsprechende Meldung an
                            MessageBox.Show("Die Kunden-ID existiert bereits. Bitte wählen Sie eine andere ID.", "Duplikate verhindern", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                        else {
                            // Füge den neuen Datensatz ein
                            using (OleDbCommand insertCmd = new OleDbCommand("INSERT INTO Kunden(K_id, K_name, K_ust_id, K_adresse, K_lief_adresse) VALUES (@K_id, @K_name, @K_ust_id, @K_adresse, @K_lief_adresse)", con)) {
                                insertCmd.Parameters.AddWithValue("@K_id", Convert.ToInt32(tbx_kdnr.Text));
                                insertCmd.Parameters.AddWithValue("@K_name", tbx_kname.Text);
                                insertCmd.Parameters.AddWithValue("@K_ust_id", Convert.ToInt32(tbx_kust.Text));
                                insertCmd.Parameters.AddWithValue("@K_adresse", tbx_kadresse.Text);
                                insertCmd.Parameters.AddWithValue("@K_lief_adresse", tbx_kliefadresse.Text);

                                insertCmd.ExecuteNonQuery();
                            }

                            MessageBox.Show("Erfolgreich");

                            // Rufe die RefreshData-Methode des Hauptformulars auf
                            mainForm?.RefreshData();

                            this.DialogResult = DialogResult.OK;
                            this.Close();
                        }
                    }
                }
            }
            catch (Exception ex) {
                // Behandele Ausnahmen hier, wenn die Datenbankoperation fehlschlägt
                MessageBox.Show("Fehler beim Speichern der Daten: " + ex.Message, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            lblfehlermeldung();

        }
        public void meldung() {
            try {
               

                List<string> numericFieldsKunden = new List<string>();

               
                if (!int.TryParse(tbx_kdnr.Text, out _)) numericFieldsKunden.Add("Kundennummer");
                if (!int.TryParse(tbx_kust.Text, out _)) numericFieldsKunden.Add("USt-Id");


                if (numericFieldsKunden.Any()) {
                    MessageBox.Show($"Bitte geben Sie numerische Werte für die folgenden Felder ein: {string.Join(", ", numericFieldsKunden)}");
                    return;
                }

                if (string.IsNullOrWhiteSpace(tbx_kdnr.Text)
                    || string.IsNullOrWhiteSpace(tbx_kname.Text)
                    || string.IsNullOrWhiteSpace(tbx_kust.Text)
                    || string.IsNullOrWhiteSpace(tbx_kadresse.Text)
                    || string.IsNullOrWhiteSpace(tbx_kliefadresse.Text)) {

                    MessageBox.Show("Bitte füllen Sie alle erforderlichen Felder aus.");
                    return; 
                }

                MessageBox.Show("Erfolgreich");
            }
            catch (Exception a) {
                MessageBox.Show("Ein Fehler ist aufgetreten: " + a.Message);
            }

          

        }
        public void lblfehlermeldung() {

            if (tbx_kdnr.Text == "") {
                lbl_fehlermeldung.Visible = true;
                lbl_fehlermeldung.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lbl_fehlermeldung.Visible = false;
            }

            if (tbx_kname.Text == "") {
                lbl_fehlername.Visible = true;
                lbl_fehlername.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lbl_fehlername.Visible = false;
            }

            if (tbx_kust.Text == "") {
                lbl_fehlerust.Visible = true;
                lbl_fehlerust.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lbl_fehlerust.Visible = false;
            }

            if (tbx_kadresse.Text == "") {
                lbl_fehleradresse.Visible = true;
                lbl_fehleradresse.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lbl_fehleradresse.Visible = false;
            }

            if (tbx_kliefadresse.Text == "") {
                lbl_fehlerliefadresse.Visible = true;
                lbl_fehlerliefadresse.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lbl_fehlerliefadresse.Visible = false;
            }
        }
        private void button2_Click(object sender, EventArgs e) {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e) {
            this.Close();
        }
    }
}
