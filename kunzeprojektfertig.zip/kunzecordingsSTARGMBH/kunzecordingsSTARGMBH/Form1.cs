﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kunzecordingsSTARGMBH {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e) {
            userhome.Hide();
            userlogin.Show();
            userlogin.BringToFront();
        }

        private void btn_home_Click(object sender, EventArgs e) {
            userlogin.Hide();
            userhome.Show();
            userhome.BringToFront();
        }

        private void btn_create_Click(object sender, EventArgs e) {
            Application.Exit();
        }
    }
}
