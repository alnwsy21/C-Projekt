﻿
namespace kunzecordingsSTARGMBH
{
    partial class hinzufügenarbeitskarteunter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.lbl_fehlermeldung = new System.Windows.Forms.Label();
            this.tbx_pid = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_pe_probenform = new System.Windows.Forms.Label();
            this.lbl_pe_probenlage = new System.Windows.Forms.Label();
            this.lbl_PE_norm = new System.Windows.Forms.Label();
            this.lbl_pe_temp = new System.Windows.Forms.Label();
            this.tbx_pe_temp = new System.Windows.Forms.TextBox();
            this.tbx_pe_probenform = new System.Windows.Forms.TextBox();
            this.tbx_pe_norm = new System.Windows.Forms.TextBox();
            this.tbx_pe_probenlage = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbll_pe_typ_id = new System.Windows.Forms.Label();
            this.tbx_PE_typ_id = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.lbl_PE_id = new System.Windows.Forms.Label();
            this.tbx_Pe_id = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.lbl_PE_anzahl = new System.Windows.Forms.Label();
            this.tbx_PE_anzahl = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.lbl_mid = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lbl_pe_bemerkung = new System.Windows.Forms.Label();
            this.tbx_pe_bemerkung = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_anzeigen = new System.Windows.Forms.Button();
            this.lbl_P_ergebnis_text = new System.Windows.Forms.Label();
            this.tbx_P_ergebnis_text = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cbx_M_id = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(151)))), ((int)(((byte)(139)))));
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(857, 60);
            this.panel1.TabIndex = 9;
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(761, 32);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(84, 23);
            this.button3.TabIndex = 216;
            this.button3.Text = "zurück";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(102, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(551, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "Arbeitskarte_unter Hinzufügen";
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(761, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(84, 23);
            this.button2.TabIndex = 215;
            this.button2.Text = "beenden";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lbl_fehlermeldung
            // 
            this.lbl_fehlermeldung.AutoSize = true;
            this.lbl_fehlermeldung.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fehlermeldung.Location = new System.Drawing.Point(50, 121);
            this.lbl_fehlermeldung.Name = "lbl_fehlermeldung";
            this.lbl_fehlermeldung.Size = new System.Drawing.Size(130, 17);
            this.lbl_fehlermeldung.TabIndex = 139;
            this.lbl_fehlermeldung.Text = "Tragen sie was ein!";
            this.lbl_fehlermeldung.Visible = false;
            // 
            // tbx_pid
            // 
            this.tbx_pid.Location = new System.Drawing.Point(53, 137);
            this.tbx_pid.Name = "tbx_pid";
            this.tbx_pid.Size = new System.Drawing.Size(121, 20);
            this.tbx_pid.TabIndex = 138;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(50, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 20);
            this.label2.TabIndex = 137;
            this.label2.Text = "P_id";
            // 
            // lbl_pe_probenform
            // 
            this.lbl_pe_probenform.AutoSize = true;
            this.lbl_pe_probenform.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pe_probenform.Location = new System.Drawing.Point(289, 189);
            this.lbl_pe_probenform.Name = "lbl_pe_probenform";
            this.lbl_pe_probenform.Size = new System.Drawing.Size(130, 17);
            this.lbl_pe_probenform.TabIndex = 155;
            this.lbl_pe_probenform.Text = "Tragen sie was ein!";
            this.lbl_pe_probenform.Visible = false;
            // 
            // lbl_pe_probenlage
            // 
            this.lbl_pe_probenlage.AutoSize = true;
            this.lbl_pe_probenlage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pe_probenlage.Location = new System.Drawing.Point(289, 265);
            this.lbl_pe_probenlage.Name = "lbl_pe_probenlage";
            this.lbl_pe_probenlage.Size = new System.Drawing.Size(130, 17);
            this.lbl_pe_probenlage.TabIndex = 154;
            this.lbl_pe_probenlage.Text = "Tragen sie was ein!";
            this.lbl_pe_probenlage.Visible = false;
            // 
            // lbl_PE_norm
            // 
            this.lbl_PE_norm.AutoSize = true;
            this.lbl_PE_norm.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PE_norm.Location = new System.Drawing.Point(289, 336);
            this.lbl_PE_norm.Name = "lbl_PE_norm";
            this.lbl_PE_norm.Size = new System.Drawing.Size(130, 17);
            this.lbl_PE_norm.TabIndex = 153;
            this.lbl_PE_norm.Text = "Tragen sie was ein!";
            this.lbl_PE_norm.Visible = false;
            // 
            // lbl_pe_temp
            // 
            this.lbl_pe_temp.AutoSize = true;
            this.lbl_pe_temp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pe_temp.Location = new System.Drawing.Point(288, 121);
            this.lbl_pe_temp.Name = "lbl_pe_temp";
            this.lbl_pe_temp.Size = new System.Drawing.Size(130, 17);
            this.lbl_pe_temp.TabIndex = 152;
            this.lbl_pe_temp.Text = "Tragen sie was ein!";
            this.lbl_pe_temp.Visible = false;
            // 
            // tbx_pe_temp
            // 
            this.tbx_pe_temp.Location = new System.Drawing.Point(291, 134);
            this.tbx_pe_temp.Name = "tbx_pe_temp";
            this.tbx_pe_temp.Size = new System.Drawing.Size(121, 20);
            this.tbx_pe_temp.TabIndex = 151;
            // 
            // tbx_pe_probenform
            // 
            this.tbx_pe_probenform.Location = new System.Drawing.Point(292, 203);
            this.tbx_pe_probenform.Name = "tbx_pe_probenform";
            this.tbx_pe_probenform.Size = new System.Drawing.Size(121, 20);
            this.tbx_pe_probenform.TabIndex = 150;
            // 
            // tbx_pe_norm
            // 
            this.tbx_pe_norm.Location = new System.Drawing.Point(292, 350);
            this.tbx_pe_norm.Name = "tbx_pe_norm";
            this.tbx_pe_norm.Size = new System.Drawing.Size(121, 20);
            this.tbx_pe_norm.TabIndex = 149;
            // 
            // tbx_pe_probenlage
            // 
            this.tbx_pe_probenlage.Location = new System.Drawing.Point(292, 281);
            this.tbx_pe_probenlage.Name = "tbx_pe_probenlage";
            this.tbx_pe_probenlage.Size = new System.Drawing.Size(121, 20);
            this.tbx_pe_probenlage.TabIndex = 148;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(289, 246);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(133, 20);
            this.label10.TabIndex = 147;
            this.label10.Text = "Pe_probenlage";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(289, 320);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 20);
            this.label9.TabIndex = 146;
            this.label9.Text = "Pe_norm";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(288, 101);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 20);
            this.label7.TabIndex = 145;
            this.label7.Text = "Pe_temp";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(289, 174);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(136, 20);
            this.label6.TabIndex = 144;
            this.label6.Text = "Pe_probenform";
            // 
            // lbll_pe_typ_id
            // 
            this.lbll_pe_typ_id.AutoSize = true;
            this.lbll_pe_typ_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbll_pe_typ_id.Location = new System.Drawing.Point(51, 274);
            this.lbll_pe_typ_id.Name = "lbll_pe_typ_id";
            this.lbll_pe_typ_id.Size = new System.Drawing.Size(130, 17);
            this.lbll_pe_typ_id.TabIndex = 162;
            this.lbll_pe_typ_id.Text = "Tragen sie was ein!";
            this.lbll_pe_typ_id.Visible = false;
            // 
            // tbx_PE_typ_id
            // 
            this.tbx_PE_typ_id.Location = new System.Drawing.Point(54, 288);
            this.tbx_PE_typ_id.Name = "tbx_PE_typ_id";
            this.tbx_PE_typ_id.Size = new System.Drawing.Size(121, 20);
            this.tbx_PE_typ_id.TabIndex = 161;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(51, 258);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(91, 20);
            this.label15.TabIndex = 160;
            this.label15.Text = "Pe_typ_id";
            // 
            // lbl_PE_id
            // 
            this.lbl_PE_id.AutoSize = true;
            this.lbl_PE_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PE_id.Location = new System.Drawing.Point(50, 202);
            this.lbl_PE_id.Name = "lbl_PE_id";
            this.lbl_PE_id.Size = new System.Drawing.Size(130, 17);
            this.lbl_PE_id.TabIndex = 159;
            this.lbl_PE_id.Text = "Tragen sie was ein!";
            this.lbl_PE_id.Visible = false;
            // 
            // tbx_Pe_id
            // 
            this.tbx_Pe_id.Location = new System.Drawing.Point(53, 216);
            this.tbx_Pe_id.Name = "tbx_Pe_id";
            this.tbx_Pe_id.Size = new System.Drawing.Size(121, 20);
            this.tbx_Pe_id.TabIndex = 158;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(50, 186);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(56, 20);
            this.label13.TabIndex = 157;
            this.label13.Text = "Pe_id";
            // 
            // lbl_PE_anzahl
            // 
            this.lbl_PE_anzahl.AutoSize = true;
            this.lbl_PE_anzahl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PE_anzahl.Location = new System.Drawing.Point(52, 350);
            this.lbl_PE_anzahl.Name = "lbl_PE_anzahl";
            this.lbl_PE_anzahl.Size = new System.Drawing.Size(130, 17);
            this.lbl_PE_anzahl.TabIndex = 165;
            this.lbl_PE_anzahl.Text = "Tragen sie was ein!";
            this.lbl_PE_anzahl.Visible = false;
            // 
            // tbx_PE_anzahl
            // 
            this.tbx_PE_anzahl.Location = new System.Drawing.Point(55, 364);
            this.tbx_PE_anzahl.Name = "tbx_PE_anzahl";
            this.tbx_PE_anzahl.Size = new System.Drawing.Size(121, 20);
            this.tbx_PE_anzahl.TabIndex = 164;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(52, 334);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(96, 20);
            this.label12.TabIndex = 163;
            this.label12.Text = "Pe_anzahl";
            // 
            // lbl_mid
            // 
            this.lbl_mid.AutoSize = true;
            this.lbl_mid.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mid.Location = new System.Drawing.Point(579, 205);
            this.lbl_mid.Name = "lbl_mid";
            this.lbl_mid.Size = new System.Drawing.Size(130, 17);
            this.lbl_mid.TabIndex = 171;
            this.lbl_mid.Text = "Tragen sie was ein!";
            this.lbl_mid.Visible = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(579, 189);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(49, 20);
            this.label17.TabIndex = 169;
            this.label17.Text = "M_id";
            // 
            // lbl_pe_bemerkung
            // 
            this.lbl_pe_bemerkung.AutoSize = true;
            this.lbl_pe_bemerkung.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pe_bemerkung.Location = new System.Drawing.Point(580, 120);
            this.lbl_pe_bemerkung.Name = "lbl_pe_bemerkung";
            this.lbl_pe_bemerkung.Size = new System.Drawing.Size(130, 17);
            this.lbl_pe_bemerkung.TabIndex = 168;
            this.lbl_pe_bemerkung.Text = "Tragen sie was ein!";
            this.lbl_pe_bemerkung.Visible = false;
            // 
            // tbx_pe_bemerkung
            // 
            this.tbx_pe_bemerkung.Location = new System.Drawing.Point(583, 136);
            this.tbx_pe_bemerkung.Name = "tbx_pe_bemerkung";
            this.tbx_pe_bemerkung.Size = new System.Drawing.Size(121, 20);
            this.tbx_pe_bemerkung.TabIndex = 167;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(580, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(132, 20);
            this.label3.TabIndex = 166;
            this.label3.Text = "Pe_bemerkung";
            // 
            // btn_anzeigen
            // 
            this.btn_anzeigen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_anzeigen.Location = new System.Drawing.Point(575, 342);
            this.btn_anzeigen.Name = "btn_anzeigen";
            this.btn_anzeigen.Size = new System.Drawing.Size(129, 33);
            this.btn_anzeigen.TabIndex = 172;
            this.btn_anzeigen.Text = "Hinzufügen";
            this.btn_anzeigen.UseVisualStyleBackColor = true;
            this.btn_anzeigen.Click += new System.EventHandler(this.btn_anzeigen_Click);
            // 
            // lbl_P_ergebnis_text
            // 
            this.lbl_P_ergebnis_text.AutoSize = true;
            this.lbl_P_ergebnis_text.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_P_ergebnis_text.Location = new System.Drawing.Point(579, 262);
            this.lbl_P_ergebnis_text.Name = "lbl_P_ergebnis_text";
            this.lbl_P_ergebnis_text.Size = new System.Drawing.Size(130, 17);
            this.lbl_P_ergebnis_text.TabIndex = 175;
            this.lbl_P_ergebnis_text.Text = "Tragen sie was ein!";
            this.lbl_P_ergebnis_text.Visible = false;
            // 
            // tbx_P_ergebnis_text
            // 
            this.tbx_P_ergebnis_text.Location = new System.Drawing.Point(582, 276);
            this.tbx_P_ergebnis_text.Name = "tbx_P_ergebnis_text";
            this.tbx_P_ergebnis_text.Size = new System.Drawing.Size(121, 20);
            this.tbx_P_ergebnis_text.TabIndex = 174;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(579, 246);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(144, 20);
            this.label5.TabIndex = 173;
            this.label5.Text = "P_ergebnis_text";
            // 
            // cbx_M_id
            // 
            this.cbx_M_id.FormattingEnabled = true;
            this.cbx_M_id.Location = new System.Drawing.Point(584, 225);
            this.cbx_M_id.Name = "cbx_M_id";
            this.cbx_M_id.Size = new System.Drawing.Size(121, 21);
            this.cbx_M_id.TabIndex = 176;
            this.cbx_M_id.SelectedIndexChanged += new System.EventHandler(this.cbx_M_id_SelectedIndexChanged);
            // 
            // hinzufügenarbeitskarteunter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(857, 393);
            this.Controls.Add(this.cbx_M_id);
            this.Controls.Add(this.lbl_P_ergebnis_text);
            this.Controls.Add(this.tbx_P_ergebnis_text);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btn_anzeigen);
            this.Controls.Add(this.lbl_mid);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.lbl_pe_bemerkung);
            this.Controls.Add(this.tbx_pe_bemerkung);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbl_PE_anzahl);
            this.Controls.Add(this.tbx_PE_anzahl);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.lbll_pe_typ_id);
            this.Controls.Add(this.tbx_PE_typ_id);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.lbl_PE_id);
            this.Controls.Add(this.tbx_Pe_id);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.lbl_pe_probenform);
            this.Controls.Add(this.lbl_pe_probenlage);
            this.Controls.Add(this.lbl_PE_norm);
            this.Controls.Add(this.lbl_pe_temp);
            this.Controls.Add(this.tbx_pe_temp);
            this.Controls.Add(this.tbx_pe_probenform);
            this.Controls.Add(this.tbx_pe_norm);
            this.Controls.Add(this.tbx_pe_probenlage);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lbl_fehlermeldung);
            this.Controls.Add(this.tbx_pid);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Name = "hinzufügenarbeitskarteunter";
            this.Text = "hinzufügenarbeitskarteunter";
            this.Load += new System.EventHandler(this.hinzufügenarbeitskarteunter_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_fehlermeldung;
        private System.Windows.Forms.TextBox tbx_pid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_pe_probenform;
        private System.Windows.Forms.Label lbl_pe_probenlage;
        private System.Windows.Forms.Label lbl_PE_norm;
        private System.Windows.Forms.Label lbl_pe_temp;
        private System.Windows.Forms.TextBox tbx_pe_temp;
        private System.Windows.Forms.TextBox tbx_pe_probenform;
        private System.Windows.Forms.TextBox tbx_pe_norm;
        private System.Windows.Forms.TextBox tbx_pe_probenlage;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbll_pe_typ_id;
        private System.Windows.Forms.TextBox tbx_PE_typ_id;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lbl_PE_id;
        private System.Windows.Forms.TextBox tbx_Pe_id;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lbl_PE_anzahl;
        private System.Windows.Forms.TextBox tbx_PE_anzahl;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lbl_mid;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lbl_pe_bemerkung;
        private System.Windows.Forms.TextBox tbx_pe_bemerkung;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_anzeigen;
        private System.Windows.Forms.Label lbl_P_ergebnis_text;
        private System.Windows.Forms.TextBox tbx_P_ergebnis_text;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbx_M_id;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
    }
}