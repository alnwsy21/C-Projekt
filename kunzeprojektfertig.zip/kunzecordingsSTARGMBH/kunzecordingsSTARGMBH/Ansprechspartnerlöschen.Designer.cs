﻿
namespace kunzecordingsSTARGMBH {
    partial class Ansprechspartnerlöschen {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && ( components != null )) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.panel2 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.datagriedanzeigen = new System.Windows.Forms.DataGridView();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagriedanzeigen)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(151)))), ((int)(((byte)(139)))));
            this.panel2.Controls.Add(this.label7);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 60);
            this.panel2.TabIndex = 60;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(141, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(387, 33);
            this.label7.TabIndex = 0;
            this.label7.Text = "Ansprechspartner Löschen";
            // 
            // datagriedanzeigen
            // 
            this.datagriedanzeigen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagriedanzeigen.Location = new System.Drawing.Point(22, 82);
            this.datagriedanzeigen.Name = "datagriedanzeigen";
            this.datagriedanzeigen.Size = new System.Drawing.Size(690, 150);
            this.datagriedanzeigen.TabIndex = 61;
            this.datagriedanzeigen.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagriedanzeigen_CellDoubleClick);
            // 
            // Ansprechspartnerlöschen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.datagriedanzeigen);
            this.Controls.Add(this.panel2);
            this.Name = "Ansprechspartnerlöschen";
            this.Text = "Ansprechspartnerlöschen";
            this.Load += new System.EventHandler(this.Ansprechspartnerlöschen_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagriedanzeigen)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView datagriedanzeigen;
    }
}