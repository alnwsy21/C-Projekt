﻿
namespace kunzecordingsSTARGMBH {
    partial class mitarbeiterhinzufügen {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.lblfehlerpass = new System.Windows.Forms.Label();
            this.lblfehleradmin = new System.Windows.Forms.Label();
            this.lblfehlervname = new System.Windows.Forms.Label();
            this.lblfehlernname = new System.Windows.Forms.Label();
            this.lbl_fehlermeldung = new System.Windows.Forms.Label();
            this.checkbox_show = new System.Windows.Forms.CheckBox();
            this.tbx_mnr = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_anzeigen = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tbx_mlp = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbx_mlname = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbx_nname = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbx_vname = new System.Windows.Forms.TextBox();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(151)))), ((int)(((byte)(139)))));
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(570, 60);
            this.panel2.TabIndex = 57;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(51, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(415, 42);
            this.label1.TabIndex = 3;
            this.label1.Text = "Mitarbeiter Hinzufügen";
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(474, 32);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(84, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "zurück";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(474, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(84, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "beenden";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lblfehlerpass
            // 
            this.lblfehlerpass.AutoSize = true;
            this.lblfehlerpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfehlerpass.Location = new System.Drawing.Point(324, 210);
            this.lblfehlerpass.Name = "lblfehlerpass";
            this.lblfehlerpass.Size = new System.Drawing.Size(130, 17);
            this.lblfehlerpass.TabIndex = 74;
            this.lblfehlerpass.Text = "Tragen sie was ein!";
            this.lblfehlerpass.Visible = false;
            // 
            // lblfehleradmin
            // 
            this.lblfehleradmin.AutoSize = true;
            this.lblfehleradmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfehleradmin.Location = new System.Drawing.Point(324, 113);
            this.lblfehleradmin.Name = "lblfehleradmin";
            this.lblfehleradmin.Size = new System.Drawing.Size(130, 17);
            this.lblfehleradmin.TabIndex = 73;
            this.lblfehleradmin.Text = "Tragen sie was ein!";
            this.lblfehleradmin.Visible = false;
            // 
            // lblfehlervname
            // 
            this.lblfehlervname.AutoSize = true;
            this.lblfehlervname.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfehlervname.Location = new System.Drawing.Point(54, 210);
            this.lblfehlervname.Name = "lblfehlervname";
            this.lblfehlervname.Size = new System.Drawing.Size(130, 17);
            this.lblfehlervname.TabIndex = 72;
            this.lblfehlervname.Text = "Tragen sie was ein!";
            this.lblfehlervname.Visible = false;
            // 
            // lblfehlernname
            // 
            this.lblfehlernname.AutoSize = true;
            this.lblfehlernname.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfehlernname.Location = new System.Drawing.Point(54, 310);
            this.lblfehlernname.Name = "lblfehlernname";
            this.lblfehlernname.Size = new System.Drawing.Size(130, 17);
            this.lblfehlernname.TabIndex = 71;
            this.lblfehlernname.Text = "Tragen sie was ein!";
            this.lblfehlernname.Visible = false;
            // 
            // lbl_fehlermeldung
            // 
            this.lbl_fehlermeldung.AutoSize = true;
            this.lbl_fehlermeldung.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fehlermeldung.Location = new System.Drawing.Point(54, 113);
            this.lbl_fehlermeldung.Name = "lbl_fehlermeldung";
            this.lbl_fehlermeldung.Size = new System.Drawing.Size(130, 17);
            this.lbl_fehlermeldung.TabIndex = 70;
            this.lbl_fehlermeldung.Text = "Tragen sie was ein!";
            this.lbl_fehlermeldung.Visible = false;
            // 
            // checkbox_show
            // 
            this.checkbox_show.AutoSize = true;
            this.checkbox_show.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkbox_show.Location = new System.Drawing.Point(327, 283);
            this.checkbox_show.Name = "checkbox_show";
            this.checkbox_show.Size = new System.Drawing.Size(171, 21);
            this.checkbox_show.TabIndex = 69;
            this.checkbox_show.Text = "Password Anzeigen";
            this.checkbox_show.UseVisualStyleBackColor = true;
            this.checkbox_show.CheckedChanged += new System.EventHandler(this.checkbox_show_CheckedChanged);
            // 
            // tbx_mnr
            // 
            this.tbx_mnr.Location = new System.Drawing.Point(57, 129);
            this.tbx_mnr.Name = "tbx_mnr";
            this.tbx_mnr.Size = new System.Drawing.Size(106, 20);
            this.tbx_mnr.TabIndex = 68;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(324, 182);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(246, 20);
            this.label5.TabIndex = 61;
            this.label5.Text = "Mitarbeiter_login_password:";
            // 
            // btn_anzeigen
            // 
            this.btn_anzeigen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_anzeigen.Location = new System.Drawing.Point(327, 313);
            this.btn_anzeigen.Name = "btn_anzeigen";
            this.btn_anzeigen.Size = new System.Drawing.Size(129, 33);
            this.btn_anzeigen.TabIndex = 67;
            this.btn_anzeigen.Text = "Hinzufügen";
            this.btn_anzeigen.UseVisualStyleBackColor = true;
            this.btn_anzeigen.Click += new System.EventHandler(this.btn_anzeigen_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(54, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(131, 20);
            this.label2.TabIndex = 58;
            this.label2.Text = "Mitarbeiter_id:";
            // 
            // tbx_mlp
            // 
            this.tbx_mlp.Location = new System.Drawing.Point(327, 226);
            this.tbx_mlp.Name = "tbx_mlp";
            this.tbx_mlp.Size = new System.Drawing.Size(125, 20);
            this.tbx_mlp.TabIndex = 66;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(324, 94);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(211, 20);
            this.label3.TabIndex = 59;
            this.label3.Text = "Mitarbeiter_login_name:";
            // 
            // tbx_mlname
            // 
            this.tbx_mlname.Location = new System.Drawing.Point(327, 129);
            this.tbx_mlname.Name = "tbx_mlname";
            this.tbx_mlname.Size = new System.Drawing.Size(125, 20);
            this.tbx_mlname.TabIndex = 65;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(54, 182);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(170, 20);
            this.label4.TabIndex = 60;
            this.label4.Text = "Mitarbeiter_vname:";
            // 
            // tbx_nname
            // 
            this.tbx_nname.Location = new System.Drawing.Point(57, 326);
            this.tbx_nname.Name = "tbx_nname";
            this.tbx_nname.Size = new System.Drawing.Size(106, 20);
            this.tbx_nname.TabIndex = 64;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(54, 284);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(171, 20);
            this.label6.TabIndex = 62;
            this.label6.Text = "Mitarbeiter_nname:";
            // 
            // tbx_vname
            // 
            this.tbx_vname.Location = new System.Drawing.Point(57, 226);
            this.tbx_vname.Name = "tbx_vname";
            this.tbx_vname.Size = new System.Drawing.Size(106, 20);
            this.tbx_vname.TabIndex = 63;
            // 
            // mitarbeiterhinzufügen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(570, 420);
            this.Controls.Add(this.lblfehlerpass);
            this.Controls.Add(this.lblfehleradmin);
            this.Controls.Add(this.lblfehlervname);
            this.Controls.Add(this.lblfehlernname);
            this.Controls.Add(this.lbl_fehlermeldung);
            this.Controls.Add(this.checkbox_show);
            this.Controls.Add(this.tbx_mnr);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btn_anzeigen);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbx_mlp);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbx_mlname);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbx_nname);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbx_vname);
            this.Controls.Add(this.panel2);
            this.Name = "mitarbeiterhinzufügen";
            this.Text = "MitarbeiterBearbeitenForm";
            this.Load += new System.EventHandler(this.MitarbeiterBearbeitenForm_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblfehlerpass;
        private System.Windows.Forms.Label lblfehleradmin;
        private System.Windows.Forms.Label lblfehlervname;
        private System.Windows.Forms.Label lblfehlernname;
        private System.Windows.Forms.Label lbl_fehlermeldung;
        private System.Windows.Forms.CheckBox checkbox_show;
        private System.Windows.Forms.TextBox tbx_mnr;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_anzeigen;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbx_mlp;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbx_mlname;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbx_nname;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbx_vname;
    }
}