﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace kunzecordingsSTARGMBH {
    public partial class mitarbeiterlöschen : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Kunze.accdb;";
        public mitarbeiterlöschen() {
            InitializeComponent();
            datagriedanzeigen.CellDoubleClick += new DataGridViewCellEventHandler(dataGridView1_CellDoubleClick);
        }

        private void mitarbeiterlöschen_Load(object sender, EventArgs e) {
            LoadData();
        }
        private void LoadData() {
            using (OleDbConnection connection = new OleDbConnection(connectionString)) {
                connection.Open();
                string query = "SELECT * FROM Mitarbeiter";

                using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection)) {
                    dataSet = new DataSet();
                    adapter.Fill(dataSet, "DeineTabelle");
                    datagriedanzeigen.DataSource = dataSet.Tables["DeineTabelle"];
                }
            }
        }
        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            if (e.RowIndex >= 0) {
                DataGridViewRow selectedRow = datagriedanzeigen.Rows[e.RowIndex];

              löschenmitarbeiter löschenForm = new löschenmitarbeiter(selectedRow);
                DialogResult result = löschenForm.ShowDialog();

                if (result == DialogResult.OK) {
                    // Lade die Daten erneut, um die DataGridView zu aktualisieren
                    LoadData();
                }
            }
        }
    }
}
