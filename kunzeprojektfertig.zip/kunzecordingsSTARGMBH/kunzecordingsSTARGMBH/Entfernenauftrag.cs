﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class Entfernenauftrag : Form {
        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = null;
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();


        bool clicked;
        string mnr = "";
        public Entfernenauftrag() {
            InitializeComponent();
        }

        private void Entfernenauftrag_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source= Kunze.accdb";
                con.Open();
                con.Close();
            }
            catch {
                MessageBox.Show("Die Datenbank konnte nicht geöffnet werden");
            }
            try {
                con.Open();
                ada = new OleDbDataAdapter("select * from Auftrag where Auf_gelöscht = true", con);
                ada.Fill(ds, "Auftrag");
                dgentfernt.DataSource = ds;
                dgentfernt.DataMember = "Auftrag";
                con.Close();
            
            }
            catch {
                MessageBox.Show("Der Datensatz konnte nicht gelöscht werden");
            }
        }

        private void button1_Click(object sender, EventArgs e) {
            try
            {
                if (dgentfernt.SelectedRows.Count > 0)
                {
                    con.Open();
                    int mnr = Convert.ToInt32(dgentfernt.SelectedRows[0].Cells["Auf_id"].Value);
                    cmd = new OleDbCommand("Update Auftrag set Auf_gelöscht = false where Auf_id = " + mnr, con);
                    cmd.ExecuteNonQuery();
                    ds.Clear();
                    ada.Fill(ds, "Kundengelöscht");
                    dgentfernt.DataSource = ds;
                    dgentfernt.DataMember = "Kundengelöscht";
                    con.Close();
                }
                else
                {
                    MessageBox.Show("Bitte wählen Sie einen Datensatz aus, um ihn zu aktualisieren.");
                }
            }
            catch (Exception a)
            {
                MessageBox.Show("Der Datensatz konnte nicht hinzugefügt werden" + a);
            }

        }

        private void dgentfernt_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            clicked = true;
            if (e.RowIndex >= 0) {
                dgentfernt.CurrentRow.Selected = true;
                mnr = dgentfernt.Rows[e.RowIndex].Cells["Auf_id"].FormattedValue.ToString();
                label2.Text = dgentfernt.Rows[e.RowIndex].Cells["Auf_id"].FormattedValue.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
