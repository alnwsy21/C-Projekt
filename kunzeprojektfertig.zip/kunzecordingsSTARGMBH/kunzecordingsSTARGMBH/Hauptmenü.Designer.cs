﻿
namespace kunzecordingsSTARGMBH {
    partial class Hauptmenü {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && ( components != null )) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Hauptmenü));
            this.panel1 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.btn_rechnung = new System.Windows.Forms.Button();
            this.btn_angebot = new System.Windows.Forms.Button();
            this.btn_prüfung = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.arbeitskarte = new kunzecordingsSTARGMBH.Arbeitskarte();
            this.angebot = new kunzecordingsSTARGMBH.Angebot();
            this.auftrag = new kunzecordingsSTARGMBH.Auftrag();
            this.stamdaten = new kunzecordingsSTARGMBH.STAMMdaten();
            this.usermitarbeiter = new kunzecordingsSTARGMBH.USERmitarbeiter();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.btn_rechnung);
            this.panel1.Controls.Add(this.btn_angebot);
            this.panel1.Controls.Add(this.btn_prüfung);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 563);
            this.panel1.TabIndex = 4;
            // 
            // button2
            // 
            this.button2.Dock = System.Windows.Forms.DockStyle.Top;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Gainsboro;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(0, 420);
            this.button2.Name = "button2";
            this.button2.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.button2.Size = new System.Drawing.Size(200, 60);
            this.button2.TabIndex = 8;
            this.button2.Text = "   Beenden";
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Gainsboro;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(0, 360);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.button1.Size = new System.Drawing.Size(200, 60);
            this.button1.TabIndex = 7;
            this.button1.Text = "   Abmelden";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button5
            // 
            this.button5.Dock = System.Windows.Forms.DockStyle.Top;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.Gainsboro;
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(0, 300);
            this.button5.Name = "button5";
            this.button5.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.button5.Size = new System.Drawing.Size(200, 60);
            this.button5.TabIndex = 5;
            this.button5.Text = "   Mitarbeiter";
            this.button5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Dock = System.Windows.Forms.DockStyle.Top;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.Gainsboro;
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(0, 240);
            this.button4.Name = "button4";
            this.button4.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.button4.Size = new System.Drawing.Size(200, 60);
            this.button4.TabIndex = 4;
            this.button4.Text = "   Stammdaten";
            this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // btn_rechnung
            // 
            this.btn_rechnung.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_rechnung.FlatAppearance.BorderSize = 0;
            this.btn_rechnung.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_rechnung.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_rechnung.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_rechnung.Image = ((System.Drawing.Image)(resources.GetObject("btn_rechnung.Image")));
            this.btn_rechnung.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_rechnung.Location = new System.Drawing.Point(0, 180);
            this.btn_rechnung.Name = "btn_rechnung";
            this.btn_rechnung.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btn_rechnung.Size = new System.Drawing.Size(200, 60);
            this.btn_rechnung.TabIndex = 3;
            this.btn_rechnung.Text = "   Auftrag";
            this.btn_rechnung.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_rechnung.UseVisualStyleBackColor = true;
            this.btn_rechnung.Click += new System.EventHandler(this.btn_rechnung_Click);
            // 
            // btn_angebot
            // 
            this.btn_angebot.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_angebot.FlatAppearance.BorderSize = 0;
            this.btn_angebot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_angebot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_angebot.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_angebot.Image = ((System.Drawing.Image)(resources.GetObject("btn_angebot.Image")));
            this.btn_angebot.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_angebot.Location = new System.Drawing.Point(0, 120);
            this.btn_angebot.Name = "btn_angebot";
            this.btn_angebot.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btn_angebot.Size = new System.Drawing.Size(200, 60);
            this.btn_angebot.TabIndex = 2;
            this.btn_angebot.Text = "   Angebot";
            this.btn_angebot.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_angebot.UseVisualStyleBackColor = true;
            this.btn_angebot.Click += new System.EventHandler(this.btn_angebot_Click);
            // 
            // btn_prüfung
            // 
            this.btn_prüfung.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_prüfung.FlatAppearance.BorderSize = 0;
            this.btn_prüfung.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_prüfung.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_prüfung.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_prüfung.Image = ((System.Drawing.Image)(resources.GetObject("btn_prüfung.Image")));
            this.btn_prüfung.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_prüfung.Location = new System.Drawing.Point(0, 60);
            this.btn_prüfung.Name = "btn_prüfung";
            this.btn_prüfung.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btn_prüfung.Size = new System.Drawing.Size(200, 60);
            this.btn_prüfung.TabIndex = 1;
            this.btn_prüfung.Text = "   Arbeitskarte";
            this.btn_prüfung.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_prüfung.UseVisualStyleBackColor = true;
            this.btn_prüfung.Click += new System.EventHandler(this.btn_prüfung_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(58)))));
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.ForeColor = System.Drawing.Color.Gainsboro;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.panel2.Size = new System.Drawing.Size(200, 60);
            this.panel2.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(55, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hauptmenü";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.arbeitskarte);
            this.panel3.Controls.Add(this.angebot);
            this.panel3.Controls.Add(this.auftrag);
            this.panel3.Controls.Add(this.stamdaten);
            this.panel3.Controls.Add(this.usermitarbeiter);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(200, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(926, 563);
            this.panel3.TabIndex = 5;
            // 
            // arbeitskarte
            // 
            this.arbeitskarte.Location = new System.Drawing.Point(0, 0);
            this.arbeitskarte.Name = "arbeitskarte";
            this.arbeitskarte.Size = new System.Drawing.Size(926, 563);
            this.arbeitskarte.TabIndex = 4;
            this.arbeitskarte.Visible = false;
            // 
            // angebot
            // 
            this.angebot.Location = new System.Drawing.Point(0, 0);
            this.angebot.Name = "angebot";
            this.angebot.Size = new System.Drawing.Size(926, 563);
            this.angebot.TabIndex = 3;
            this.angebot.Visible = false;
            // 
            // auftrag
            // 
            this.auftrag.Location = new System.Drawing.Point(0, 0);
            this.auftrag.Name = "auftrag";
            this.auftrag.Size = new System.Drawing.Size(926, 563);
            this.auftrag.TabIndex = 2;
            this.auftrag.Visible = false;
            // 
            // stamdaten
            // 
            this.stamdaten.Location = new System.Drawing.Point(0, 0);
            this.stamdaten.Name = "stamdaten";
            this.stamdaten.Size = new System.Drawing.Size(926, 563);
            this.stamdaten.TabIndex = 1;
            this.stamdaten.Visible = false;
            // 
            // usermitarbeiter
            // 
            this.usermitarbeiter.Location = new System.Drawing.Point(0, 0);
            this.usermitarbeiter.Name = "usermitarbeiter";
            this.usermitarbeiter.Size = new System.Drawing.Size(926, 563);
            this.usermitarbeiter.TabIndex = 0;
            this.usermitarbeiter.Visible = false;
            this.usermitarbeiter.Load += new System.EventHandler(this.usermitarbeiter_Load);
            // 
            // Hauptmenü
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1126, 563);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Name = "Hauptmenü";
            this.Text = "Hauptmenü";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btn_rechnung;
        private System.Windows.Forms.Button btn_angebot;
        private System.Windows.Forms.Button btn_prüfung;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private USERmitarbeiter usermitarbeiter;
        private STAMMdaten stamdaten;
        private Auftrag auftrag;
        private Angebot angebot;
        private Arbeitskarte arbeitskarte;
    }
}