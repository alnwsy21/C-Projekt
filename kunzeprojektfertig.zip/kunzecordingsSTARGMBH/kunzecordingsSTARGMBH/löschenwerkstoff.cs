﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class löschenwerkstoff : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;



        private DataGridViewRow selectedRow;

        public löschenwerkstoff(DataGridViewRow selectedRow) {
            InitializeComponent();
            this.selectedRow = selectedRow;
        }

        private void löschenwerkstoff_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";
                con.Open();
               
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            try {
                //der tabelname das kein - enthalten

                cmd = new OleDbCommand("select W_id from Werkstoff", con);
                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                //liest die datensätze bis zum tabelle
                while (dr.Read()) {
                    cbx_wnr.Items.Add(dr.GetInt32(0));
                }
            }

            catch (Exception a) {
                MessageBox.Show("Tabellen-Zugriffsfehler(Sequentielles suchen):" + a);
            }
        }
        private void LöschenAbschließen() {
            try {
                // Führe die Logik zum Löschen der Daten durch
                // ...
                try {
                    cmd = new OleDbCommand("delete * from Werkstoff where W_id=" + int.Parse(cbx_wnr.SelectedItem.ToString()) + "", con);
                    cmd.ExecuteNonQuery();
                    listefüllen();
                }
                catch (Exception a) {
                    MessageBox.Show("Fehler" + a);
                }
                // Setze DialogResult auf OK, um anzuzeigen, dass das Löschen erfolgreich war
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex) {
                MessageBox.Show("Fehler beim Löschen: " + ex.Message);
            }
        }
        private void listefüllen() {
            try {
                cbx_wnr.Items.Clear();
                //der tabelname das kein - enthalten

                cmd = new OleDbCommand("select * from Werkstoff order by W_id asc", con);
                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                MessageBox.Show("geschafft");
                //liest die datensätze bis zum tabelle
                while (dr.Read()) {
                    cbx_wnr.Items.Add(dr.GetInt32(0));
                }
            }
            catch (Exception a) {
                MessageBox.Show("Tabellen-Zugriffsfehler(Sequentielles suchen):" + a);
            }

        }

        private void btn_anzeigen_Click(object sender, EventArgs e) {
            LöschenAbschließen();
        }

        private void cbx_wnr_SelectedIndexChanged(object sender, EventArgs e) {
            try {
                int vergleich = System.Convert.ToInt32(cbx_wnr.SelectedItem.ToString());

                //es wird ein neuer zugriff (direktzugriff) auf die datenbank ausführt

                cmd = new OleDbCommand("select * from Werkstoff where W_id =" + vergleich, con);
                dr = cmd.ExecuteReader();


                dr.Read();
                tbx_wname.Text = dr.GetString(1);
                tbx_wkurz.Text = dr.GetString(2);
                tbx_wkennzeichen.Text = dr.GetString(3);
                tbx_woberfläche.Text = dr.GetInt32(4).ToString();
                tbx_whöhe.Text = dr.GetInt32(5).ToString();
                tbx_wbreite.Text = dr.GetInt32(6).ToString();
                tbx_wlänge.Text = dr.GetInt32(7).ToString();
                tbx_wgewicht.Text = dr.GetInt32(8).ToString();

            }
            catch (Exception a) {
                MessageBox.Show("tabellen-zugriffsfehler(direkt suchen)" + a);
            }
        }

        private void button1_Click(object sender, EventArgs e) {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e) {
            Application.Exit();
        }
    }
}
