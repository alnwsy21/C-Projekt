﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class mitarbeiterbearbeiten : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Kunze.accdb;";
        public mitarbeiterbearbeiten() {
            InitializeComponent();
           dgbearbeiten.CellDoubleClick += new DataGridViewCellEventHandler(dataGridView1_CellDoubleClick);
        }

        private void mitarbeiterbearbeiten_Load(object sender, EventArgs e) {
            LoadData();
        }
        private void LoadData() {
            using (OleDbConnection connection = new OleDbConnection(connectionString)) {
                connection.Open();
                string query = "SELECT M_id, M_vname, M_nname, M_pass, M_admin FROM Mitarbeiter";

                using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection)) {
                    dataSet = new DataSet();
                    adapter.Fill(dataSet, "DeineTabelle");
                    dgbearbeiten.DataSource = dataSet.Tables["DeineTabelle"];
                }
            }
            dgbearbeiten.Columns["M_id"].HeaderText = "Nummer";
            dgbearbeiten.Columns["M_vname"].HeaderText = "Vorname";
            dgbearbeiten.Columns["M_pass"].HeaderText = "Password";
            dgbearbeiten.Columns["M_admin"].HeaderText = "Benutzernamen";
            dgbearbeiten.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
        }
        public void RefreshData() {
            LoadData();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            if (e.RowIndex >= 0) {
                DataGridViewRow selectedRow = dgbearbeiten.Rows[e.RowIndex];

              bearbeitenmitarbeiter bearbeitenForm = new bearbeitenmitarbeiter(selectedRow, connectionString);
                DialogResult result = bearbeitenForm.ShowDialog();

                if (result == DialogResult.OK) {
                    // Lade die Daten erneut
                    LoadData();

                    // Versuche, die aktualisierte Zeile zu markieren
                    dgbearbeiten.CurrentCell = null; // Zuerst die aktuelle Zelle aufheben
                    dgbearbeiten.ClearSelection();

                    foreach (DataGridViewRow row in dgbearbeiten.Rows) {
                        if (row.Cells[0].Value != null && row.Cells[0].Value.Equals(selectedRow.Cells[0].Value)) {
                            row.Selected = true;
                            dgbearbeiten.CurrentCell = row.Cells[0];
                            break;
                        }
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
