﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace kunzecordingsSTARGMBH {
    public partial class entfernenansprechspartner : Form {
        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = null;
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();


        bool clicked;
        string mnr = "";
        public entfernenansprechspartner() {
            InitializeComponent();
        }

        private void entfernenansprechspartner_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source= Kunze.accdb";
                con.Open();
                con.Close();
            }
            catch {
                MessageBox.Show("Die Datenbank konnte nicht geöffnet werden");
            }
            try {
                con.Open();
                ada = new OleDbDataAdapter("select * from Ansprechspartner where Anspr_gelöscht = true", con);
                ada.Fill(ds, "Kundengelöscht");
                dg.DataSource = ds;
                dg.DataMember = "Kundengelöscht";
                con.Close();
        
            }
            catch {
                MessageBox.Show("Der Datensatz konnte nicht gelöscht werden");
            }
        }

        private void button1_Click(object sender, EventArgs e) {

            try
            {
                if (dg.SelectedRows.Count > 0)
                {
                    con.Open();
                    int mnr = Convert.ToInt32(dg.SelectedRows[0].Cells["Anspr_id"].Value);
                    cmd = new OleDbCommand("Update Ansprechspartner set Anspr_gelöscht = false where Anspr_id = " + mnr, con);
                    cmd.ExecuteNonQuery();
                    ds.Clear();
                    ada.Fill(ds, "Kundengelöscht");
                    dg.DataSource = ds;
                    dg.DataMember = "Kundengelöscht";
                    con.Close();
                }
                else
                {
                    MessageBox.Show("Bitte wählen Sie einen Datensatz aus, um ihn zu aktualisieren.");
                }
            }
            catch (Exception a)
            {
                MessageBox.Show("Der Datensatz konnte nicht hinzugefügt werden" + a);
            }

        }

        private void dg_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            clicked = true;
            if (e.RowIndex >= 0) {
                dg.CurrentRow.Selected = true;
                mnr = dg.Rows[e.RowIndex].Cells["Anspr_id"].FormattedValue.ToString();
                label2.Text = dg.Rows[e.RowIndex].Cells["Anspr_id"].FormattedValue.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
