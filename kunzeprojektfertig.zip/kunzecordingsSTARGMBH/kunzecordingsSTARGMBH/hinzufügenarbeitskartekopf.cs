﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH
{
    public partial class hinzufügenarbeitskartekopf : Form
    {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;


        private Auftraghinzufügen mainForm;
        private DataGridViewRow selectedRow;
        public hinzufügenarbeitskartekopf()
        {
            InitializeComponent();
            this.mainForm = mainForm;
        }

        public hinzufügenarbeitskartekopf(DataGridViewRow selectedRow) : this()
        {
            this.selectedRow = selectedRow;
            
        }
        private void hinzufügenarbeitskartekopf_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";
                con.Open();

            }
            catch (Exception a)
            {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            try
            {
                
                cmd = new OleDbCommand("SELECT DISTINCT P_fertigstellung_zeit_id FROM Fertigstellung_zeit ORDER BY P_fertigstellung_zeit_id ASC", con);
                dr = cmd.ExecuteReader();

                // ComboBox leeren, bevor neue Werte hinzugefügt werden
                cbx_fertzeitid.Items.Clear();

                // liest die Datensätze bis zur Tabelle
                while (dr.Read())
                {
                    cbx_fertzeitid.Items.Add(dr.GetInt32(0));
                }

            
            }
            catch (Exception a)
            {
                MessageBox.Show("Tabellen-Zugriffsfehler (Sequentielles Suchen):" + a);
            }
            finally
            {
                // Verbindung schließen, falls geöffnet
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }



            try
            {
                // Verbindung öffnen, wenn nicht bereits geöffnet
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }

                cmd = new OleDbCommand("SELECT DISTINCT Abnahme_id FROM Abnahmegesellschaft ORDER BY Abnahme_id ASC", con);
                dr = cmd.ExecuteReader();

                // ComboBox leeren, bevor neue Werte hinzugefügt werden
                cbx_abnahme_id.Items.Clear();

                // liest die Datensätze bis zur Tabelle
                while (dr.Read())
                {
                    cbx_abnahme_id.Items.Add(dr.GetInt32(0));
                }
            }
            catch (Exception a)
            {
                MessageBox.Show("Tabellen-Zugriffsfehler (Sequentielles Suchen):" + a);
            }
            finally
            {
                // Verbindung schließen, falls geöffnet
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

            try
            {
                // Verbindung öffnen, wenn nicht bereits geöffnet
                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }

                cmd = new OleDbCommand("SELECT DISTINCT Prob_id FROM Auftrag ORDER BY Prob_id ASC", con);
                dr = cmd.ExecuteReader();

                // ComboBox leeren, bevor neue Werte hinzugefügt werden
                cbx_prob.Items.Clear();

                // liest die Datensätze bis zur Tabelle
                while (dr.Read())
                {
                    cbx_prob.Items.Add(dr.GetInt32(0));
                }
            }
            catch (Exception a)
            {
                MessageBox.Show("Tabellen-Zugriffsfehler (Sequentielles Suchen):" + a);
            }
            finally
            {
                // Verbindung schließen, falls geöffnet
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }

        private void btn_anzeigen_Click(object sender, EventArgs e)
        {
            try
            {
                // Überprüfe, ob alle Felder ausgefüllt sind
                if (string.IsNullOrWhiteSpace(tbx_pid.Text) ||
                    string.IsNullOrWhiteSpace(cbx_prob.Text) ||
                    string.IsNullOrWhiteSpace(cbx_fertzeitid.Text) ||
                    string.IsNullOrWhiteSpace(tbx_chargeid.Text) ||
                    string.IsNullOrWhiteSpace(tbx_anzahl.Text) ||
                    string.IsNullOrWhiteSpace(cbx_abnahme_id.Text) ||
                    string.IsNullOrWhiteSpace(tbx_bemerkung.Text) ||
                    string.IsNullOrWhiteSpace(tbx_eingang.Text) ||
                    string.IsNullOrWhiteSpace(tbx_fertdat.Text) ||
                    string.IsNullOrWhiteSpace(tbx_abnahme_dat.Text) ||
                    string.IsNullOrWhiteSpace(tbx_sonstige1.Text) ||
                    string.IsNullOrWhiteSpace(tbx_sonstige2.Text) ||
                    string.IsNullOrWhiteSpace(tbx_sonstige3.Text) ||
                    string.IsNullOrWhiteSpace(tbx_abgeschlossen.Text))
                {
                    MessageBox.Show("Bitte füllen Sie alle Felder aus.");
                    return; // Verlasse die Methode, da nicht alle Felder ausgefüllt sind
                }

                int pid, probId, fertigzeitId, chargeId, anzahl, abnahmeId;

                // Überprüfe, ob numerische Werte eingegeben wurden
                if (!int.TryParse(tbx_pid.Text, out pid) ||
                    !int.TryParse(cbx_prob.Text, out probId) ||
                    !int.TryParse(cbx_fertzeitid.Text, out fertigzeitId) ||
                    !int.TryParse(tbx_chargeid.Text, out chargeId) ||
                    !int.TryParse(tbx_anzahl.Text, out anzahl) ||
                    !int.TryParse(cbx_abnahme_id.Text, out abnahmeId))
                {
                    MessageBox.Show("Bitte geben Sie numerische Werte für P_id, Prob_id, P_fertigstellung_zeit_id, P_charge_id, P_anzahl und Abnahme_id ein.");
                    return; // Verlasse die Methode, da die Eingabe nicht korrekt ist
                }


                // Überprüfe, ob der Datensatz bereits existiert
                using (OleDbCommand checkCmd = new OleDbCommand("SELECT COUNT(*) FROM Probe_kopf WHERE P_id = ?", con))
                {
                    // Hier öffnen, wenn nicht bereits geöffnet
                    if (con.State != ConnectionState.Open)
                    {
                        con.Open();
                    }

                    checkCmd.Parameters.AddWithValue("P_id", pid);

                    int count = (int)checkCmd.ExecuteScalar();

                    if (count > 0)
                    {
                        MessageBox.Show("Der Datensatz mit P_id " + pid + " existiert bereits.");
                        fehlermeldung();
                        return;
                    }
                }
                using (OleDbCommand checkCmd = new OleDbCommand("SELECT COUNT(*) FROM Probe_kopf WHERE P_id = ?", con))
                {
                    checkCmd.Parameters.AddWithValue("P_id", pid);

                    int count = (int)checkCmd.ExecuteScalar();

                    if (count > 0)
                    {
                        MessageBox.Show("Der Datensatz mit P_id " + pid + " existiert bereits.");
                        fehlermeldung();
                        return;
                    }
                }

                cmd = new OleDbCommand("insert into Probe_kopf(P_id, Prob_id, P_eingang, P_fertigstellung_dat, P_fertigstellung_zeit_id, P_abnahme_dat, P_charge_id, P_bemerkung, P_sonstige1, P_sonstige2, P_sonstige3, P_anzahl, P_abgeschlossen, Abnahme_id) " +
                    "values (" + pid + "," + probId + ",'" + tbx_eingang.Text + "','" + tbx_fertdat.Text + "'," + fertigzeitId + ",'" + tbx_abnahme_dat.Text + "','" + chargeId + "','" + tbx_bemerkung.Text + "','" + tbx_sonstige1.Text + "','" + tbx_sonstige2.Text + "','" + tbx_sonstige3.Text + "'," + anzahl + ",'" + tbx_abgeschlossen.Text + "'," + abnahmeId + ")", con);
                cmd.ExecuteNonQuery();

                MessageBox.Show("Erfolgreich");

                // Rufe die RefreshData-Methode des Hauptformulars auf
                mainForm?.RefreshData();

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Es ist ein Fehler aufgetreten: " + a.Message);
                fehlermeldung();
            }
            finally
            {
                // Hier kannst du die Verbindung schließen, wenn nötig
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public void fehlermeldung()
        {
            if (tbx_pid.Text == "")
            {
                lbl_fehlermeldung.Visible = true;
                lbl_fehlermeldung.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_fehlermeldung.Visible = false;
            }

            if (tbx_fertdat.Text == "")
            {
                lbl_fertdatum.Visible = true;
                lbl_fertdatum.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_fertdatum.Visible = false;
            }

         

            if (tbx_bemerkung.Text == "")
            {
                lbl_bemerkung.Visible = true;
                lbl_bemerkung.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_bemerkung.Visible = false;
            }

            if (tbx_sonstige2.Text == "")
            {
                lbl_sonstige2.Visible = true;
                lbl_sonstige2.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_sonstige2.Visible = false;
            }
            if (tbx_chargeid.Text == "")
            {
                lbl_charge.Visible = true;
                lbl_charge.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_charge.Visible = false;
            }
          
            if (tbx_sonstige1.Text == "")
            {
                lbl_sonstige1.Visible = true;
                lbl_sonstige1.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_sonstige1.Visible = false;
            }
            if (tbx_abnahme_dat.Text == "")
            {
                lbl_abnahmedat.Visible = true;
                lbl_abnahmedat.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_abnahmedat.Visible = false;
            }

            if (tbx_sonstige3.Text == "")
            {
                lbl_sonstige3.Visible = true;
                lbl_sonstige3.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_sonstige3.Visible = false;
            }

            if (tbx_anzahl.Text == "")
            {
                lbl_anzahl.Visible = true;
                lbl_anzahl.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_anzahl.Visible = false;
            }

            if (tbx_abgeschlossen.Text == "")
            {
                lbl_abgeschlossen.Visible = true;
                lbl_abgeschlossen.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_abgeschlossen.Visible = false;
            }

            if (tbx_eingang.Text == "")
            {
                lbl_eingang.Visible = true;
                lbl_eingang.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_eingang.Visible = false;
            }

          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
