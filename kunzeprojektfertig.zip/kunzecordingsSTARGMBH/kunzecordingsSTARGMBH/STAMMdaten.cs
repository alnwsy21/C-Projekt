﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kunzecordingsSTARGMBH {
    public partial class STAMMdaten : UserControl {
        public STAMMdaten() {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) {
            ansprechpartner.Hide();
            werkstoff.Hide();
            kunden.Show();
            kunden.BringToFront();
        }

        private void button2_Click(object sender, EventArgs e) {
            ansprechpartner.Hide();
            kunden.Hide();
            werkstoff.Show();
            werkstoff.BringToFront();
        }

        private void button4_Click(object sender, EventArgs e) {
            kunden.Hide();
            werkstoff.Hide();
            ansprechpartner.Show();
            ansprechpartner.BringToFront();
        }

        private void button5_Click(object sender, EventArgs e) {
            kunden.Hide();
            werkstoff.Hide();
            ansprechpartner.Hide();
        }
    }
}
