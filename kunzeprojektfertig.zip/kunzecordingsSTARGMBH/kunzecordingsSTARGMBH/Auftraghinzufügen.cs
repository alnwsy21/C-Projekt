﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class Auftraghinzufügen : Form {
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Kunze.accdb;";
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;

        public Auftraghinzufügen() {
            InitializeComponent();
        }

        private void Auftraghinzufügen_Load(object sender, EventArgs e) {
            LoadData();
        }
        public void RefreshData() {
            LoadData();
        }
        private void LoadData() {
            using (OleDbConnection connection = new OleDbConnection(connectionString)) {
                connection.Open();
                string query = "select Auf_id, Auf_angenommen, Auf_liefertermin, K_id, Status_id, W_id, N_id, Aus_bestell_id, Auf_prüflos, Anspr_id, Prob_id, Auf_menge  from Auftrag";

                using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection)) {
                    dataSet = new DataSet();
                    adapter.Fill(dataSet, "auftrag");
                    dghinzufügen.DataSource = dataSet.Tables["auftrag"];
                }
            }
            dghinzufügen.Columns["Auf_id"].HeaderText = "Nummer";
            dghinzufügen.Columns["Auf_angenommen"].HeaderText = "Angenommen";
            dghinzufügen.Columns["Auf_liefertermin"].HeaderText = "Liefertermin";
            dghinzufügen.Columns["K_id"].HeaderText = "Kundennummer";
            dghinzufügen.Columns["Status_id"].HeaderText = "Statusnummer";
            dghinzufügen.Columns["W_id"].HeaderText = "Werkstoffnummer";
            dghinzufügen.Columns["N_id"].HeaderText = "Normnummer";
            dghinzufügen.Columns["Aus_bestell_id"].HeaderText = "Auftrag_bestellnummer";
            dghinzufügen.Columns["Auf_prüflos"].HeaderText = "Prüflos";
            dghinzufügen.Columns["Anspr_id"].HeaderText = "Ansprechspartner";
            dghinzufügen.Columns["Prob_id"].HeaderText = "Probnummer";
            dghinzufügen.Columns["Auf_menge"].HeaderText = "Menge";
            dghinzufügen.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
        }

        private void dghinzufügen_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            if (e.RowIndex >= 0) {
                // Hier bekommst du den ausgewählten Mitarbeiter
                DataGridViewRow selectedRow = dghinzufügen.Rows[e.RowIndex];

                //  Öffne ein Formular zum Bearbeiten mit den Daten der ausgewählten Zeile
                cbx_probe bearbeitenForm = new cbx_probe(selectedRow);
                DialogResult result = bearbeitenForm.ShowDialog();

                // Wenn die Bearbeitung abgeschlossen ist, lade die aktualisierten Daten
                if (result == DialogResult.OK) {
                    LoadData();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
