﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH
{
    public partial class Hinzufügenarbeitskarte : Form
    {
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Kunze.accdb;";
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;
        public Hinzufügenarbeitskarte()
        {
            InitializeComponent();
        }

        private void Hinzufügenarbeitskarte_Load(object sender, EventArgs e)
        {
            LoadData();
            LoadData2();
        }
        public void RefreshData()
        {
            LoadData();
            LoadData2();
        }
        private void LoadData()
        {
            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT P_id, Prob_id, P_eingang, P_fertigstellung_dat, P_fertigstellung_zeit_id, P_abnahme_dat, P_charge_id, P_bemerkung, P_sonstige1, P_sonstige2, P_sonstige3, P_anzahl, P_abgeschlossen, Abnahme_id FROM  Probe_kopf";

                using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection))
                {
                    dataSet = new DataSet();
                    adapter.Fill(dataSet, "P_id");
                    dghinzufügen.DataSource = dataSet.Tables["P_id"];
                }
            }
            dghinzufügen.Columns["P_id"].HeaderText = "Prüfungs_nummer";
            dghinzufügen.Columns["Prob_id"].HeaderText = "Probe_nummer";
            dghinzufügen.Columns["P_eingang"].HeaderText = "Prüfnugs_eingang";
        }
        private void LoadData2()
        {
            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT P_id, Pe_id, Pe_typ_id, Pe_anzahl, Pe_temp, Pe_probenform, Pe_probenlage, Pe_norm, Pe_bemerkung, M_id, P_ergebnis_text FROM Probe_unter";

                using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection))
                {
                    dataSet = new DataSet();
                    adapter.Fill(dataSet, "P_id");
                    dghinzufügen2.DataSource = dataSet.Tables["P_id"];
                }
            }
            dghinzufügen2.Columns["P_id"].HeaderText = "Prüfungs_nummer";
            dghinzufügen2.Columns["Pe_id"].HeaderText = "Prüfung_einzel_Nr.";
            dghinzufügen2.Columns["Pe_typ_id"].HeaderText = "Prüfungeinzel_typ_Nr.";
            dghinzufügen2.Columns["M_id"].HeaderText = "Mitarbeiternummer";
        }

        private void dghinzufügen_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // Hier bekommst du den ausgewählten Mitarbeiter
                DataGridViewRow selectedRow = dghinzufügen.Rows[e.RowIndex];

                //Öffne ein Formular zum Bearbeiten mit den Daten der ausgewählten Zeile
                hinzufügenarbeitskartekopf bearbeitenForm = new hinzufügenarbeitskartekopf(selectedRow);
                DialogResult result = bearbeitenForm.ShowDialog();

                // Wenn die Bearbeitung abgeschlossen ist, lade die aktualisierten Daten
                if (result == DialogResult.OK)
                {
                    LoadData();
                }
            }
        }

        private void dghinzufügen2_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // Hier bekommst du den ausgewählten Mitarbeiter
                DataGridViewRow selectedRow = dghinzufügen2.Rows[e.RowIndex];

                // Öffne ein Formular zum Bearbeiten mit den Daten der ausgewählten Zeile
                hinzufügenarbeitskarteunter bearbeitenForm = new hinzufügenarbeitskarteunter(selectedRow);
                DialogResult result = bearbeitenForm.ShowDialog();

                // Wenn die Bearbeitung abgeschlossen ist, lade die aktualisierten Daten
                if (result == DialogResult.OK)
                {
                    LoadData2();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
