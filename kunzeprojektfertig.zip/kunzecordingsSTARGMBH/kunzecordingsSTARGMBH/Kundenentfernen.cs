﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class Kundenentfernen : Form {
        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = null;
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();

        string mnr = "";
        bool clicked;
        public Kundenentfernen() {
            InitializeComponent();
        }

        private void Kundenentfernen_Load(object sender, EventArgs e) {
            try { // Verbindung zur Datenbank öffnen
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";
                con.Open();
                con.Close();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            try {
                ds.Clear();

                con.Open();
                ada = new OleDbDataAdapter("select K_id, K_name, K_ust_id, K_adresse, K_lief_adresse from Kunden where K_gelöscht=false", con);

                ada.Fill(ds, "Mitarbeiterübersicht");
                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "Mitarbeiterübersicht";
           

                dgentfernen.Columns["K_id"].HeaderText = "Nummer";
                dgentfernen.Columns["K_name"].HeaderText = "Name";
                dgentfernen.Columns["K_ust_id"].HeaderText = "Umsatzsteuer_nummer";
                dgentfernen.Columns["K_adresse"].HeaderText = "Adresse";
                dgentfernen.Columns["K_lief_adresse"].HeaderText = "Liefer_adresse";
                dgentfernen.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
                con.Close();
            }
            catch (Exception a) {
                MessageBox.Show("Fehler beim laden der Kunden Informationen. Bitte wenden sie sich an die IT-Abteilung" + a);
            }
        }

        private void button1_Click(object sender, EventArgs e) {
            if (clicked == true) {
                con.Open();
                cmd = new OleDbCommand("Update Kunden set K_gelöscht = true where K_id = " + mnr + "", con);
                cmd.ExecuteNonQuery();
                ds.Clear();
                ada.Fill(ds, "Mitarbeiterübersicht");
                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "Mitarbeiterübersicht";
                con.Close();
            }
            else {
                MessageBox.Show("Sie müssen doppelt auf den gewünschten Kunde Klicken damit sie ihn löschen können");
            }
        }

        private void button2_Click(object sender, EventArgs e) {
            entfernenkunde kundengelöscht = new entfernenkunde();
            kundengelöscht.ShowDialog();
            ds.Clear();
            ada.Fill(ds, "Mitarbeiterübersicht");
            dgentfernen.DataSource = ds;
            dgentfernen.DataMember = "Mitarbeiterübersicht";
        }

        private void dgentfernen_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            clicked = true;
            if (e.RowIndex >= 0) {
                dgentfernen.CurrentRow.Selected = true;
                mnr = dgentfernen.Rows[e.RowIndex].Cells["K_id"].FormattedValue.ToString();
                label3.Text = dgentfernen.Rows[e.RowIndex].Cells["K_id"].FormattedValue.ToString();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
