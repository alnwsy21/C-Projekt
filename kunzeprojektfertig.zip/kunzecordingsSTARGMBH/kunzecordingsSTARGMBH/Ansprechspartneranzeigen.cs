﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class Ansprechspartneranzeigen : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public Ansprechspartneranzeigen() {
            InitializeComponent();
        }

        private void Ansprechspartneranzeigen_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";

                con.Open();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }

            try {
                ds.Clear();

                ada = new OleDbDataAdapter("select Anspr_id, Anspr_vname, Anspr_nname, Anspr_tel, Anspr_email, Anspr_position from Ansprechspartner", con);
                ada.Fill(ds, "Ansprechspartner");
                dganzeigen.DataSource = ds;
                dganzeigen.DataMember = "Ansprechspartner";
                dganzeigen.Columns["Anspr_id"].HeaderText = "Nummer";
                dganzeigen.Columns["Anspr_vname"].HeaderText = "Vorname";
                dganzeigen.Columns["Anspr_nname"].HeaderText = "Nachname";
                dganzeigen.Columns["Anspr_tel"].HeaderText = "Telefon";
                dganzeigen.Columns["Anspr_email"].HeaderText = "Email";
                dganzeigen.Columns["Anspr_position"].HeaderText = "Position";

                con.Close();
            }
            catch (Exception) {

                MessageBox.Show("fehler");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
