﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class Kundenbearbeiten : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Kunze.accdb;";
        public Kundenbearbeiten() {
            InitializeComponent();
        }

        private void Kundenbearbeiten_Load(object sender, EventArgs e) {
            LoadData();
        }
        private void LoadData() {
            using (OleDbConnection connection = new OleDbConnection(connectionString)) {
                connection.Open();
                string query = "SELECT K_id, K_name, K_ust_id, K_adresse, K_lief_adresse FROM Kunden";

                using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection)) {
                    dataSet = new DataSet();
                    adapter.Fill(dataSet, "DeineTabelle");
                    dgbearbeiten.DataSource = dataSet.Tables["DeineTabelle"];
                }
            }
            dgbearbeiten.Columns["K_id"].HeaderText = "Nummer";
            dgbearbeiten.Columns["K_name"].HeaderText = "Name";
            dgbearbeiten.Columns["K_ust_id"].HeaderText = "Umsatzsteuer_nummer";
            dgbearbeiten.Columns["K_adresse"].HeaderText = "Adresse";
            dgbearbeiten.Columns["K_lief_adresse"].HeaderText = "Liefer_adresse";
            dgbearbeiten.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
        }

        private void dgbearbeiten_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            if (e.RowIndex >= 0) {
                DataGridViewRow selectedRow = dgbearbeiten.Rows[e.RowIndex];

                bearbeitenkunde bearbeitenForm = new bearbeitenkunde(selectedRow, connectionString);
                DialogResult result = bearbeitenForm.ShowDialog();

                if (result == DialogResult.OK) {
                    // Lade die Daten erneut
                    LoadData();

                    // Versuche, die aktualisierte Zeile zu markieren
                    dgbearbeiten.CurrentCell = null; // Zuerst die aktuelle Zelle aufheben
                    dgbearbeiten.ClearSelection();

                    foreach (DataGridViewRow row in dgbearbeiten.Rows) {
                        if (row.Cells[0].Value != null && row.Cells[0].Value.Equals(selectedRow.Cells[0].Value)) {
                            row.Selected = true;
                            dgbearbeiten.CurrentCell = row.Cells[0];
                            break;
                        }
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
