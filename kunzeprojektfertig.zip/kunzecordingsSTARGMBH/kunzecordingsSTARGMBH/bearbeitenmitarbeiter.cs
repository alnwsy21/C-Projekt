﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class bearbeitenmitarbeiter : Form {
      OleDbCommand cmd = null;


        private readonly string connectionString;
        private readonly OleDbConnection con = new OleDbConnection();
        private DataGridViewRow selectedRow;

        public DataGridViewRow UpdatedRow { get; private set; }


       
        public bearbeitenmitarbeiter(DataGridViewRow selectedRow, string connectionString) {
            InitializeComponent();
            this.selectedRow = selectedRow;
            this.connectionString = connectionString;
        }

       
       
        private void BearbeitungAbschließen() {
            try
            {
                // Überprüfe, ob alle Pflichtfelder leer sind
                if (string.IsNullOrWhiteSpace(tbx_vname.Text) || string.IsNullOrWhiteSpace(tbx_nname.Text) || string.IsNullOrWhiteSpace(tbx_mlp.Text) || string.IsNullOrWhiteSpace(tbx_mlname.Text) || string.IsNullOrWhiteSpace(tbx_id.Text))
                {
                    MessageBox.Show("Alle Pflichtfelder müssen ausgefüllt werden.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Überprüfe, ob die M_id eine gültige Zahl ist
                int mId;
                if (!int.TryParse(tbx_id.Text, out mId))
                {
                    MessageBox.Show("Bitte geben Sie eine gültige Zahl für M_id ein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Führe das Update nur aus, wenn alle Pflichtfelder ausgefüllt und die M_id eine gültige Zahl ist
                cmd = new OleDbCommand("UPDATE Mitarbeiter SET M_vname='" + tbx_vname.Text + "', M_nname='" + tbx_nname.Text + "', M_pass='" + tbx_mlp.Text + "', M_admin='" + tbx_mlname.Text + "' WHERE M_id=" + mId, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Erfolgreich bearbeitet!");

                // Setze UpdatedRow auf die aktualisierte Zeile
                UpdatedRow = selectedRow;

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler beim Bearbeiten: " + ex.Message, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void bearbeitenmitarbeiter_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = connectionString;
                con.Open();

                // Hier rufe ich eine Methode auf, um die Daten in den Textboxen anzuzeigen
                AnzeigenDerDaten();
            }
            catch (Exception ex) {
                MessageBox.Show("Fehler: " + ex.Message);
            }
            tbx_mlp.PasswordChar = '•';
        }

        private void btn_anzeigen_Click(object sender, EventArgs e) {
            BearbeitungAbschließen();
        }
        private void AnzeigenDerDaten() {
            try {
               
                tbx_id.Text = selectedRow.Cells["M_id"].Value.ToString();
                tbx_vname.Text = selectedRow.Cells["M_vname"].Value.ToString();
                tbx_nname.Text = selectedRow.Cells["M_nname"].Value.ToString();
                tbx_mlname.Text = selectedRow.Cells["M_admin"].Value.ToString();
                tbx_mlp.Text = selectedRow.Cells["M_pass"].Value.ToString();
                
            }
            catch (Exception ex) {
                MessageBox.Show("Fehler beim Anzeigen der Daten: " + ex.Message);
            }
        }
      
        private void checkbox_show_CheckedChanged(object sender, EventArgs e) {
            if (tbx_mlp.PasswordChar == '•') {
                tbx_mlp.PasswordChar = '\0';
            }
            else {
                tbx_mlp.PasswordChar = '•';
            }
        }

        private void button3_Click(object sender, EventArgs e) {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e) {
            Application.Exit();
        }
    }
}
