﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class auftraganzeigen : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public auftraganzeigen() {
            InitializeComponent();
        }

        private void auftraganzeigen_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";

                con.Open();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }

            try {
                ds.Clear();

                ada = new OleDbDataAdapter("select Auf_id, Auf_angenommen, Auf_liefertermin, K_id, Status_id, W_id, N_id, Aus_bestell_id, Auf_prüflos, Anspr_id, Prob_id, Auf_menge  from Auftrag", con);
                ada.Fill(ds, "auftrag");
                dganzeigen.DataSource = ds;
                dganzeigen.DataMember = "auftrag";
                con.Close();
                dganzeigen.Columns["Auf_id"].HeaderText = "Nummer";
                dganzeigen.Columns["Auf_angenommen"].HeaderText = "Angenommen";
                dganzeigen.Columns["Auf_liefertermin"].HeaderText = "Liefertermin";
                dganzeigen.Columns["K_id"].HeaderText = "Kundennummer";
                dganzeigen.Columns["Status_id"].HeaderText = "Statusnummer";
                dganzeigen.Columns["W_id"].HeaderText = "Werkstoffnummer";
                dganzeigen.Columns["N_id"].HeaderText = "Normnummer";
                dganzeigen.Columns["Aus_bestell_id"].HeaderText = "Auftrag_bestellnummer";
                dganzeigen.Columns["Auf_prüflos"].HeaderText = "Prüflos";
                dganzeigen.Columns["Anspr_id"].HeaderText = "Ansprechspartner";
                dganzeigen.Columns["Prob_id"].HeaderText = "Probnummer";
                dganzeigen.Columns["Auf_menge"].HeaderText = "Menge";
                dganzeigen.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            }
            catch (Exception) {

                MessageBox.Show("fehler");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
