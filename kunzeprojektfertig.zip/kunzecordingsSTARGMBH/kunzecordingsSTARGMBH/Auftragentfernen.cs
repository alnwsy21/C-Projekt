﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class Auftragentfernen : Form {
        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = null;
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();

        string mnr = "";
        bool clicked;
        public Auftragentfernen() {
            InitializeComponent();
        }

        private void Auftragentfernen_Load(object sender, EventArgs e) {
            try { // Verbindung zur Datenbank öffnen
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";
                con.Open();
                con.Close();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            try {
                ds.Clear();

                con.Open();
                ada = new OleDbDataAdapter("select Auf_id, Auf_angenommen, Auf_liefertermin, K_id, Status_id, W_id, N_id, Aus_bestell_id, Auf_prüflos, Anspr_id, Prob_id, Auf_menge  from Auftrag where Auf_gelöscht=false", con);

                ada.Fill(ds, "Mitarbeiterübersicht");
                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "Mitarbeiterübersicht";
                //spaltenformatierung();
                con.Close();
                dgentfernen.Columns["Auf_id"].HeaderText = "Nummer";
                dgentfernen.Columns["Auf_angenommen"].HeaderText = "Angenommen";
                dgentfernen.Columns["Auf_liefertermin"].HeaderText = "Liefertermin";
                dgentfernen.Columns["K_id"].HeaderText = "Kundennummer";
                dgentfernen.Columns["Status_id"].HeaderText = "Statusnummer";
                dgentfernen.Columns["W_id"].HeaderText = "Werkstoffnummer";
                dgentfernen.Columns["N_id"].HeaderText = "Normnummer";
                dgentfernen.Columns["Aus_bestell_id"].HeaderText = "Auftrag_bestellnummer";
                dgentfernen.Columns["Auf_prüflos"].HeaderText = "Prüflos";
                dgentfernen.Columns["Anspr_id"].HeaderText = "Ansprechspartner";
                dgentfernen.Columns["Prob_id"].HeaderText = "Probnummer";
                dgentfernen.Columns["Auf_menge"].HeaderText = "Menge";
                dgentfernen.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            }
            catch (Exception a) {
                MessageBox.Show("Fehler beim laden der Auftrag Informationen. Bitte wenden sie sich an die IT-Abteilung" + a);
            }
        }

        private void button1_Click(object sender, EventArgs e) {
            if (clicked == true) {
                con.Open();
                cmd = new OleDbCommand("Update Auftrag set Auf_gelöscht = true where Auf_id = " + mnr + "", con);
                cmd.ExecuteNonQuery();
                ds.Clear();
                ada.Fill(ds, "auftrag");
                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "auftrag";
                con.Close();
            }
            else {
                MessageBox.Show("Sie müssen doppelt auf den gewünschten Auf_id Klicken damit sie ihn löschen können");
            }
        }

        private void button2_Click(object sender, EventArgs e) {
            Entfernenauftrag mItarbeitergelöscht = new Entfernenauftrag();
            mItarbeitergelöscht.ShowDialog();
            ds.Clear();
            ada.Fill(ds, "Mitarbeiterübersicht");
            dgentfernen.DataSource = ds;
            dgentfernen.DataMember = "Mitarbeiterübersicht";
        }

        private void dgentfernen_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            clicked = true;
         
            if (e.RowIndex >= 0) { 
                dgentfernen.CurrentRow.Selected = true;
                mnr = dgentfernen.Rows[e.RowIndex].Cells["Auf_id"].FormattedValue.ToString();
                label3.Text = dgentfernen.Rows[e.RowIndex].Cells["Auf_id"].FormattedValue.ToString();
            }   
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
