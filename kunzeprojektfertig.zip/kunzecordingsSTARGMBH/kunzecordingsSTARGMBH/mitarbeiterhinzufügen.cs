﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace kunzecordingsSTARGMBH {
    
    public partial class mitarbeiterhinzufügen : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;


        private mitarbeiteradd mainForm;
        private DataGridViewRow selectedRow;
        public mitarbeiterhinzufügen() {
            InitializeComponent();
            this.mainForm = mainForm;
        }
        public mitarbeiterhinzufügen(DataGridViewRow selectedRow) : this() {
            this.selectedRow = selectedRow;
            // Hier kannst du die Daten der ausgewählten Zeile verwenden, um dein Formular zu initialisieren
        }
        private void MitarbeiterBearbeitenForm_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";
                con.Open();
                
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            tbx_mlp.PasswordChar = '•';
        }

       

      

        private void btn_anzeigen_Click(object sender, EventArgs e) {
            try {
                // Überprüfe, ob alle Textboxen ausgefüllt sind
                if (string.IsNullOrEmpty(tbx_mnr.Text) || string.IsNullOrEmpty(tbx_vname.Text) || string.IsNullOrEmpty(tbx_nname.Text) || string.IsNullOrEmpty(tbx_mlp.Text) || string.IsNullOrEmpty(tbx_mlname.Text)) {
                    // Zeige eine Meldung an, dass alle Felder ausgefüllt werden müssen
                    MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else {
                    // Überprüfe, ob die Mitarbeiter-ID bereits existiert
                    using (OleDbCommand checkCmd = new OleDbCommand("SELECT COUNT(*) FROM Mitarbeiter WHERE M_id = @M_id", con)) {

                        if (!int.TryParse(tbx_mnr.Text, out int mnr))
                        {
                            MessageBox.Show("Die Mitarbeiter-ID muss eine ganze Zahl sein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        else
                        {
                            checkCmd.Parameters.AddWithValue("@M_id", mnr);
                            // Rest des Codes bleibt unverändert
                        }

                       

                        int existingRecords = (int)checkCmd.ExecuteScalar();

                        if (existingRecords > 0) {
                            // Die Mitarbeiter-ID existiert bereits, zeige eine entsprechende Meldung an
                            MessageBox.Show("Die Mitarbeiter-ID existiert bereits. Bitte wählen Sie eine andere ID.", "Duplikate verhindern", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                        else {
                            // Füge den neuen Datensatz ein
                            using (OleDbCommand insertCmd = new OleDbCommand("INSERT INTO Mitarbeiter(M_id, M_vname, M_nname, M_pass, M_admin) VALUES (@M_id, @M_vname, @M_nname, @M_pass, @M_admin)", con)) {
                                insertCmd.Parameters.AddWithValue("@M_id", Convert.ToInt32(tbx_mnr.Text));
                                insertCmd.Parameters.AddWithValue("@M_vname", tbx_vname.Text);
                                insertCmd.Parameters.AddWithValue("@M_nname", tbx_nname.Text);
                                insertCmd.Parameters.AddWithValue("@M_pass", tbx_mlp.Text);
                                insertCmd.Parameters.AddWithValue("@M_admin", tbx_mlname.Text);

                                insertCmd.ExecuteNonQuery();
                            }

                            MessageBox.Show("Erfolgreich");

                            // Rufe die RefreshData-Methode des Hauptformulars auf
                            mainForm?.RefreshData();

                            this.DialogResult = DialogResult.OK;
                            this.Close();
                        }
                    }
                }
            }
            catch (Exception ex) {
                // Behandele Ausnahmen hier, wenn die Datenbankoperation fehlschlägt
                MessageBox.Show("Fehler beim Speichern der Daten: " + ex.Message, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
               
            }


        }

        public void meldung() {
            try {
                // Überprüfe, ob alle Textboxen ausgefüllt sind
                if (string.IsNullOrEmpty(tbx_mnr.Text) || string.IsNullOrEmpty(tbx_vname.Text) || string.IsNullOrEmpty(tbx_nname.Text) || string.IsNullOrEmpty(tbx_mlp.Text) || string.IsNullOrEmpty(tbx_mlname.Text)) {
                    // Zeige eine Meldung an, dass alle Felder ausgefüllt werden müssen
                    MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else {
                    // Überprüfe, ob die Zahlenfelder gültige Zahlen enthalten
                    int mnr;
                    if (!int.TryParse(tbx_mnr.Text, out mnr)) {
                        MessageBox.Show("Bitte geben Sie eine gültige Zahl für Mitarbeiternummer ein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return; // Beende die Methode, da eine ungültige Zahl eingegeben wurde
                    }

                    // Führe die Datenbankoperation nur aus, wenn alle Felder ausgefüllt sind und eine gültige Zahl für Mitarbeiternummer eingegeben wurde
                    cmd = new OleDbCommand("insert into Mitarbeiter(M_id, M_vname, M_nname, M_pass, M_admin) values (" + mnr + ",'" + tbx_vname.Text + "','" + tbx_nname.Text + "','" + tbx_mlp.Text + "','" + tbx_mlname.Text + "')", con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Erfolgreich");

                    // Rufe die RefreshData-Methode des Hauptformulars auf
                    mainForm?.RefreshData();

                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            catch (Exception ex) {
                MessageBox.Show("Fehler beim Hinzufügen: " + ex.Message, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            fehlermeldung();

        }
        public void fehlermeldung() {
            if (tbx_mnr.Text == "") {
                lbl_fehlermeldung.Visible = true;
                lbl_fehlermeldung.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lbl_fehlermeldung.Visible = false;
            }

            if (tbx_vname.Text == "") {
                lblfehlervname.Visible = true;
                lblfehlervname.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lblfehlervname.Visible = false;
            }

            if (tbx_nname.Text == "") {
                lblfehlernname.Visible = true;
                lblfehlernname.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lblfehlernname.Visible = false;
            }

            if (tbx_mlname.Text == "") {
                lblfehleradmin.Visible = true;
                lblfehleradmin.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lblfehleradmin.Visible = false;
            }

            if (tbx_mlp.Text == "") {
                lblfehlerpass.Visible = true;
                lblfehlerpass.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lblfehlerpass.Visible = false;
            }

        }
        private void button2_Click(object sender, EventArgs e) {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e) {
            this.Close();
        }

        private void checkbox_show_CheckedChanged(object sender, EventArgs e)
        {
            if (tbx_mlp.PasswordChar == '•')
            {
                tbx_mlp.PasswordChar = '\0';
            }
            else
            {
                tbx_mlp.PasswordChar = '•';
            }
        }
    }
}
