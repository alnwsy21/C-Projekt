﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class ArbeitskarteAnzeigen : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
                DataSet ds = new DataSet();
        public ArbeitskarteAnzeigen() {
            InitializeComponent();
        }

        private void ArbeitskarteAnzeigen_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";

                con.Open();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }

               
            //kopf
            try {
                ada = new OleDbDataAdapter("SELECT P_id, Prob_id, P_eingang, P_fertigstellung_dat, P_fertigstellung_zeit_id, P_abnahme_dat, P_charge_id, P_bemerkung, P_sonstige1, P_sonstige2, P_sonstige3, P_anzahl, P_abgeschlossen, Abnahme_id FROM Probe_kopf", con);
                DataSet ds1 = new DataSet();  
                ada.Fill(ds1, "P_id");
                dganzeigen.DataSource = ds1;
                dganzeigen.DataMember = "P_id";
               

                dganzeigen.Columns["P_id"].HeaderText = "Prüfungs_nummer";
                dganzeigen.Columns["Prob_id"].HeaderText = "Probe_nummer";
                dganzeigen.Columns["P_eingang"].HeaderText = "Prüfnugs_eingang";
             

                
            }
            catch (Exception a) {
                MessageBox.Show("Fehler bei der ersten Abfrage: " + a.Message);
            }

            try
            {
                ada = new OleDbDataAdapter("SELECT P_id, Pe_id, Pe_typ_id, Pe_anzahl, Pe_temp, Pe_probenform, Pe_probenlage, Pe_norm, Pe_bemerkung, M_id, P_ergebnis_text FROM Probe_unter", con);
                DataSet ds2 = new DataSet();
                ada.Fill(ds2, "Pe_id");
                dganzeigen2.DataSource = ds2;
                dganzeigen2.DataMember = "Pe_id";

                dganzeigen2.Columns["P_id"].HeaderText = "Prüfungs_nummer";
                dganzeigen2.Columns["Pe_id"].HeaderText = "Prüfung_einzel_Nr.";
                dganzeigen2.Columns["Pe_typ_id"].HeaderText = "Prüfungeinzel_typ_Nr.";
                dganzeigen2.Columns["M_id"].HeaderText = "Mitarbeiternummer";

                // Automatische Anpassung der Spaltenbreiten an den Inhalt
                dganzeigen2.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler bei der zweiten Abfrage: " + a.Message);
            }
            finally
            {
                con.Close();
            }



        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
