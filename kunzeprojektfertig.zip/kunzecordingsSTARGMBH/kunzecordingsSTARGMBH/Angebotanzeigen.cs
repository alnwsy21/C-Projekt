﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Printing;
using System.Data.OleDb;

namespace kunzecordingsSTARGMBH {
    public partial class Angebotanzeigen : Form
    {
        private PrintDocument printDocument = new PrintDocument();
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public Angebotanzeigen()
        {
            InitializeComponent();
            printDocument.PrintPage += new PrintPageEventHandler(PrintDocument_PrintPage);
        }

        private void Angebotanzeigen_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";

                con.Open();
            }
            catch (Exception a)
            {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            // zugriff auf die datenbank
            try
            {
                //der tabelname das kein - enthalten

                
                cmd = new OleDbCommand("select * from Textbaustein order by Textbaustein_id asc", con);


                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                //liest die datensätze bis zum tabelle
                while (dr.Read())
                {

                    cbx_probe_id.Items.Add(dr.GetInt32(0));
                    cbx_liefer_id.Items.Add(dr.GetInt32(0));
                    cbx_rest_id.Items.Add(dr.GetInt32(0));
                 //   cbx_kid.Items.Add(dr.GetInt32(0));
                }
                con.Close();
            }

            catch (Exception a)
            {
                MessageBox.Show("Tabellen-Zugriffsfehler(Sequentielles suchen):" + a);
            }

            try
            {
                con.Open();
                cmd = new OleDbCommand("SELECT DISTINCT K_id FROM Kunden ORDER BY K_id ASC", con);
                dr = cmd.ExecuteReader();

                // ComboBox leeren, bevor neue Werte hinzugefügt werden
                cbx_kid.Items.Clear();

                // liest die Datensätze bis zur Tabelle
                while (dr.Read())
                {
                    cbx_kid.Items.Add(dr.GetInt32(0));
                }

                con.Close(); // Verbindung schließen
            }
            catch (Exception a)
            {
                MessageBox.Show("Tabellen-Zugriffsfehler (Sequentielles Suchen):" + a);
            }

            try
            {
                con.Open();
                cmd = new OleDbCommand("SELECT DISTINCT W_id FROM Werkstoff ORDER BY W_id ASC", con);
                dr = cmd.ExecuteReader();

                // ComboBox leeren, bevor neue Werte hinzugefügt werden
                cbx_w_id.Items.Clear(); // Hier die richtige ComboBox löschen

                // liest die Datensätze bis zur Tabelle
                while (dr.Read())
                {
                    cbx_w_id.Items.Add(dr.GetInt32(0));
                }
            }
            catch (Exception a)
            {
                MessageBox.Show("Tabellen-Zugriffsfehler (Sequentielles Suchen):" + a);
            }
            finally
            {
                con.Close(); // Verbindung schließen
            }



            rechnungupdate();

        }


        private void rechnungupdate()
        {
            try
            {
                ds.Clear();

                ada = new OleDbDataAdapter("select Ang_id, Pe_typ_id, Kommentar, Menge, Rp_preis from Angebotposition", con);
                ada.Fill(ds, "Angebot");

                // Neues DataColumn für die Gesamtsumme hinzufügen
                DataColumn gesamtSummeColumn = new DataColumn("GesamtSumme", typeof(decimal));
                gesamtSummeColumn.Expression = "Menge * Rp_preis";
                ds.Tables["Angebot"].Columns.Add(gesamtSummeColumn);

                dganzeigen.DataSource = ds;
                dganzeigen.DataMember = "Angebot";

                // Ändere den Spaltennamen im DataGridView
                dganzeigen.Columns["Pe_typ_id"].HeaderText = "Prüfungs_nummer";
                dganzeigen.Columns["Ang_id"].HeaderText = "Angebot_nummer";

                UpdateLabels(); // Methode aufrufen, um Labels zu aktualisieren

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler: " + ex.Message);
            }
        }

        private void UpdateLabels()
        {
            // Berechnung der Gesamtsumme direkt aus dem DataGridView
            decimal gesamtSumme = 0;

            foreach (DataGridViewRow row in dganzeigen.Rows)
            {
              
                decimal menge = Convert.ToDecimal(row.Cells["Menge"].Value);
                decimal rpPreis = Convert.ToDecimal(row.Cells["Rp_preis"].Value);

                decimal gesamtEinzelSumme = menge * rpPreis;
                gesamtSumme += gesamtEinzelSumme;
            }

         
            lbl_summevongesamt.Text = gesamtSumme.ToString("C");

           
            decimal umsatz = gesamtSumme * 0.19m;

        
            lbl_umsatz.Text = umsatz.ToString("C");

     
            decimal gesamtSummeMitUmsatz = gesamtSumme + umsatz;

          
            lbl_gesamtsumme.Text = gesamtSummeMitUmsatz.ToString("C");
        }



        private void button1_Click(object sender, EventArgs e)
        {
            // Zeigt den Druckdialog an und druckt das Formular
            PrintDialog printDialog = new PrintDialog();
            printDialog.Document = printDocument;

            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                printDocument.Print();
            }
        }
        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            

            try
            {
                using (Bitmap contentBitmap = new Bitmap(this.Width, this.Height))
                {
                    this.DrawToBitmap(contentBitmap, new Rectangle(0, 0, this.Width, this.Height));

                    // Zeichnen Sie das Bitmap auf die Druckseite
                    e.Graphics.DrawImage(contentBitmap, new Rectangle(20, 20, this.Width, this.Height));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cbx_probe_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                int vergleich = System.Convert.ToInt32(cbx_probe_id.SelectedItem.ToString());

                //es wird ein neuer zugriff (direktzugriff) auf die datenbank ausführt

                cmd = new OleDbCommand("select * from Textbaustein where Textbaustein_id =" + vergleich, con);
                dr = cmd.ExecuteReader();


                dr.Read();
                tbx_material.Text = dr.GetString(1);

                lbl_m.Text = dr.GetString(2);
                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("tabellen-zugriffsfehler(direkt suchen)" + a);
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void cbx_liefer_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                int vergleich = System.Convert.ToInt32(cbx_liefer_id.SelectedItem.ToString());

                //es wird ein neuer zugriff (direktzugriff) auf die datenbank ausführt

                cmd = new OleDbCommand("select * from Textbaustein where Textbaustein_id =" + vergleich, con);
                dr = cmd.ExecuteReader();


                dr.Read();
                tbx_lieferzeit.Text = dr.GetString(1);

                lbl_l.Text = dr.GetString(2);
                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("tabellen-zugriffsfehler(direkt suchen)" + a);
            }
        }

        private void cbx_rest_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                int vergleich = System.Convert.ToInt32(cbx_rest_id.SelectedItem.ToString());

                //es wird ein neuer zugriff (direktzugriff) auf die datenbank ausführt

                cmd = new OleDbCommand("select * from Textbaustein where Textbaustein_id =" + vergleich, con);
                dr = cmd.ExecuteReader();


                dr.Read();
                tbx_rest.Text = dr.GetString(1);

                lbl_r.Text = dr.GetString(2);
                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("tabellen-zugriffsfehler(direkt suchen)" + a);
            }
        }

        private void dganzeigen_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dganzeigen_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            // Wird aufgerufen, wenn sich der Wert in der DataGridView-Zelle ändert
            UpdateLabels(); // Labels aktualisieren
        }

        private void label40_Click(object sender, EventArgs e)
        {

        }

        private void cbx_kid_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                int vergleich = System.Convert.ToInt32(cbx_kid.SelectedItem.ToString());

                //es wird ein neuer zugriff (direktzugriff) auf die datenbank ausführt

                cmd = new OleDbCommand("select * from Kunden where K_id =" + vergleich, con);
                dr = cmd.ExecuteReader();


                dr.Read();
                lbl_kanem.Text = dr.GetString(1);

                k_adresse.Text = dr.GetString(3);
                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("tabellen-zugriffsfehler(direkt suchen)" + a);
            }
        }

        private void label45_Click(object sender, EventArgs e)
        {

        }

        private void dganzeigen_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            lbl_ang_id.Text = dganzeigen.Rows[e.RowIndex].Cells["Ang_id"].FormattedValue.ToString();
        }

        private void cbx_w_id_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {
                con.Open();
                int vergleich = System.Convert.ToInt32(cbx_w_id.SelectedItem.ToString());

                //es wird ein neuer zugriff (direktzugriff) auf die datenbank ausführt

                cmd = new OleDbCommand("select * from Werkstoff where W_id =" + vergleich, con);
                dr = cmd.ExecuteReader();


                dr.Read();
                tbx_w.Text = dr.GetInt32(0).ToString();

           
                con.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("tabellen-zugriffsfehler(direkt suchen)" + a);
            }

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkboxshow.Checked == true)
            {
                cbx_kid.Visible = false;
                cbx_liefer_id.Visible = false;
                cbx_probe_id.Visible = false;
                cbx_rest_id.Visible = false;
                cbx_w_id.Visible = false;
                checkboxshow.Visible = false;
            }

        }
    }
}
    

