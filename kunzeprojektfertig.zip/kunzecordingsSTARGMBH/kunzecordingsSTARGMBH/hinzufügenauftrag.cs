﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class cbx_probe : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;


        private Auftraghinzufügen mainForm;
        private DataGridViewRow selectedRow;

        public cbx_probe() {
            InitializeComponent();
            this.mainForm = mainForm;
        }
        public cbx_probe(DataGridViewRow selectedRow) : this() {
            this.selectedRow = selectedRow;
           
        }
        private void hinzufügenauftrag_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";
                con.Open();

            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }

            try
            {
                //der tabelname das kein - enthalten

                cmd = new OleDbCommand("select K_id from Kunden", con);
                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                //liest die datensätze bis zum tabelle
                while (dr.Read())
                {
                    cbx_kid.Items.Add(dr.GetInt32(0));
                }
            }

            catch (Exception a)
            {
                MessageBox.Show("Tabellen-Zugriffsfehler(Sequentielles suchen):" + a);
            }

            try
            {
                //der tabelname das kein - enthalten

                cmd = new OleDbCommand("select Status_id from Status", con);
                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                //liest die datensätze bis zum tabelle
                while (dr.Read())
                {
                    cbx_status.Items.Add(dr.GetInt32(0));
                }
            }

            catch (Exception a)
            {
                MessageBox.Show("Tabellen-Zugriffsfehler(Sequentielles suchen):" + a);
            }

            try
            {
                //der tabelname das kein - enthalten

                cmd = new OleDbCommand("select W_id from Werkstoff", con);
                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                //liest die datensätze bis zum tabelle
                while (dr.Read())
                {
                    cbx_wnr.Items.Add(dr.GetInt32(0));
                }
            }

            catch (Exception a)
            {
                MessageBox.Show("Tabellen-Zugriffsfehler(Sequentielles suchen):" + a);
            }

            try
            {
                //der tabelname das kein - enthalten

                cmd = new OleDbCommand("select N_id from Norm", con);
                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                //liest die datensätze bis zum tabelle
                while (dr.Read())
                {
                    cbx_norm.Items.Add(dr.GetInt32(0));
                }
            }

            catch (Exception a)
            {
                MessageBox.Show("Tabellen-Zugriffsfehler(Sequentielles suchen):" + a);
            }

            try
            {
                //der tabelname das kein - enthalten

                cmd = new OleDbCommand("select Anspr_id from Ansprechspartner", con);
                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                //liest die datensätze bis zum tabelle
                while (dr.Read())
                {
                    cbx_anspr.Items.Add(dr.GetInt32(0));
                }
            }

            catch (Exception a)
            {
                MessageBox.Show("Tabellen-Zugriffsfehler(Sequentielles suchen):" + a);
            }

            try
            {
                //der tabelname das kein - enthalten

                cmd = new OleDbCommand("select P_id from Probe_kopf", con);
                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                //liest die datensätze bis zum tabelle
                while (dr.Read())
                {
                    cbx_prob.Items.Add(dr.GetInt32(0));
                }
            }

            catch (Exception a)
            {
                MessageBox.Show("Tabellen-Zugriffsfehler(Sequentielles suchen):" + a);
            }
        }

        private void btn_anzeigen_Click(object sender, EventArgs e) {
            try {
                // Überprüfe, ob alle Textboxen ausgefüllt sind
                if (string.IsNullOrWhiteSpace(tbx_anr.Text) || string.IsNullOrWhiteSpace(tbx_aangenommen.Text) || string.IsNullOrWhiteSpace(tbx_liefertermin.Text) || string.IsNullOrWhiteSpace(cbx_kid.Text) || string.IsNullOrWhiteSpace(cbx_status.Text) || string.IsNullOrWhiteSpace(cbx_wnr.Text) || string.IsNullOrWhiteSpace(cbx_norm.Text) || string.IsNullOrWhiteSpace(tbx_ausbestellid.Text) || string.IsNullOrWhiteSpace(tbx_aprüflos.Text) || string.IsNullOrWhiteSpace(cbx_anspr.Text) || string.IsNullOrWhiteSpace(cbx_prob.Text) || string.IsNullOrWhiteSpace(tbx_menge.Text)) {
                    // Zeige eine Meldung an, dass alle Felder ausgefüllt werden müssen
                    MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else {
                    // Führe die Datenbankoperation nur aus, wenn alle Felder ausgefüllt sind

                    // Überprüfe, ob die Auftrags-ID bereits existiert
                    using (OleDbCommand checkCmd = new OleDbCommand("SELECT COUNT(*) FROM Auftrag WHERE Auf_id = @Auf_id", con)) {
                        checkCmd.Parameters.AddWithValue("@Auf_id", Convert.ToInt32(tbx_anr.Text));

                        int existingRecords = (int)checkCmd.ExecuteScalar();

                        if (existingRecords > 0) {
                            // Die Auftrags-ID existiert bereits, zeige eine entsprechende Meldung an
                            MessageBox.Show("Die Auftrags-ID existiert bereits. Bitte wählen Sie eine andere ID.", "Duplikate verhindern", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                        else {
                            // Füge den neuen Datensatz ein
                            using (OleDbCommand insertCmd = new OleDbCommand("INSERT INTO Auftrag(Auf_id, Auf_angenommen, Auf_liefertermin, K_id, status_id, W_id, N_id, Aus_bestell_id, Auf_prüflos, Anspr_id, Prob_id, Auf_menge) " +
                                "VALUES (@Auf_id, @Auf_angenommen, @Auf_liefertermin, @K_id, @status_id, @W_id, @N_id, @Aus_bestell_id, @Auf_prüflos, @Anspr_id, @Prob_id, @Auf_menge)", con)) {
                                insertCmd.Parameters.AddWithValue("@Auf_id", Convert.ToInt32(tbx_anr.Text));
                                insertCmd.Parameters.AddWithValue("@Auf_angenommen", tbx_aangenommen.Text);
                                insertCmd.Parameters.AddWithValue("@Auf_liefertermin", tbx_liefertermin.Text);
                                insertCmd.Parameters.AddWithValue("@K_id", Convert.ToInt32(cbx_kid.Text));
                                insertCmd.Parameters.AddWithValue("@status_id", Convert.ToInt32(cbx_status.Text));
                                insertCmd.Parameters.AddWithValue("@W_id", Convert.ToInt32(cbx_wnr.Text));
                                insertCmd.Parameters.AddWithValue("@N_id", Convert.ToInt32(cbx_norm.Text));
                                insertCmd.Parameters.AddWithValue("@Aus_bestell_id", Convert.ToInt32(tbx_ausbestellid.Text));
                                insertCmd.Parameters.AddWithValue("@Auf_prüflos", Convert.ToInt32(tbx_aprüflos.Text));
                                insertCmd.Parameters.AddWithValue("@Anspr_id", Convert.ToInt32(cbx_anspr.Text));
                                insertCmd.Parameters.AddWithValue("@Prob_id", Convert.ToInt32(cbx_prob.Text));
                                insertCmd.Parameters.AddWithValue("@Auf_menge", Convert.ToInt32(tbx_menge.Text));

                                insertCmd.ExecuteNonQuery();
                            }

                            MessageBox.Show("Erfolgreich");

                            // Rufe die RefreshData-Methode des Hauptformulars auf
                            mainForm?.RefreshData();

                            this.DialogResult = DialogResult.OK;
                            this.Close();
                        }
                    }
                }
            }
            catch (Exception ex) {
           
                meldung();
            }

            fehlermeldung();

        }

        public void meldung() {

            try {
                // Überprüfe, ob alle Textboxen ausgefüllt sind
                if (string.IsNullOrEmpty(tbx_anr.Text) || string.IsNullOrEmpty(tbx_aangenommen.Text) || string.IsNullOrEmpty(tbx_liefertermin.Text) || string.IsNullOrEmpty(cbx_kid.Text) || string.IsNullOrEmpty(cbx_status.Text) || string.IsNullOrEmpty(cbx_wnr.Text) || string.IsNullOrEmpty(cbx_norm.Text) || string.IsNullOrEmpty(tbx_ausbestellid.Text) || string.IsNullOrEmpty(tbx_aprüflos.Text) || string.IsNullOrEmpty(cbx_anspr.Text) || string.IsNullOrEmpty(cbx_prob.Text) || string.IsNullOrEmpty(tbx_menge.Text)) {
                    // Zeige eine Meldung an, dass alle Felder ausgefüllt werden müssen
                    MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else {
                    // Überprüfe, ob die Zahlenfelder gültige Zahlen enthalten
                    int anr, status, wnr, norm, ausbestellid, aprüflos, anspr, probe, menge;
                    if (!int.TryParse(tbx_anr.Text, out anr) || !int.TryParse(cbx_status.Text, out status) || !int.TryParse(cbx_wnr.Text, out wnr) || !int.TryParse(cbx_norm.Text, out norm) || !int.TryParse(tbx_ausbestellid.Text, out ausbestellid) || !int.TryParse(tbx_aprüflos.Text, out aprüflos) || !int.TryParse(cbx_anspr.Text, out anspr) || !int.TryParse(cbx_prob.Text, out probe) || !int.TryParse(tbx_menge.Text, out menge)) {
                        MessageBox.Show("Bitte geben Sie gültige Zahlen für Auftragsnummer, Kundennummer, Status, Werkstoffnummer, Norm, Aus Bestell-ID, Prüflos, Ansprechpartner, Probe und Menge ein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return; // Beende die Methode, da ungültige Zahlen eingegeben wurden
                    }

                    // Führe die Datenbankoperation nur aus, wenn alle Felder ausgefüllt sind und gültige Zahlen eingegeben wurden
                    cmd = new OleDbCommand("insert into Auftrag(Auf_id, Auf_angenommen, Auf_liefertermin, K_id, status_id, W_id, N_id, Aus_bestell_id, Auf_prüflos, Anspr_id, Prob_id, Auf_menge) " +
                        "values (" + anr + ",'" + tbx_aangenommen.Text + "','" + tbx_liefertermin.Text + "'," + Convert.ToInt32(cbx_kid.Text) + "," + status + "," + wnr + "," + norm + "," + ausbestellid + "," + aprüflos + "," + anspr + "," + probe + "," + menge + ")", con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Erfolgreich");

                    // Rufe die RefreshData-Methode des Hauptformulars auf
                    mainForm?.RefreshData();

                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            catch (Exception ex) {
                meldung();
                MessageBox.Show("Fehler beim Hinzufügen: " + ex.Message, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        


        }
        public void fehlermeldung() {
            if (tbx_anr.Text == "") {
                lbl_fehlermeldung.Visible = true;
                lbl_fehlermeldung.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lbl_fehlermeldung.Visible = false;
            }

            if (tbx_liefertermin.Text == "") {
                lblkurzfehlermeldung.Visible = true;
                lblkurzfehlermeldung.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lblkurzfehlermeldung.Visible = false;
            }

            if (tbx_aangenommen.Text == "") {
                lblnamefehlermeldung.Visible = true;
                lblnamefehlermeldung.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lblnamefehlermeldung.Visible = false;
            }

       

            if (tbx_aprüflos.Text == "") {
                lblgewichtfehlermeldung.Visible = true;
                lblgewichtfehlermeldung.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lblgewichtfehlermeldung.Visible = false;
            }
           
         
            if (tbx_ausbestellid.Text == "") {
                lbllängefehlermeldung.Visible = true;
                lbllängefehlermeldung.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lbllängefehlermeldung.Visible = false;
            }
           

           

         

            if (tbx_menge.Text == "") {
                lbl_mengefelher.Visible = true;
                lbl_mengefelher.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lbl_mengefelher.Visible = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
