﻿
namespace kunzecordingsSTARGMBH {
    partial class mitarbeiterlöschen {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.datagriedanzeigen = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.datagriedanzeigen)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // datagriedanzeigen
            // 
            this.datagriedanzeigen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagriedanzeigen.Location = new System.Drawing.Point(63, 77);
            this.datagriedanzeigen.Name = "datagriedanzeigen";
            this.datagriedanzeigen.Size = new System.Drawing.Size(665, 150);
            this.datagriedanzeigen.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(151)))), ((int)(((byte)(139)))));
            this.panel2.Controls.Add(this.label7);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 60);
            this.panel2.TabIndex = 59;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(141, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(290, 33);
            this.label7.TabIndex = 0;
            this.label7.Text = "Mitarbeiter Löschen";
            // 
            // mitarbeiterlöschen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.datagriedanzeigen);
            this.Name = "mitarbeiterlöschen";
            this.Text = "mitarbeiterlöschen";
            this.Load += new System.EventHandler(this.mitarbeiterlöschen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datagriedanzeigen)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView datagriedanzeigen;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label7;
    }
}