﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class bearbeitenkunde : Form {
        OleDbCommand cmd = null;


        private readonly string connectionString;
        private readonly OleDbConnection con = new OleDbConnection();
        private DataGridViewRow selectedRow;

        public DataGridViewRow UpdatedRow { get; private set; }
        public bearbeitenkunde(DataGridViewRow selectedRow, string connectionString) {
            InitializeComponent();
            this.selectedRow = selectedRow;
            this.connectionString = connectionString;

        }
      

        private void bearbeitenkunde_Load(object sender, EventArgs e) {
            try
            {
                con.ConnectionString = connectionString;
                con.Open();

                // Hier rufe ich eine Methode auf, um die Daten in den Textboxen anzuzeigen
                AnzeigenDerDaten();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler: " + ex.Message);
            }
        }
        private void AnzeigenDerDaten()
        {
            try
            {
                
                tbx_id.Text = selectedRow.Cells["K_id"].Value.ToString();
                tbx_kname.Text = selectedRow.Cells["K_name"].Value.ToString();
                tbx_kust.Text = selectedRow.Cells["K_ust_id"].Value.ToString();
                tbx_kadresse.Text = selectedRow.Cells["K_adresse"].Value.ToString();
                tbx_kliefadresse.Text = selectedRow.Cells["K_lief_adresse"].Value.ToString();
              
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler beim Anzeigen der Daten: " + ex.Message);
            }
        }
        private void BearbeitungAbschließen() {
            try {
                // Überprüfe, ob alle Textboxen ausgefüllt sind
                if (string.IsNullOrEmpty(tbx_kname.Text) || string.IsNullOrEmpty(tbx_kust.Text) || string.IsNullOrEmpty(tbx_kadresse.Text) || string.IsNullOrEmpty(tbx_kliefadresse.Text) || string.IsNullOrEmpty(tbx_id.Text)) {
                    // Zeige eine Meldung an, dass alle Felder ausgefüllt werden müssen
                    MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else {
                    // Führe das Update nur aus, wenn alle Felder ausgefüllt sind
                    cmd = new OleDbCommand("UPDATE Kunden SET K_name='" + tbx_kname.Text + "', K_ust_id=" + Convert.ToInt32(tbx_kust.Text) + ", K_adresse='" + tbx_kadresse.Text + "', K_lief_adresse='" + tbx_kliefadresse.Text + "' WHERE K_id=" + tbx_id.Text, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Erfolgreich bearbeitet!");

                    // Setze UpdatedRow auf die aktualisierte Zeile
                    UpdatedRow = selectedRow;

                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            catch (Exception ex) {
                meldung();
            }

        }
        public void meldung() {
            try {
         

                List<string> numericFieldsKunden = new List<string>();

              
                if (!int.TryParse(tbx_id.Text, out _)) numericFieldsKunden.Add("Kundennummer");
                if (!int.TryParse(tbx_kust.Text, out _)) numericFieldsKunden.Add("USt-Id");

                
                if (numericFieldsKunden.Any()) {
                    MessageBox.Show($"Bitte geben Sie numerische Werte für die folgenden Felder ein: {string.Join(", ", numericFieldsKunden)}");
                    return; 
                }

                if (string.IsNullOrWhiteSpace(tbx_id.Text)
                    || string.IsNullOrWhiteSpace(tbx_kname.Text)
                    || string.IsNullOrWhiteSpace(tbx_kust.Text)
                    || string.IsNullOrWhiteSpace(tbx_kadresse.Text)
                    || string.IsNullOrWhiteSpace(tbx_kliefadresse.Text)) {

                    MessageBox.Show("Bitte füllen Sie alle erforderlichen Felder aus.");
                    return;
                }

                MessageBox.Show("Erfolgreich");
            }
            catch (Exception a) {
                MessageBox.Show("Ein Fehler ist aufgetreten: " + a.Message);
            }



        }

        private void button1_Click(object sender, EventArgs e) {
            BearbeitungAbschließen();
        }

    
        private void button3_Click(object sender, EventArgs e) {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e) {
            Application.Exit();
        }
    }
}
