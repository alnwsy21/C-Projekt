﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kunzecordingsSTARGMBH {
    public partial class Hauptmenü : Form {
        public Hauptmenü() {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e) {
            arbeitskarte.Hide();
            angebot.Hide();
            auftrag.Hide();
            stamdaten.Hide();
            usermitarbeiter.Show();
            usermitarbeiter.BringToFront();
        }

        private void button2_Click(object sender, EventArgs e) {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e) {
            this.Close();
        }

        private void usermitarbeiter_Load(object sender, EventArgs e) {

        }

        private void button4_Click(object sender, EventArgs e) {
            arbeitskarte.Hide();
            angebot.Hide();
            auftrag.Hide();
            usermitarbeiter.Hide();
            stamdaten.Show();
            stamdaten.BringToFront();
        }

        private void btn_rechnung_Click(object sender, EventArgs e) {
            arbeitskarte.Hide();
            angebot.Hide();
            usermitarbeiter.Hide();
            stamdaten.Hide();
            auftrag.Show();
            auftrag.BringToFront();
        }

        private void btn_angebot_Click(object sender, EventArgs e) {
            arbeitskarte.Hide();
            usermitarbeiter.Hide();
            stamdaten.Hide();
            angebot.Show();
            angebot.BringToFront();
        }

        private void btn_prüfung_Click(object sender, EventArgs e) {
            usermitarbeiter.Hide();
            stamdaten.Hide();
            angebot.Hide();
            auftrag.Hide();
            arbeitskarte.Show();
            arbeitskarte.BringToFront();
        }
    }
}
