﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kunzecordingsSTARGMBH {
    public partial class Arbeitskartedaten : UserControl {
        public Arbeitskartedaten() {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e) {
            Arbeitskarteentfernen entfernen = new Arbeitskarteentfernen();
            entfernen.ShowDialog();
        }

        private void btn_prüfung_Click(object sender, EventArgs e) {
            ArbeitskarteAnzeigen anzeigen = new ArbeitskarteAnzeigen();
            anzeigen.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Hinzufügenarbeitskarte hinzufügen = new Hinzufügenarbeitskarte();
            hinzufügen.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            arbeitskartebearbeiten bearbeiten = new arbeitskartebearbeiten();
            bearbeiten.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
