﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH
{
    public partial class arbeitskartebearbeiten : Form
    {
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Kunze.accdb;";
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;
        public arbeitskartebearbeiten()
        {
            InitializeComponent();
        }

        private void LoadData()
        {
            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT P_id, Prob_id, P_eingang, P_fertigstellung_dat, P_fertigstellung_zeit_id, P_abnahme_dat, P_charge_id, P_bemerkung, P_sonstige1, P_sonstige2, P_sonstige3, P_anzahl, P_abgeschlossen, Abnahme_id FROM  Probe_kopf";

                using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection))
                {
                    dataSet = new DataSet();
                    adapter.Fill(dataSet, "P_id");
                    dgbearbeiten.DataSource = dataSet.Tables["P_id"];
                }
            }
            dgbearbeiten.Columns["P_id"].HeaderText = "Prüfungs_nummer";
            dgbearbeiten.Columns["Prob_id"].HeaderText = "Probe_nummer";
            dgbearbeiten.Columns["P_eingang"].HeaderText = "Prüfnugs_eingang";
        }

        private void arbeitskartebearbeiten_Load(object sender, EventArgs e)
        {
            LoadData();
          
        }

        private void dghinzufügen_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //kopf
            if (e.RowIndex >= 0)
            {
                // Hier bekommst du den ausgewählten Mitarbeiter
                DataGridViewRow selectedRow = dgbearbeiten.Rows[e.RowIndex];

               
                bearbeitenarbeitskartekopf bearbeitenForm = new bearbeitenarbeitskartekopf(selectedRow, connectionString);
                DialogResult result = bearbeitenForm.ShowDialog();

                // Wenn die Bearbeitung abgeschlossen ist, lade die aktualisierten Daten
                if (result == DialogResult.OK)
                {
                    LoadData();
                }
            }
        }

    

        private void button1_Click(object sender, EventArgs e)
        {
            BearbeitenArbeitskarteUNTER unter = new BearbeitenArbeitskarteUNTER();
            unter.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
