﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kunzecordingsSTARGMBH {
    public partial class Auftragdaten : UserControl {
        public Auftragdaten() {
            InitializeComponent();
        }

        private void btn_prüfung_Click(object sender, EventArgs e) {
            auftraganzeigen anzeigen = new auftraganzeigen();
            anzeigen.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e) {
            Auftraghinzufügen hinzufügen = new Auftraghinzufügen();
            hinzufügen.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e) {
            Auftragbearbeiten bearbeiten = new Auftragbearbeiten();
            bearbeiten.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e) {
            Auftragentfernen entfernen = new Auftragentfernen();
            entfernen.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
