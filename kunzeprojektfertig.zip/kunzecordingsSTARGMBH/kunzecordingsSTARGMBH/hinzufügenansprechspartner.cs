﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class hinzufügenansprechspartner : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        private mitarbeiteradd mainForm;
        private DataGridViewRow selectedRow;
        public hinzufügenansprechspartner() {
            InitializeComponent();
            this.mainForm = mainForm;
        }
        public hinzufügenansprechspartner(DataGridViewRow selectedRow) : this() {
            this.selectedRow = selectedRow;
            
        }

        private void hinzufügenansprechspartner_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";

                con.Open();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
        }

        private void btn_speichern_Click(object sender, EventArgs e) {
            try
            {
                // Überprüfe, ob alle Textboxen ausgefüllt sind
                if (string.IsNullOrEmpty(tbx_id.Text) || string.IsNullOrEmpty(tbx_avname.Text) || string.IsNullOrEmpty(tbx_anname.Text) || string.IsNullOrEmpty(tbx_tel.Text) || string.IsNullOrEmpty(tbx_email.Text) || string.IsNullOrEmpty(tbx_position.Text))
                {
                    // Zeige eine Meldung an, dass alle Felder ausgefüllt werden müssen
                    MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    // Überprüfe, ob die Ansprechpartner-ID bereits existiert
                    using (OleDbCommand checkCmd = new OleDbCommand("SELECT COUNT(*) FROM Ansprechspartner WHERE Anspr_id = @Anspr_id", con))
                    {
                        // Überprüfe, ob die Ansprechpartner-ID eine ganze Zahl ist
                        if (!int.TryParse(tbx_id.Text, out int ansprId))
                        {
                            MessageBox.Show("Die Ansprechpartner-ID muss eine ganze Zahl sein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }

                        checkCmd.Parameters.AddWithValue("@Anspr_id", ansprId);

                        int existingRecords = (int)checkCmd.ExecuteScalar();

                        if (existingRecords > 0)
                        {
                            // Die Ansprechpartner-ID existiert bereits, zeige eine entsprechende Meldung an
                            MessageBox.Show("Die Ansprechpartner-ID existiert bereits. Bitte wählen Sie eine andere ID.", "Duplikate verhindern", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                        else
                        {
                            // Überprüfe, ob die Telefonnummer eine ganze Zahl ist
                            if (!int.TryParse(tbx_tel.Text, out int telefonnummer))
                            {
                                MessageBox.Show("Die Telefonnummer muss eine ganze Zahl sein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }

                            // Füge den neuen Datensatz ein
                            using (OleDbCommand insertCmd = new OleDbCommand("INSERT INTO Ansprechspartner(Anspr_id, Anspr_vname, Anspr_nname, Anspr_tel, Anspr_email, Anspr_position) VALUES (@Anspr_id, @Anspr_vname, @Anspr_nname, @Anspr_tel, @Anspr_email, @Anspr_position)", con))
                            {
                                insertCmd.Parameters.AddWithValue("@Anspr_id", ansprId);
                                insertCmd.Parameters.AddWithValue("@Anspr_vname", tbx_avname.Text);
                                insertCmd.Parameters.AddWithValue("@Anspr_nname", tbx_anname.Text);
                                insertCmd.Parameters.AddWithValue("@Anspr_tel", telefonnummer);
                                insertCmd.Parameters.AddWithValue("@Anspr_email", tbx_email.Text);
                                insertCmd.Parameters.AddWithValue("@Anspr_position", tbx_position.Text);

                                insertCmd.ExecuteNonQuery();
                            }

                            MessageBox.Show("Erfolgreich");

                            // Rufe die RefreshData-Methode des Hauptformulars auf
                            mainForm?.RefreshData();

                            this.DialogResult = DialogResult.OK;
                            this.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Behandele Ausnahmen hier, wenn die Datenbankoperation fehlschlägt
                MessageBox.Show("Fehler beim Speichern der Daten: " + ex.Message, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                meldung();
            }



        }

        public void meldung() {
            try {
                // Überprüfe, ob alle Textboxen ausgefüllt sind
                if (string.IsNullOrEmpty(tbx_id.Text) || string.IsNullOrEmpty(tbx_avname.Text) || string.IsNullOrEmpty(tbx_anname.Text) || string.IsNullOrEmpty(tbx_tel.Text) || string.IsNullOrEmpty(tbx_email.Text) || string.IsNullOrEmpty(tbx_position.Text)) {
                    // Zeige eine Meldung an, dass alle Felder ausgefüllt werden müssen
                    MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else {
                    // Überprüfe, ob die Zahlenfelder gültige Zahlen enthalten
                    int id, tel;
                    if (!int.TryParse(tbx_id.Text, out id) || !int.TryParse(tbx_tel.Text, out tel)) {
                        MessageBox.Show("Bitte geben Sie gültige Zahlen für ANP_id und Telefon ein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return; // Beende die Methode, da ungültige Zahlen eingegeben wurden
                    }

                    // Führe die Datenbankoperation nur aus, wenn alle Felder ausgefüllt sind und gültige Zahlen eingegeben wurden
                    cmd = new OleDbCommand("INSERT INTO Ansprechspartner(Anspr_id, Anspr_vname, Anspr_nname, Anspr_tel, Anspr_email, Anspr_position) VALUES (" + id + ",'" + tbx_avname.Text + "','" + tbx_anname.Text + "'," + tel + ",'" + tbx_email.Text + "','" + tbx_position.Text + "')", con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Erfolgreich");

                    // Rufe die RefreshData-Methode des Hauptformulars auf
                    mainForm?.RefreshData();

                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            catch (Exception ex) {
                // Behandle Ausnahmen hier, wenn die Datenbankoperation fehlschlägt
                MessageBox.Show("Fehler: " + ex.Message, "Fehler beim Hinzufügen", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            fehlermeldung();

        }
        public void fehlermeldung() {
            if (tbx_id.Text == "") {
                lbl_fehlermeldung.Visible = true;
                lbl_fehlermeldung.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lbl_fehlermeldung.Visible = false;
            }

            if (tbx_avname.Text == "") {
                lbl_fehlername.Visible = true;
                lbl_fehlername.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lbl_fehlername.Visible = false;
            }

            if (tbx_anname.Text == "") {
                lbl_fehlerust.Visible = true;
                lbl_fehlerust.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lbl_fehlerust.Visible = false;
            }

            if (tbx_tel.Text == "") {
                lbl_fehleradresse.Visible = true;
                lbl_fehleradresse.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lbl_fehleradresse.Visible = false;
            }

            if (tbx_email.Text == "") {
                lbl_fehlerliefadresse.Visible = true;
                lbl_fehlerliefadresse.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lbl_fehlerliefadresse.Visible = false;
            }
            if (tbx_position.Text == "") {
                lbl_fehlerliefadresse.Visible = true;
                lbl_fehlerliefadresse.ForeColor = System.Drawing.Color.Red;
            }
            else {
                lbl_fehlerliefadresse.Visible = false;
            }
        }
        private void button2_Click(object sender, EventArgs e) {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e) {
            this.Close();
        }
    }
}
