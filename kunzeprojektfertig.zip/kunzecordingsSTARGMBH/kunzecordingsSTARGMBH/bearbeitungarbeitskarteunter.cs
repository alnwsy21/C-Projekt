﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH
{
    public partial class bearbeitungarbeitskarteunter : Form
    {
        OleDbCommand cmd = null;


        private readonly string connectionString;
        private readonly OleDbConnection con = new OleDbConnection();
        private DataGridViewRow selectedRow;
        public DataGridViewRow UpdatedRow { get; private set; }
        public bearbeitungarbeitskarteunter(DataGridViewRow selectedRow, string connectionString)
        {
            InitializeComponent();
            this.selectedRow = selectedRow;
            this.connectionString = connectionString;
        }

        private void bearbeitungarbeitskarteunter_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = connectionString;
                con.Open();

                // Hier rufe ich eine Methode auf, um die Daten in den Textboxen anzuzeigen
                AnzeigenDerDaten();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler: " + ex.Message);
            }
        }
        private void AnzeigenDerDaten()
        {
            try
            {


                
                tbx_pid.Text = selectedRow.Cells["P_id"].Value.ToString();
                tbx_Pe_id.Text = selectedRow.Cells["Pe_id"].Value.ToString();
                tbx_PE_typ_id.Text = selectedRow.Cells["Pe_typ_id"].Value.ToString();
                tbx_PE_anzahl.Text = selectedRow.Cells["Pe_anzahl"].Value.ToString();
                tbx_pe_temp.Text = selectedRow.Cells["Pe_temp"].Value.ToString();
                tbx_pe_probenform.Text = selectedRow.Cells["Pe_probenform"].Value.ToString();
                tbx_pe_probenlage.Text = selectedRow.Cells["Pe_probenlage"].Value.ToString();
                tbx_pe_norm.Text = selectedRow.Cells["Pe_norm"].Value.ToString();
                tbx_pe_bemerkung.Text = selectedRow.Cells["Pe_bemerkung"].Value.ToString();
                tbx_mid.Text = selectedRow.Cells["M_id"].Value.ToString();
                tbx_P_ergebnis_text.Text = selectedRow.Cells["P_ergebnis_text"].Value.ToString();
                
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler beim Anzeigen der Daten: " + ex.Message);
            }
        }

        private void btn_anzeigen_Click(object sender, EventArgs e)
        {
            try
            {
                // Überprüfe, ob alle Textboxen leer sind
                if (string.IsNullOrWhiteSpace(tbx_Pe_id.Text) || string.IsNullOrWhiteSpace(tbx_PE_typ_id.Text) || string.IsNullOrWhiteSpace(tbx_PE_anzahl.Text) ||
                    string.IsNullOrWhiteSpace(tbx_pe_temp.Text) || string.IsNullOrWhiteSpace(tbx_pe_probenform.Text) || string.IsNullOrWhiteSpace(tbx_pe_probenlage.Text) ||
                    string.IsNullOrWhiteSpace(tbx_pe_norm.Text) || string.IsNullOrWhiteSpace(tbx_pe_bemerkung.Text) || string.IsNullOrWhiteSpace(tbx_mid.Text) ||
                    string.IsNullOrWhiteSpace(tbx_P_ergebnis_text.Text) || string.IsNullOrWhiteSpace(tbx_pid.Text))
                {
                    MessageBox.Show("Alle Felder sind leer. Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Überprüfe, ob die Zahlenfelder gültige Zahlen enthalten
                int peId, peTypId, peAnzahl, mid, pid;

                if (!int.TryParse(tbx_Pe_id.Text, out peId))
                {
                    MessageBox.Show("Bitte geben Sie eine gültige Zahl für Pe_id ein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!int.TryParse(tbx_PE_typ_id.Text, out peTypId))
                {
                    MessageBox.Show("Bitte geben Sie eine gültige Zahl für Pe_typ_id ein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!int.TryParse(tbx_PE_anzahl.Text, out peAnzahl))
                {
                    MessageBox.Show("Bitte geben Sie eine gültige Zahl für Pe_anzahl ein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!int.TryParse(tbx_mid.Text, out mid))
                {
                    MessageBox.Show("Bitte geben Sie eine gültige Zahl für M_id ein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!int.TryParse(tbx_pid.Text, out pid))
                {
                    MessageBox.Show("Bitte geben Sie eine gültige Zahl für P_id ein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                cmd = new OleDbCommand("UPDATE Probe_unter SET Pe_id=" + peId + ", Pe_typ_id=" + peTypId + ", Pe_anzahl=" + peAnzahl + ", Pe_temp='" + tbx_pe_temp.Text +
                    "', Pe_probenform='" + tbx_pe_probenform.Text + "', Pe_probenlage='" + tbx_pe_probenlage.Text + "', Pe_norm='" + tbx_pe_norm.Text +
                    "', Pe_bemerkung='" + tbx_pe_bemerkung.Text + "', M_id=" + mid + ", P_ergebnis_text='" + tbx_P_ergebnis_text.Text + "' WHERE P_id=" + pid, con);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Erfolgreich bearbeitet!");

                // Setze UpdatedRow auf die aktualisierte Zeile
                UpdatedRow = selectedRow;

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler beim Bearbeiten: " + a.Message, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
