﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class Kundenlöschen : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Kunze.accdb;";
        public Kundenlöschen() {
            InitializeComponent();
        }

        private void Kundenlöschen_Load(object sender, EventArgs e) {
            LoadData();
        }
        private void LoadData() {
            using (OleDbConnection connection = new OleDbConnection(connectionString)) {
                connection.Open();
                string query = "SELECT * FROM Kunden";

                using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection)) {
                    dataSet = new DataSet();
                    adapter.Fill(dataSet, "DeineTabelle");
                    dglöschen.DataSource = dataSet.Tables["DeineTabelle"];
                }
            }
        }

        private void dglöschen_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            if (e.RowIndex >= 0) {
                DataGridViewRow selectedRow = dglöschen.Rows[e.RowIndex];

                Löschenkunde löschenForm = new Löschenkunde(selectedRow);
                DialogResult result = löschenForm.ShowDialog();

                if (result == DialogResult.OK) {
                    // Lade die Daten erneut, um die DataGridView zu aktualisieren
                    LoadData();
                }
            }
        }
    }
}
