﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class Ansprechspartnerbearbeiten : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Kunze.accdb;";
        public Ansprechspartnerbearbeiten() {
            InitializeComponent();
        }

        private void Ansprechspartnerbearbeiten_Load(object sender, EventArgs e) {
            LoadData();
        }
        private void LoadData() {
            using (OleDbConnection connection = new OleDbConnection(connectionString)) {
                connection.Open();
                string query = "SELECT Anspr_id, Anspr_vname, Anspr_nname, Anspr_tel, Anspr_email, Anspr_position FROM Ansprechspartner";

                
                
              
                using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection)) {
                    dataSet = new DataSet();
                    adapter.Fill(dataSet, "DeineTabelle");
                    dgbearbeiten.DataSource = dataSet.Tables["DeineTabelle"];
                }
            }
            dgbearbeiten.Columns["Anspr_id"].HeaderText = "Nummer";
            dgbearbeiten.Columns["Anspr_vname"].HeaderText = "Vorname";
            dgbearbeiten.Columns["Anspr_nname"].HeaderText = "Nachname";
            dgbearbeiten.Columns["Anspr_tel"].HeaderText = "Telefon";
            dgbearbeiten.Columns["Anspr_email"].HeaderText = "Email";
            dgbearbeiten.Columns["Anspr_position"].HeaderText = "Position";
        }

        private void dgbearbeiten_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            if (e.RowIndex >= 0) {
                DataGridViewRow selectedRow = dgbearbeiten.Rows[e.RowIndex];

                bearbeitenansprechspartner bearbeitenForm = new bearbeitenansprechspartner(selectedRow, connectionString);
                DialogResult result = bearbeitenForm.ShowDialog();

                if (result == DialogResult.OK) {
                    // Lade die Daten erneut
                    LoadData();

                    
                    dgbearbeiten.CurrentCell = null; 
                    dgbearbeiten.ClearSelection();

                    foreach (DataGridViewRow row in dgbearbeiten.Rows) {
                        if (row.Cells[0].Value != null && row.Cells[0].Value.Equals(selectedRow.Cells[0].Value)) {
                            row.Selected = true;
                            dgbearbeiten.CurrentCell = row.Cells[0];
                            break;
                        }
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
