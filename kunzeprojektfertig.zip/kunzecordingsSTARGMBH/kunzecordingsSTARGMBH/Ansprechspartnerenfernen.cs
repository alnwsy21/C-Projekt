﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace kunzecordingsSTARGMBH {
    public partial class Ansprechspartnerenfernen : Form {
        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = null;
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();

        string mnr = "";
        bool clicked;
        public Ansprechspartnerenfernen() {
            InitializeComponent();
        }

        private void Ansprechspartnerenfernen_Load(object sender, EventArgs e) {
            try { // Verbindung zur Datenbank öffnen
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";
                con.Open();
                con.Close();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }
            try {
                ds.Clear();

                con.Open();
                ada = new OleDbDataAdapter("select Anspr_id, Anspr_vname, Anspr_nname, Anspr_tel, Anspr_email, Anspr_position from Ansprechspartner where Anspr_gelöscht=false", con);

              

                ada.Fill(ds, "Mitarbeiterübersicht");
                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "Mitarbeiterübersicht";
                //spaltenformatierung();
                dgentfernen.Columns["Anspr_id"].HeaderText = "Nummer";
                dgentfernen.Columns["Anspr_vname"].HeaderText = "Vorname";
                dgentfernen.Columns["Anspr_nname"].HeaderText = "Nachname";
                dgentfernen.Columns["Anspr_tel"].HeaderText = "Telefon";
                dgentfernen.Columns["Anspr_email"].HeaderText = "Email";
                dgentfernen.Columns["Anspr_position"].HeaderText = "Position";
                con.Close();
            }
            catch (Exception a) {
                MessageBox.Show("Fehler beim laden der Mitarbeiter Informationen. Bitte wenden sie sich an die IT-Abteilung" + a);
            }
        }

        private void button1_Click(object sender, EventArgs e) {
            if (clicked == true) {
                con.Open();
                cmd = new OleDbCommand("Update Ansprechspartner set Anspr_gelöscht = true where Anspr_id = " + mnr + "", con);
                cmd.ExecuteNonQuery();
                ds.Clear();
                ada.Fill(ds, "Mitarbeiterübersicht");
                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "Mitarbeiterübersicht";
                con.Close();
            }
            else {
                MessageBox.Show("Sie müssen doppelt auf den gewünschten Ansprechspartner Klicken damit sie ihn löschen können");
            }
        }

        private void button2_Click(object sender, EventArgs e) {
            entfernenansprechspartner mItarbeitergelöscht = new entfernenansprechspartner();
            mItarbeitergelöscht.ShowDialog();
            ds.Clear();
            ada.Fill(ds, "Mitarbeiterübersicht");
            dgentfernen.DataSource = ds;
            dgentfernen.DataMember = "Mitarbeiterübersicht";
        }

        private void dg_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            clicked = true;
            if (e.RowIndex >= 0) {
                dgentfernen.CurrentRow.Selected = true;
                mnr = dgentfernen.Rows[e.RowIndex].Cells["Anspr_id"].FormattedValue.ToString();
                label3.Text = dgentfernen.Rows[e.RowIndex].Cells["Anspr_id"].FormattedValue.ToString();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
