﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class Werkstoffbearbeiten : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Kunze.accdb;";
        public Werkstoffbearbeiten() {
            InitializeComponent();
        }

        private void Werkstoffbearbeiten_Load(object sender, EventArgs e) {
            LoadData();
        }
        private void LoadData() {
            using (OleDbConnection connection = new OleDbConnection(connectionString)) {
                connection.Open();
                string query = "SELECT W_id, W_name, W_kurz, W_kennzeichen, W_oberfläche, W_höhe, W_breite, W_länge, W_gewicht FROM Werkstoff";

                using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection)) {
                    dataSet = new DataSet();
                    adapter.Fill(dataSet, "Werkstoff");
                    dgbearbeiten.DataSource = dataSet.Tables["Werkstoff"];
                }
            }
            dgbearbeiten.Columns["W_id"].HeaderText = "Nummer";
            dgbearbeiten.Columns["W_name"].HeaderText = "Name";
            dgbearbeiten.Columns["W_kurz"].HeaderText = "Kurz";
            dgbearbeiten.Columns["W_kennzeichen"].HeaderText = "Kennzeichen";
            dgbearbeiten.Columns["W_oberfläche"].HeaderText = "Oberfläche";
            dgbearbeiten.Columns["W_höhe"].HeaderText = "Höhe";
            dgbearbeiten.Columns["W_breite"].HeaderText = "Breite";
            dgbearbeiten.Columns["W_länge"].HeaderText = "Länge";
            dgbearbeiten.Columns["W_gewicht"].HeaderText = "Gewicht";
            dgbearbeiten.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
        }

        private void dgbearbeiten_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            if (e.RowIndex >= 0) {
                // Hier bekommst du den ausgewählten Mitarbeiter
                DataGridViewRow selectedRow = dgbearbeiten.Rows[e.RowIndex];

                // Öffne ein Formular zum Bearbeiten mit den Daten der ausgewählten Zeile
                bearbeitenwerkstoff bearbeitenForm = new bearbeitenwerkstoff(selectedRow, connectionString);
                DialogResult result = bearbeitenForm.ShowDialog();

                // Wenn die Bearbeitung abgeschlossen ist, lade die aktualisierten Daten
                if (result == DialogResult.OK) {
                    LoadData();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
