﻿
namespace kunzecordingsSTARGMBH {
    partial class hinzufügenwerkstoff {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.tbx_wkurz = new System.Windows.Forms.TextBox();
            this.tbx_wgewicht = new System.Windows.Forms.TextBox();
            this.tbx_wname = new System.Windows.Forms.TextBox();
            this.tbx_wkennzeichen = new System.Windows.Forms.TextBox();
            this.tbx_wlänge = new System.Windows.Forms.TextBox();
            this.tbx_woberfläche = new System.Windows.Forms.TextBox();
            this.tbx_wbreite = new System.Windows.Forms.TextBox();
            this.tbx_whöhe = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.tbx_wnr = new System.Windows.Forms.TextBox();
            this.btn_anzeigen = new System.Windows.Forms.Button();
            this.lbl_fehlermeldung = new System.Windows.Forms.Label();
            this.lblnamefehlermeldung = new System.Windows.Forms.Label();
            this.lblkurzfehlermeldung = new System.Windows.Forms.Label();
            this.lblkennfehlermeldung = new System.Windows.Forms.Label();
            this.lblbreitefehlermeldung = new System.Windows.Forms.Label();
            this.lbllängefehlermeldung = new System.Windows.Forms.Label();
            this.lblhöhefehlermeldung = new System.Windows.Forms.Label();
            this.lbloberfehlermeldung = new System.Windows.Forms.Label();
            this.lblgewichtfehlermeldung = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbx_wkurz
            // 
            this.tbx_wkurz.Location = new System.Drawing.Point(109, 268);
            this.tbx_wkurz.Name = "tbx_wkurz";
            this.tbx_wkurz.Size = new System.Drawing.Size(121, 20);
            this.tbx_wkurz.TabIndex = 38;
            // 
            // tbx_wgewicht
            // 
            this.tbx_wgewicht.Location = new System.Drawing.Point(562, 122);
            this.tbx_wgewicht.Name = "tbx_wgewicht";
            this.tbx_wgewicht.Size = new System.Drawing.Size(121, 20);
            this.tbx_wgewicht.TabIndex = 37;
            // 
            // tbx_wname
            // 
            this.tbx_wname.Location = new System.Drawing.Point(109, 199);
            this.tbx_wname.Name = "tbx_wname";
            this.tbx_wname.Size = new System.Drawing.Size(121, 20);
            this.tbx_wname.TabIndex = 36;
            // 
            // tbx_wkennzeichen
            // 
            this.tbx_wkennzeichen.Location = new System.Drawing.Point(109, 338);
            this.tbx_wkennzeichen.Name = "tbx_wkennzeichen";
            this.tbx_wkennzeichen.Size = new System.Drawing.Size(121, 20);
            this.tbx_wkennzeichen.TabIndex = 35;
            // 
            // tbx_wlänge
            // 
            this.tbx_wlänge.Location = new System.Drawing.Point(338, 338);
            this.tbx_wlänge.Name = "tbx_wlänge";
            this.tbx_wlänge.Size = new System.Drawing.Size(121, 20);
            this.tbx_wlänge.TabIndex = 34;
            // 
            // tbx_woberfläche
            // 
            this.tbx_woberfläche.Location = new System.Drawing.Point(338, 121);
            this.tbx_woberfläche.Name = "tbx_woberfläche";
            this.tbx_woberfläche.Size = new System.Drawing.Size(121, 20);
            this.tbx_woberfläche.TabIndex = 33;
            // 
            // tbx_wbreite
            // 
            this.tbx_wbreite.Location = new System.Drawing.Point(338, 268);
            this.tbx_wbreite.Name = "tbx_wbreite";
            this.tbx_wbreite.Size = new System.Drawing.Size(121, 20);
            this.tbx_wbreite.TabIndex = 32;
            // 
            // tbx_whöhe
            // 
            this.tbx_whöhe.Location = new System.Drawing.Point(338, 199);
            this.tbx_whöhe.Name = "tbx_whöhe";
            this.tbx_whöhe.Size = new System.Drawing.Size(121, 20);
            this.tbx_whöhe.TabIndex = 31;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(335, 164);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(118, 16);
            this.label10.TabIndex = 30;
            this.label10.Text = "Werkstoff_Höhe";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(335, 238);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(122, 16);
            this.label9.TabIndex = 29;
            this.label9.Text = "Werkstoff_Breite";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(559, 92);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(135, 16);
            this.label8.TabIndex = 28;
            this.label8.Text = "Werkstoff_Gewicht";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(106, 305);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(168, 16);
            this.label7.TabIndex = 27;
            this.label7.Text = "Werkstoff_Kennzeichen";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(335, 92);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(157, 16);
            this.label6.TabIndex = 26;
            this.label6.Text = "Werkstoff_Oberfläche";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(335, 305);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(124, 16);
            this.label5.TabIndex = 25;
            this.label5.Text = "Werkstoff_Länge";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(106, 238);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 16);
            this.label4.TabIndex = 24;
            this.label4.Text = "Werkstoff_Kurz";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(106, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 16);
            this.label3.TabIndex = 23;
            this.label3.Text = "Werkstoff_name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(106, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 16);
            this.label2.TabIndex = 22;
            this.label2.Text = "Werkstoff_id";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(151)))), ((int)(((byte)(139)))));
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 60);
            this.panel1.TabIndex = 39;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(103, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(313, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "Werkstoff Hinzufügen";
            // 
            // tbx_wnr
            // 
            this.tbx_wnr.Location = new System.Drawing.Point(109, 141);
            this.tbx_wnr.Name = "tbx_wnr";
            this.tbx_wnr.Size = new System.Drawing.Size(121, 20);
            this.tbx_wnr.TabIndex = 40;
            // 
            // btn_anzeigen
            // 
            this.btn_anzeigen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_anzeigen.Location = new System.Drawing.Point(554, 325);
            this.btn_anzeigen.Name = "btn_anzeigen";
            this.btn_anzeigen.Size = new System.Drawing.Size(129, 33);
            this.btn_anzeigen.TabIndex = 68;
            this.btn_anzeigen.Text = "Hinzufügen";
            this.btn_anzeigen.UseVisualStyleBackColor = true;
            this.btn_anzeigen.Click += new System.EventHandler(this.btn_anzeigen_Click);
            // 
            // lbl_fehlermeldung
            // 
            this.lbl_fehlermeldung.AutoSize = true;
            this.lbl_fehlermeldung.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fehlermeldung.Location = new System.Drawing.Point(106, 125);
            this.lbl_fehlermeldung.Name = "lbl_fehlermeldung";
            this.lbl_fehlermeldung.Size = new System.Drawing.Size(99, 13);
            this.lbl_fehlermeldung.TabIndex = 71;
            this.lbl_fehlermeldung.Text = "Tragen sie was ein!";
            this.lbl_fehlermeldung.Visible = false;
            this.lbl_fehlermeldung.Click += new System.EventHandler(this.lbl_fehlermeldung_Click);
            // 
            // lblnamefehlermeldung
            // 
            this.lblnamefehlermeldung.AutoSize = true;
            this.lblnamefehlermeldung.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnamefehlermeldung.Location = new System.Drawing.Point(106, 183);
            this.lblnamefehlermeldung.Name = "lblnamefehlermeldung";
            this.lblnamefehlermeldung.Size = new System.Drawing.Size(99, 13);
            this.lblnamefehlermeldung.TabIndex = 72;
            this.lblnamefehlermeldung.Text = "Tragen sie was ein!";
            this.lblnamefehlermeldung.Visible = false;
            // 
            // lblkurzfehlermeldung
            // 
            this.lblkurzfehlermeldung.AutoSize = true;
            this.lblkurzfehlermeldung.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblkurzfehlermeldung.Location = new System.Drawing.Point(106, 254);
            this.lblkurzfehlermeldung.Name = "lblkurzfehlermeldung";
            this.lblkurzfehlermeldung.Size = new System.Drawing.Size(99, 13);
            this.lblkurzfehlermeldung.TabIndex = 73;
            this.lblkurzfehlermeldung.Text = "Tragen sie was ein!";
            this.lblkurzfehlermeldung.Visible = false;
            // 
            // lblkennfehlermeldung
            // 
            this.lblkennfehlermeldung.AutoSize = true;
            this.lblkennfehlermeldung.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblkennfehlermeldung.Location = new System.Drawing.Point(106, 325);
            this.lblkennfehlermeldung.Name = "lblkennfehlermeldung";
            this.lblkennfehlermeldung.Size = new System.Drawing.Size(99, 13);
            this.lblkennfehlermeldung.TabIndex = 74;
            this.lblkennfehlermeldung.Text = "Tragen sie was ein!";
            this.lblkennfehlermeldung.Visible = false;
            // 
            // lblbreitefehlermeldung
            // 
            this.lblbreitefehlermeldung.AutoSize = true;
            this.lblbreitefehlermeldung.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbreitefehlermeldung.Location = new System.Drawing.Point(335, 254);
            this.lblbreitefehlermeldung.Name = "lblbreitefehlermeldung";
            this.lblbreitefehlermeldung.Size = new System.Drawing.Size(99, 13);
            this.lblbreitefehlermeldung.TabIndex = 75;
            this.lblbreitefehlermeldung.Text = "Tragen sie was ein!";
            this.lblbreitefehlermeldung.Visible = false;
            // 
            // lbllängefehlermeldung
            // 
            this.lbllängefehlermeldung.AutoSize = true;
            this.lbllängefehlermeldung.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllängefehlermeldung.Location = new System.Drawing.Point(335, 322);
            this.lbllängefehlermeldung.Name = "lbllängefehlermeldung";
            this.lbllängefehlermeldung.Size = new System.Drawing.Size(99, 13);
            this.lbllängefehlermeldung.TabIndex = 76;
            this.lbllängefehlermeldung.Text = "Tragen sie was ein!";
            this.lbllängefehlermeldung.Visible = false;
            // 
            // lblhöhefehlermeldung
            // 
            this.lblhöhefehlermeldung.AutoSize = true;
            this.lblhöhefehlermeldung.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblhöhefehlermeldung.Location = new System.Drawing.Point(335, 183);
            this.lblhöhefehlermeldung.Name = "lblhöhefehlermeldung";
            this.lblhöhefehlermeldung.Size = new System.Drawing.Size(99, 13);
            this.lblhöhefehlermeldung.TabIndex = 77;
            this.lblhöhefehlermeldung.Text = "Tragen sie was ein!";
            this.lblhöhefehlermeldung.Visible = false;
            // 
            // lbloberfehlermeldung
            // 
            this.lbloberfehlermeldung.AutoSize = true;
            this.lbloberfehlermeldung.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbloberfehlermeldung.Location = new System.Drawing.Point(335, 107);
            this.lbloberfehlermeldung.Name = "lbloberfehlermeldung";
            this.lbloberfehlermeldung.Size = new System.Drawing.Size(99, 13);
            this.lbloberfehlermeldung.TabIndex = 78;
            this.lbloberfehlermeldung.Text = "Tragen sie was ein!";
            this.lbloberfehlermeldung.Visible = false;
            // 
            // lblgewichtfehlermeldung
            // 
            this.lblgewichtfehlermeldung.AutoSize = true;
            this.lblgewichtfehlermeldung.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgewichtfehlermeldung.Location = new System.Drawing.Point(559, 108);
            this.lblgewichtfehlermeldung.Name = "lblgewichtfehlermeldung";
            this.lblgewichtfehlermeldung.Size = new System.Drawing.Size(99, 13);
            this.lblgewichtfehlermeldung.TabIndex = 79;
            this.lblgewichtfehlermeldung.Text = "Tragen sie was ein!";
            this.lblgewichtfehlermeldung.Visible = false;
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(704, 32);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(84, 23);
            this.button3.TabIndex = 12;
            this.button3.Text = "zurück";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(704, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(84, 23);
            this.button2.TabIndex = 11;
            this.button2.Text = "beenden";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // hinzufügenwerkstoff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblgewichtfehlermeldung);
            this.Controls.Add(this.lbloberfehlermeldung);
            this.Controls.Add(this.lblhöhefehlermeldung);
            this.Controls.Add(this.lbllängefehlermeldung);
            this.Controls.Add(this.lblbreitefehlermeldung);
            this.Controls.Add(this.lblkennfehlermeldung);
            this.Controls.Add(this.lblkurzfehlermeldung);
            this.Controls.Add(this.lblnamefehlermeldung);
            this.Controls.Add(this.lbl_fehlermeldung);
            this.Controls.Add(this.btn_anzeigen);
            this.Controls.Add(this.tbx_wnr);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tbx_wkurz);
            this.Controls.Add(this.tbx_wgewicht);
            this.Controls.Add(this.tbx_wname);
            this.Controls.Add(this.tbx_wkennzeichen);
            this.Controls.Add(this.tbx_wlänge);
            this.Controls.Add(this.tbx_woberfläche);
            this.Controls.Add(this.tbx_wbreite);
            this.Controls.Add(this.tbx_whöhe);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Name = "hinzufügenwerkstoff";
            this.Text = "hinzufügenwerkstoff";
            this.Load += new System.EventHandler(this.hinzufügenwerkstoff_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbx_wkurz;
        private System.Windows.Forms.TextBox tbx_wgewicht;
        private System.Windows.Forms.TextBox tbx_wname;
        private System.Windows.Forms.TextBox tbx_wkennzeichen;
        private System.Windows.Forms.TextBox tbx_wlänge;
        private System.Windows.Forms.TextBox tbx_woberfläche;
        private System.Windows.Forms.TextBox tbx_wbreite;
        private System.Windows.Forms.TextBox tbx_whöhe;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbx_wnr;
        private System.Windows.Forms.Button btn_anzeigen;
        private System.Windows.Forms.Label lbl_fehlermeldung;
        private System.Windows.Forms.Label lblnamefehlermeldung;
        private System.Windows.Forms.Label lblkurzfehlermeldung;
        private System.Windows.Forms.Label lblkennfehlermeldung;
        private System.Windows.Forms.Label lblbreitefehlermeldung;
        private System.Windows.Forms.Label lbllängefehlermeldung;
        private System.Windows.Forms.Label lblhöhefehlermeldung;
        private System.Windows.Forms.Label lbloberfehlermeldung;
        private System.Windows.Forms.Label lblgewichtfehlermeldung;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
    }
}