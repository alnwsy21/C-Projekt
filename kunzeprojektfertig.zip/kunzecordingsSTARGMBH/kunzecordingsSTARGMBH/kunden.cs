﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kunzecordingsSTARGMBH {
    public partial class kunden : UserControl {
        public kunden() {
            InitializeComponent();
        }

        private void btn_prüfung_Click(object sender, EventArgs e) {
            Kundenanzeigen anzeigen = new Kundenanzeigen();
            anzeigen.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e) {
            kundenhuinzufügen hinzufügen = new kundenhuinzufügen();
            hinzufügen.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e) {
            Kundenbearbeiten bearbeiten = new Kundenbearbeiten();
            bearbeiten.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e) {
            Kundenentfernen entfernen = new Kundenentfernen();
            entfernen.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e) {
            Application.Exit();
        }
    }
}
