﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH
{
    public partial class hinzufügenarbeitskarteunter : Form
    {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;


        private Auftraghinzufügen mainForm;
        private DataGridViewRow selectedRow;
        public hinzufügenarbeitskarteunter()
        {
            InitializeComponent();
            this.mainForm = mainForm;
        }

        public hinzufügenarbeitskarteunter(DataGridViewRow selectedRow) : this()
        {
            this.selectedRow = selectedRow;
           
        }
        private void hinzufügenarbeitskarteunter_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";
                con.Open();

            }
            catch (Exception a)
            {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }

            try
            {
                //der tabelname das kein - enthalten

                cmd = new OleDbCommand("select M_id from Mitarbeiter", con);
                //liest die leseoperation auf die datenbank aus

                dr = cmd.ExecuteReader();
                //liest die datensätze bis zum tabelle
                while (dr.Read())
                {
                    cbx_M_id.Items.Add(dr.GetInt32(0));
                }
            }

            catch (Exception a)
            {
                MessageBox.Show("Tabellen-Zugriffsfehler(Sequentielles suchen):" + a);
            }
        }
        public void fehlermeldung()
        {
            if (tbx_pid.Text == "")
            {
                lbl_fehlermeldung.Visible = true;
                lbl_fehlermeldung.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_fehlermeldung.Visible = false;
            }

            

            if (tbx_pe_bemerkung.Text == "")
            {
                lbl_pe_bemerkung.Visible = true;
                lbl_pe_bemerkung.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_pe_bemerkung.Visible = false;
            }

            if (tbx_pe_norm.Text == "")
            {
                lbl_PE_norm.Visible = true;
                lbl_PE_norm.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_PE_norm.Visible = false;
            }

            if (tbx_pe_probenlage.Text == "")
            {
                lbl_pe_probenlage.Visible = true;
                lbl_pe_probenlage.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_pe_probenlage.Visible = false;
            }
            if (tbx_pe_temp.Text == "")
            {
                lbl_pe_temp.Visible = true;
                lbl_pe_temp.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_pe_temp.Visible = false;
            }
        
            if (tbx_pe_probenform.Text == "")
            {
                lbl_pe_probenform.Visible = true;
                lbl_pe_probenform.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_pe_probenform.Visible = false;
            }

            if (tbx_P_ergebnis_text.Text == "")
            {
                lbl_P_ergebnis_text.Visible = true;
                lbl_P_ergebnis_text.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_P_ergebnis_text.Visible = false;
            }

            if (tbx_PE_anzahl.Text == "")
            {
                lbl_PE_anzahl.Visible = true;
                lbl_PE_anzahl.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_PE_anzahl.Visible = false;
            }

            if (tbx_Pe_id.Text == "")
            {
                lbl_PE_id.Visible = true;
                lbl_PE_id.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_PE_id.Visible = false;
            }

            if (cbx_M_id.Text == "")
            {
                lbl_mid.Visible = true;
                lbl_mid.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbl_mid.Visible = false;
            }

            if (tbx_PE_typ_id.Text == "")
            {
                lbll_pe_typ_id.Visible = true;
                lbll_pe_typ_id.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                lbll_pe_typ_id.Visible = false;
            }
        }

        private void btn_anzeigen_Click(object sender, EventArgs e)
        {
            try
            {
                // Überprüfe, ob alle erforderlichen Felder ausgefüllt sind
                if (string.IsNullOrEmpty(tbx_pid.Text) ||
             string.IsNullOrEmpty(tbx_Pe_id.Text) ||
             string.IsNullOrEmpty(tbx_PE_typ_id.Text) ||
             string.IsNullOrEmpty(tbx_PE_anzahl.Text) ||
             string.IsNullOrEmpty(tbx_pe_temp.Text) ||
             string.IsNullOrEmpty(tbx_pe_probenform.Text) ||
             string.IsNullOrEmpty(tbx_pe_probenlage.Text) ||
             string.IsNullOrEmpty(tbx_pe_norm.Text) ||
             string.IsNullOrEmpty(tbx_pe_bemerkung.Text) ||
             string.IsNullOrEmpty(cbx_M_id.Text) ||
             string.IsNullOrEmpty(tbx_P_ergebnis_text.Text))
                {
                    MessageBox.Show("Bitte füllen Sie alle Felder aus.");
                    fehlermeldung();
                    return;
                }

                // Überprüfe, ob die numerischen Felder gültige Zahlen enthalten
                if (!int.TryParse(tbx_pid.Text, out int P_id) ||
                    !int.TryParse(tbx_Pe_id.Text, out int Pe_id) ||
                    !int.TryParse(tbx_PE_typ_id.Text, out int PE_typ_id) ||
                    !int.TryParse(tbx_PE_anzahl.Text, out int PE_anzahl) ||
                    !int.TryParse(cbx_M_id.Text, out int M_id))
                {
                    MessageBox.Show("Bitte geben Sie für P_id, PE_id, PE_typ_id, PE_anzahl und M_id gültige Zahlen ein.");
                    fehlermeldung();
                    return;
                }

                // Überprüfe, ob der Datensatz bereits existiert
                using (OleDbCommand checkCmd = new OleDbCommand("SELECT COUNT(*) FROM Probe_unter WHERE P_id = ?", con))
                {
                    checkCmd.Parameters.AddWithValue("P_id", P_id);

                    int count = (int)checkCmd.ExecuteScalar();

                    if (count > 0)
                    {
                        MessageBox.Show("Der Datensatz mit P_id " + P_id + " existiert bereits.");
                        fehlermeldung();
                        return;
                    }
                }

                // Führe den Datenbankbefehl aus
                cmd = new OleDbCommand("INSERT INTO Probe_unter(P_id, Pe_id, Pe_typ_id, Pe_anzahl, Pe_temp, Pe_probenform, Pe_probenlage, Pe_norm, Pe_bemerkung, M_id, P_ergebnis_text) " +
                    "VALUES (" + P_id + "," + Pe_id + "," + PE_typ_id + "," + PE_anzahl + ",'" + tbx_pe_temp.Text + "','" + tbx_pe_probenform.Text + "','" + tbx_pe_probenlage.Text + "','" + tbx_pe_norm.Text + "','" + tbx_pe_bemerkung.Text + "'," + M_id + ",'" + tbx_P_ergebnis_text.Text + "')", con);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Erfolgreich");

                // Rufe die RefreshData-Methode des Hauptformulars auf
                mainForm?.RefreshData();

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler beim Hinzufügen: " + a.Message);
            }



        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cbx_M_id_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
