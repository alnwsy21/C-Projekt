﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class bearbeitenansprechspartner : Form {
        OleDbCommand cmd = null;


        private readonly string connectionString;
        private readonly OleDbConnection con = new OleDbConnection();
        private DataGridViewRow selectedRow;

        public DataGridViewRow UpdatedRow { get; private set; }
        public bearbeitenansprechspartner(DataGridViewRow selectedRow, string connectionString) {
            InitializeComponent();
            this.selectedRow = selectedRow;
            this.connectionString = connectionString;
        }
       
        private void bearbeitenansprechspartner_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = connectionString;
                con.Open();

                // Hier rufe ich eine Methode auf, um die Daten in den Textboxen anzuzeigen
                AnzeigenDerDaten();
            }
            catch (Exception ex) {
                MessageBox.Show("Fehler: " + ex.Message);
            }
        }
        private void AnzeigenDerDaten() {
            try {
               
                tbx_id.Text = selectedRow.Cells["Anspr_id"].Value.ToString();
                tbx_avname.Text = selectedRow.Cells["Anspr_vname"].Value.ToString();
                tbx_anname.Text = selectedRow.Cells["Anspr_nname"].Value.ToString();
                tbx_tel.Text = selectedRow.Cells["Anspr_tel"].Value.ToString();
                tbx_email.Text = selectedRow.Cells["Anspr_email"].Value.ToString();
                tbx_email.Text = selectedRow.Cells["Anspr_email"].Value.ToString();
                tbx_position.Text = selectedRow.Cells["Anspr_position"].Value.ToString();
              
            }
            catch (Exception ex) {
                MessageBox.Show("Fehler beim Anzeigen der Daten: " + ex.Message);
            }
        }
        private void BearbeitungAbschließen() {
            try {
                // Überprüfe, ob alle Textboxen ausgefüllt sind
                if (string.IsNullOrEmpty(tbx_id.Text) || string.IsNullOrEmpty(tbx_avname.Text) || string.IsNullOrEmpty(tbx_anname.Text) || string.IsNullOrEmpty(tbx_tel.Text) || string.IsNullOrEmpty(tbx_email.Text) || string.IsNullOrEmpty(tbx_position.Text)) {
                    // Zeige eine Meldung an, dass alle Felder ausgefüllt werden müssen
                    MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else {
                    // Überprüfe, ob die Zahlenfelder gültige Zahlen enthalten
                    int id, tel;
                    if (!int.TryParse(tbx_id.Text, out id) || !int.TryParse(tbx_tel.Text, out tel)) {
                        MessageBox.Show("Bitte geben Sie gültige Zahlen für ID und Telefon ein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return; // Beende die Methode, da ungültige Zahlen eingegeben wurden
                    }

                    // Führe die Datenbankaktualisierung durch
                    cmd = new OleDbCommand("update Ansprechspartner set Anspr_vname='" + tbx_avname.Text + "', Anspr_nname='" + tbx_anname.Text + "', Anspr_tel='" + tel + "', Anspr_email='" + tbx_email.Text + "', Anspr_position='" + tbx_position.Text + "' where Anspr_id = " + id, con);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Erfolgreich bearbeitet!");

                    // Setze UpdatedRow auf die aktualisierte Zeile
                    UpdatedRow = selectedRow;

                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            catch (Exception ex) {
                meldung();
            }


        }


        public void meldung() {
            try {
                // Überprüfe, ob alle Textboxen ausgefüllt sind
                if (string.IsNullOrEmpty(tbx_avname.Text) || string.IsNullOrEmpty(tbx_anname.Text) || string.IsNullOrEmpty(tbx_email.Text) || string.IsNullOrEmpty(tbx_position.Text)) {
                    // Zeige eine Meldung an, dass alle Felder ausgefüllt werden müssen
                    MessageBox.Show("Bitte füllen Sie alle Pflichtfelder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else {
                    // Führe das Update nur aus, wenn alle Pflichtfelder ausgefüllt sind
                    cmd = new OleDbCommand("UPDATE Ansprechspartner SET Anspr_vname='" + tbx_avname.Text + "', Anspr_nname='" + tbx_anname.Text + "', Anspr_tel='" + Convert.ToInt32(tbx_tel.Text) + "', Anspr_email='" + tbx_email.Text + "', Anspr_position='" + tbx_position.Text + "' WHERE Anspr_id = " + Convert.ToInt32(tbx_id.Text), con);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Erfolgreich bearbeitet!");

                    // Setze UpdatedRow auf die aktualisierte Zeile
                    UpdatedRow = selectedRow;

                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            catch (Exception ex) {
                // Behandele Ausnahmen hier, wenn das Update fehlschlägt
                MessageBox.Show("Fehler: " + ex.Message, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }
        private void btn_speichern_Click(object sender, EventArgs e) {
            BearbeitungAbschließen();
        }

        private void button2_Click(object sender, EventArgs e) {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e) {
            this.Close();
        }
    }
}
