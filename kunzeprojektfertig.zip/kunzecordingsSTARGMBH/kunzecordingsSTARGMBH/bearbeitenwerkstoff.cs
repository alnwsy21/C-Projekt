﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class bearbeitenwerkstoff : Form {
        OleDbCommand cmd = null;


        private readonly string connectionString;
        private readonly OleDbConnection con = new OleDbConnection();
        private DataGridViewRow selectedRow;
        public DataGridViewRow UpdatedRow { get; private set; }
        public bearbeitenwerkstoff(DataGridViewRow selectedRow, string connectionString) {
            InitializeComponent();
            this.selectedRow = selectedRow;
            this.connectionString = connectionString;
        }
       
        private void bearbeitenwerkstoff_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = connectionString;
                con.Open();

                // Hier rufe ich eine Methode auf, um die Daten in den Textboxen anzuzeigen
                AnzeigenDerDaten();
            }
            catch (Exception ex) {
                MessageBox.Show("Fehler: " + ex.Message);
            }
        }
        private void AnzeigenDerDaten() {
            try {
               
                tbx_id.Text = selectedRow.Cells["W_id"].Value.ToString();
                tbx_wname.Text = selectedRow.Cells["W_name"].Value.ToString();
                tbx_wkurz.Text = selectedRow.Cells["W_kurz"].Value.ToString();
                tbx_wkennzeichen.Text = selectedRow.Cells["W_kennzeichen"].Value.ToString();
                tbx_woberfläche.Text = selectedRow.Cells["W_oberfläche"].Value.ToString();
                tbx_whöhe.Text = selectedRow.Cells["W_höhe"].Value.ToString();
                tbx_wbreite.Text = selectedRow.Cells["W_breite"].Value.ToString();
                tbx_wlänge.Text = selectedRow.Cells["W_länge"].Value.ToString();
                tbx_wgewicht.Text = selectedRow.Cells["W_gewicht"].Value.ToString();
                
            }
            catch (Exception ex) {
                MessageBox.Show("Fehler beim Anzeigen der Daten: " + ex.Message);
            }
        }

        private void BearbeitungAbschließen() {
            try {
                // Überprüfe, ob alle Textboxen ausgefüllt sind
                if (string.IsNullOrEmpty(tbx_wname.Text) || string.IsNullOrEmpty(tbx_wkurz.Text) || string.IsNullOrEmpty(tbx_wkennzeichen.Text) || string.IsNullOrEmpty(tbx_woberfläche.Text) || string.IsNullOrEmpty(tbx_whöhe.Text) || string.IsNullOrEmpty(tbx_wbreite.Text) || string.IsNullOrEmpty(tbx_wlänge.Text) || string.IsNullOrEmpty(tbx_wgewicht.Text) || string.IsNullOrEmpty(tbx_id.Text)) {
                    // Zeige eine Meldung an, dass alle Felder ausgefüllt werden müssen
                    MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else {
                    // Führe das Update nur aus, wenn alle Felder ausgefüllt sind
                    cmd = new OleDbCommand("UPDATE Werkstoff SET W_name='" + tbx_wname.Text + "', W_kurz='" + tbx_wkurz.Text + "', W_kennzeichen='" + tbx_wkennzeichen.Text + "', W_oberfläche=" + Convert.ToInt32(tbx_woberfläche.Text) + ", W_höhe=" + Convert.ToInt32(tbx_whöhe.Text) + ", W_breite=" + Convert.ToInt32(tbx_wbreite.Text) + ", W_länge=" + Convert.ToInt32(tbx_wlänge.Text) + ", W_gewicht=" + Convert.ToInt32(tbx_wgewicht.Text) + " WHERE W_id=" + Convert.ToInt32(tbx_id.Text), con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Erfolgreich bearbeitet!");

                    // Setze UpdatedRow auf die aktualisierte Zeile
                    UpdatedRow = selectedRow;

                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            catch (Exception) {
                meldung();
            }

        }

        public void meldung() {
            try {
                // Überprüfe, ob alle Textboxen ausgefüllt sind
                if (string.IsNullOrEmpty(tbx_id.Text) || string.IsNullOrEmpty(tbx_wname.Text) || string.IsNullOrEmpty(tbx_wkurz.Text) || string.IsNullOrEmpty(tbx_wkennzeichen.Text) || string.IsNullOrEmpty(tbx_woberfläche.Text) || string.IsNullOrEmpty(tbx_whöhe.Text) || string.IsNullOrEmpty(tbx_wbreite.Text) || string.IsNullOrEmpty(tbx_wlänge.Text) || string.IsNullOrEmpty(tbx_wgewicht.Text)) {
                    // Zeige eine Meldung an, dass alle Felder ausgefüllt werden müssen
                    MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else {
                    // Überprüfe, ob die Zahlenfelder gültige Zahlen enthalten
                    int id, oberfläche, höhe, breite, länge, gewicht;
                    if (!int.TryParse(tbx_id.Text, out id) || !int.TryParse(tbx_woberfläche.Text, out oberfläche) || !int.TryParse(tbx_whöhe.Text, out höhe) || !int.TryParse(tbx_wbreite.Text, out breite) || !int.TryParse(tbx_wlänge.Text, out länge) || !int.TryParse(tbx_wgewicht.Text, out gewicht)) {
                        MessageBox.Show("Bitte geben Sie gültige Zahlen für ID, Oberfläche, Höhe, Breite, Länge und Gewicht ein.", "Ungültige Eingabe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return; // Beende die Methode, da ungültige Zahlen eingegeben wurden
                    }

                    // Führe die Datenbankaktualisierung durch
                    cmd = new OleDbCommand("update Werkstoff set W_name='" + tbx_wname.Text + "', W_kurz='" + tbx_wkurz.Text + "', W_kennzeichen='" + tbx_wkennzeichen.Text + "', W_oberfläche=" + oberfläche + ", W_höhe=" + höhe + ", W_breite=" + breite + ", W_länge=" + länge + ", W_gewicht=" + gewicht + " where W_id = " + id, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Erfolgreich bearbeitet!");

                    // Setze UpdatedRow auf die aktualisierte Zeile
                    UpdatedRow = selectedRow;

                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            catch (Exception ex) {
                MessageBox.Show("Fehler: " + ex.Message, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btn_anzeigen_Click(object sender, EventArgs e) {
            BearbeitungAbschließen();
        }

        private void button2_Click(object sender, EventArgs e) {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e) {
            this.Close();
        }
    }
}
