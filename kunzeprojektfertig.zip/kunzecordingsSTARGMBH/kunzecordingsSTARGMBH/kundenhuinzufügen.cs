﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class kundenhuinzufügen : Form {
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Kunze.accdb;";
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;
        public kundenhuinzufügen() {
            InitializeComponent();
        }

        private void kundenhuinzufügen_Load(object sender, EventArgs e) {
            LoadData();
        }
        public void RefreshData() {
            LoadData();
        }
        private void LoadData() {
            using (OleDbConnection connection = new OleDbConnection(connectionString)) {
                connection.Open();
                string query = "SELECT K_id, K_name, K_ust_id, K_adresse, K_lief_adresse FROM Kunden";

                using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection)) {
                    dataSet = new DataSet();
                    adapter.Fill(dataSet, "DeineTabelle");
                    dghinzufügen.DataSource = dataSet.Tables["DeineTabelle"];
                }
            }
            dghinzufügen.Columns["K_id"].HeaderText = "Nummer";
            dghinzufügen.Columns["K_name"].HeaderText = "Name";
            dghinzufügen.Columns["K_ust_id"].HeaderText = "Umsatzsteuer_nummer";
            dghinzufügen.Columns["K_adresse"].HeaderText = "Adresse";
            dghinzufügen.Columns["K_lief_adresse"].HeaderText = "Liefer_adresse";
            dghinzufügen.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            if (e.RowIndex >= 0) {
                // Hier bekommst du den ausgewählten Mitarbeiter
                DataGridViewRow selectedRow = dghinzufügen.Rows[e.RowIndex];

                //  Öffne ein Formular zum Bearbeiten mit den Daten der ausgewählten Zeile
                hinzufügenkunde bearbeitenForm = new hinzufügenkunde(selectedRow);
                DialogResult result = bearbeitenForm.ShowDialog();

                // Wenn die Bearbeitung abgeschlossen ist, lade die aktualisierten Daten
                if (result == DialogResult.OK) {
                    LoadData();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
