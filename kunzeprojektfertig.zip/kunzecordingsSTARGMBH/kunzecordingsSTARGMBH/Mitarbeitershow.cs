﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class Mitarbeitershow : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public Mitarbeitershow() {
            InitializeComponent();
        }

        private void Mitarbeitershow_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";

                con.Open();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }

            try {
                ds.Clear();

                ada = new OleDbDataAdapter("SELECT M_id, M_vname, M_nname, M_pass, M_admin FROM Mitarbeiter", con);
                ada.Fill(ds, "mitarbeiter");
                dganzeigen.DataSource = ds;
                dganzeigen.DataMember = "mitarbeiter";
                con.Close();
                dganzeigen.Columns["M_id"].HeaderText = "Nummer";
                dganzeigen.Columns["M_vname"].HeaderText = "Vorname";
                dganzeigen.Columns["M_pass"].HeaderText = "Password";
                dganzeigen.Columns["M_admin"].HeaderText = "Benutzernamen";
                dganzeigen.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            }
            catch (Exception) {

                MessageBox.Show("fehler");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
