﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class entfernenkunde : Form {
        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = null;
        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
     

        bool clicked;
        string mnr = "";
        public entfernenkunde() {
            InitializeComponent();
 
        }
    
        private void entfernenkunde_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source= Kunze.accdb";
                con.Open();
                con.Close();
            }
            catch {
                MessageBox.Show("Die Datenbank konnte nicht geöffnet werden");
            }
            try {
                con.Open();
                ada = new OleDbDataAdapter("select * from Kunden where K_gelöscht = true", con);
                ada.Fill(ds, "Kundengelöscht");
                dgentfernen.DataSource = ds;
                dgentfernen.DataMember = "Kundengelöscht";
                con.Close();
        
                dgentfernen.Columns["K_id"].HeaderText = "Nummer";
                dgentfernen.Columns["K_name"].HeaderText = "Name";
                dgentfernen.Columns["K_ust_id"].HeaderText = "Umsatzsteuer_nummer";
                dgentfernen.Columns["K_adresse"].HeaderText = "Adresse";
                dgentfernen.Columns["K_lief_adresse"].HeaderText = "Liefer_adresse";
                dgentfernen.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            }
            catch {
                MessageBox.Show("Der Datensatz konnte nicht gelöscht werden");
            }
        }

        private void button1_Click(object sender, EventArgs e) {
            try
            {
                if (dgentfernen.SelectedRows.Count > 0)
                {
                    con.Open();
                    int mnr = Convert.ToInt32(dgentfernen.SelectedRows[0].Cells["K_id"].Value);
                    cmd = new OleDbCommand("Update kunden set K_gelöscht = false where K_id = " + mnr, con);
                    cmd.ExecuteNonQuery();
                    ds.Clear();
                    ada.Fill(ds, "Kundengelöscht");
                    dgentfernen.DataSource = ds;
                    dgentfernen.DataMember = "Kundengelöscht";
                    con.Close();
                }
                else
                {
                    MessageBox.Show("Bitte wählen Sie einen Datensatz aus, um ihn zu aktualisieren.");
                }
            }
            catch (Exception a)
            {
                MessageBox.Show("Der Datensatz konnte nicht hinzugefügt werden" + a);
            }

        }

        private void dgentfernen_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            clicked = true;
            if (e.RowIndex >= 0) {
                dgentfernen.CurrentRow.Selected = true;
                mnr = dgentfernen.Rows[e.RowIndex].Cells["K_id"].FormattedValue.ToString();
                label3.Text = dgentfernen.Rows[e.RowIndex].Cells["K_id"].FormattedValue.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
