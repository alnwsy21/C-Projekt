﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class Werkstoffanzeigen : Form {
        OleDbCommand cmd = null;
        OleDbConnection con = new OleDbConnection();
        OleDbDataReader dr = null;

        OleDbDataAdapter ada = null;
        DataSet ds = new DataSet();
        public Werkstoffanzeigen() {
            InitializeComponent();
        }

        private void Werkstoffanzeigen_Load(object sender, EventArgs e) {
            try {
                con.ConnectionString = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Kunze.accdb";

                con.Open();
            }
            catch (Exception a) {
                MessageBox.Show("Datenbank-öffnungsfehler:" + a);
            }

            try {
                ds.Clear();

                ada = new OleDbDataAdapter("select W_id, W_name, W_kurz, W_kennzeichen, W_oberfläche, W_höhe, W_breite, W_länge, W_gewicht from Werkstoff", con);
                ada.Fill(ds, "kunden1");
               dganzeigen.DataSource = ds;
               dganzeigen.DataMember = "kunden1";
                con.Close();
                dganzeigen.Columns["W_id"].HeaderText = "Nummer";
                dganzeigen.Columns["W_name"].HeaderText = "Name";
                dganzeigen.Columns["W_kurz"].HeaderText = "Kurz";
                dganzeigen.Columns["W_kennzeichen"].HeaderText = "Kennzeichen";
                dganzeigen.Columns["W_oberfläche"].HeaderText = "Oberfläche";
                dganzeigen.Columns["W_höhe"].HeaderText = "Höhe";
                dganzeigen.Columns["W_breite"].HeaderText = "Breite";
                dganzeigen.Columns["W_länge"].HeaderText = "Länge";
                dganzeigen.Columns["W_gewicht"].HeaderText = "Gewicht";
                dganzeigen.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            }
            catch (Exception) {

                MessageBox.Show("fehler");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
