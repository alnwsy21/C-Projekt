﻿
namespace kunzecordingsSTARGMBH
{
    partial class hinzufügenarbeitskartekopf
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.lbl_abgeschlossen = new System.Windows.Forms.Label();
            this.tbx_abgeschlossen = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.lbl_sonstige3 = new System.Windows.Forms.Label();
            this.tbx_sonstige3 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.lbl_anzahl = new System.Windows.Forms.Label();
            this.tbx_anzahl = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.lbl_sonstige2 = new System.Windows.Forms.Label();
            this.lbl_abnahmedat = new System.Windows.Forms.Label();
            this.lbl_charge = new System.Windows.Forms.Label();
            this.lbl_sonstige1 = new System.Windows.Forms.Label();
            this.lbl_bemerkung = new System.Windows.Forms.Label();
            this.lbl_fertzeitid = new System.Windows.Forms.Label();
            this.lbl_fertdatum = new System.Windows.Forms.Label();
            this.lbl_prob = new System.Windows.Forms.Label();
            this.lbl_fehlermeldung = new System.Windows.Forms.Label();
            this.btn_anzeigen = new System.Windows.Forms.Button();
            this.tbx_pid = new System.Windows.Forms.TextBox();
            this.tbx_fertdat = new System.Windows.Forms.TextBox();
            this.tbx_sonstige2 = new System.Windows.Forms.TextBox();
            this.tbx_sonstige1 = new System.Windows.Forms.TextBox();
            this.tbx_abnahme_dat = new System.Windows.Forms.TextBox();
            this.tbx_bemerkung = new System.Windows.Forms.TextBox();
            this.tbx_chargeid = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_abnahmeid = new System.Windows.Forms.Label();
            this.tbx_abnahme_id = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.lbl_eingang = new System.Windows.Forms.Label();
            this.tbx_eingang = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.cbx_abnahme_id = new System.Windows.Forms.ComboBox();
            this.cbx_fertzeitid = new System.Windows.Forms.ComboBox();
            this.cbx_prob = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(151)))), ((int)(((byte)(139)))));
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(855, 60);
            this.panel1.TabIndex = 8;
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(742, 32);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(84, 23);
            this.button3.TabIndex = 216;
            this.button3.Text = "zurück";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(102, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(536, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "Arbeitskarte_kopf Hinzufügen";
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(742, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(84, 23);
            this.button2.TabIndex = 215;
            this.button2.Text = "beenden";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lbl_abgeschlossen
            // 
            this.lbl_abgeschlossen.AutoSize = true;
            this.lbl_abgeschlossen.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_abgeschlossen.Location = new System.Drawing.Point(654, 92);
            this.lbl_abgeschlossen.Name = "lbl_abgeschlossen";
            this.lbl_abgeschlossen.Size = new System.Drawing.Size(130, 17);
            this.lbl_abgeschlossen.TabIndex = 153;
            this.lbl_abgeschlossen.Text = "Tragen sie was ein!";
            this.lbl_abgeschlossen.Visible = false;
            // 
            // tbx_abgeschlossen
            // 
            this.tbx_abgeschlossen.Location = new System.Drawing.Point(657, 106);
            this.tbx_abgeschlossen.Name = "tbx_abgeschlossen";
            this.tbx_abgeschlossen.Size = new System.Drawing.Size(121, 20);
            this.tbx_abgeschlossen.TabIndex = 152;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(654, 76);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(156, 20);
            this.label13.TabIndex = 151;
            this.label13.Text = "P_abgeschlossen";
            // 
            // lbl_sonstige3
            // 
            this.lbl_sonstige3.AutoSize = true;
            this.lbl_sonstige3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sonstige3.Location = new System.Drawing.Point(475, 236);
            this.lbl_sonstige3.Name = "lbl_sonstige3";
            this.lbl_sonstige3.Size = new System.Drawing.Size(130, 17);
            this.lbl_sonstige3.TabIndex = 150;
            this.lbl_sonstige3.Text = "Tragen sie was ein!";
            this.lbl_sonstige3.Visible = false;
            // 
            // tbx_sonstige3
            // 
            this.tbx_sonstige3.Location = new System.Drawing.Point(478, 250);
            this.tbx_sonstige3.Name = "tbx_sonstige3";
            this.tbx_sonstige3.Size = new System.Drawing.Size(121, 20);
            this.tbx_sonstige3.TabIndex = 149;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(475, 220);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(112, 20);
            this.label14.TabIndex = 148;
            this.label14.Text = "P_sonstige3";
            // 
            // lbl_anzahl
            // 
            this.lbl_anzahl.AutoSize = true;
            this.lbl_anzahl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_anzahl.Location = new System.Drawing.Point(475, 310);
            this.lbl_anzahl.Name = "lbl_anzahl";
            this.lbl_anzahl.Size = new System.Drawing.Size(130, 17);
            this.lbl_anzahl.TabIndex = 147;
            this.lbl_anzahl.Text = "Tragen sie was ein!";
            this.lbl_anzahl.Visible = false;
            // 
            // tbx_anzahl
            // 
            this.tbx_anzahl.Location = new System.Drawing.Point(478, 324);
            this.tbx_anzahl.Name = "tbx_anzahl";
            this.tbx_anzahl.Size = new System.Drawing.Size(121, 20);
            this.tbx_anzahl.TabIndex = 146;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(475, 294);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(86, 20);
            this.label12.TabIndex = 145;
            this.label12.Text = "P_anzahl";
            // 
            // lbl_sonstige2
            // 
            this.lbl_sonstige2.AutoSize = true;
            this.lbl_sonstige2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sonstige2.Location = new System.Drawing.Point(475, 164);
            this.lbl_sonstige2.Name = "lbl_sonstige2";
            this.lbl_sonstige2.Size = new System.Drawing.Size(130, 17);
            this.lbl_sonstige2.TabIndex = 144;
            this.lbl_sonstige2.Text = "Tragen sie was ein!";
            this.lbl_sonstige2.Visible = false;
            // 
            // lbl_abnahmedat
            // 
            this.lbl_abnahmedat.AutoSize = true;
            this.lbl_abnahmedat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_abnahmedat.Location = new System.Drawing.Point(259, 177);
            this.lbl_abnahmedat.Name = "lbl_abnahmedat";
            this.lbl_abnahmedat.Size = new System.Drawing.Size(130, 17);
            this.lbl_abnahmedat.TabIndex = 143;
            this.lbl_abnahmedat.Text = "Tragen sie was ein!";
            this.lbl_abnahmedat.Visible = false;
            // 
            // lbl_charge
            // 
            this.lbl_charge.AutoSize = true;
            this.lbl_charge.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_charge.Location = new System.Drawing.Point(259, 253);
            this.lbl_charge.Name = "lbl_charge";
            this.lbl_charge.Size = new System.Drawing.Size(130, 17);
            this.lbl_charge.TabIndex = 142;
            this.lbl_charge.Text = "Tragen sie was ein!";
            this.lbl_charge.Visible = false;
            // 
            // lbl_sonstige1
            // 
            this.lbl_sonstige1.AutoSize = true;
            this.lbl_sonstige1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sonstige1.Location = new System.Drawing.Point(474, 93);
            this.lbl_sonstige1.Name = "lbl_sonstige1";
            this.lbl_sonstige1.Size = new System.Drawing.Size(130, 17);
            this.lbl_sonstige1.TabIndex = 141;
            this.lbl_sonstige1.Text = "Tragen sie was ein!";
            this.lbl_sonstige1.Visible = false;
            // 
            // lbl_bemerkung
            // 
            this.lbl_bemerkung.AutoSize = true;
            this.lbl_bemerkung.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bemerkung.Location = new System.Drawing.Point(259, 324);
            this.lbl_bemerkung.Name = "lbl_bemerkung";
            this.lbl_bemerkung.Size = new System.Drawing.Size(130, 17);
            this.lbl_bemerkung.TabIndex = 140;
            this.lbl_bemerkung.Text = "Tragen sie was ein!";
            this.lbl_bemerkung.Visible = false;
            // 
            // lbl_fertzeitid
            // 
            this.lbl_fertzeitid.AutoSize = true;
            this.lbl_fertzeitid.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fertzeitid.Location = new System.Drawing.Point(258, 109);
            this.lbl_fertzeitid.Name = "lbl_fertzeitid";
            this.lbl_fertzeitid.Size = new System.Drawing.Size(130, 17);
            this.lbl_fertzeitid.TabIndex = 139;
            this.lbl_fertzeitid.Text = "Tragen sie was ein!";
            this.lbl_fertzeitid.Visible = false;
            // 
            // lbl_fertdatum
            // 
            this.lbl_fertdatum.AutoSize = true;
            this.lbl_fertdatum.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fertdatum.Location = new System.Drawing.Point(27, 323);
            this.lbl_fertdatum.Name = "lbl_fertdatum";
            this.lbl_fertdatum.Size = new System.Drawing.Size(130, 17);
            this.lbl_fertdatum.TabIndex = 138;
            this.lbl_fertdatum.Text = "Tragen sie was ein!";
            this.lbl_fertdatum.Visible = false;
            // 
            // lbl_prob
            // 
            this.lbl_prob.AutoSize = true;
            this.lbl_prob.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_prob.Location = new System.Drawing.Point(28, 167);
            this.lbl_prob.Name = "lbl_prob";
            this.lbl_prob.Size = new System.Drawing.Size(130, 17);
            this.lbl_prob.TabIndex = 137;
            this.lbl_prob.Text = "Tragen sie was ein!";
            this.lbl_prob.Visible = false;
            // 
            // lbl_fehlermeldung
            // 
            this.lbl_fehlermeldung.AutoSize = true;
            this.lbl_fehlermeldung.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fehlermeldung.Location = new System.Drawing.Point(28, 109);
            this.lbl_fehlermeldung.Name = "lbl_fehlermeldung";
            this.lbl_fehlermeldung.Size = new System.Drawing.Size(130, 17);
            this.lbl_fehlermeldung.TabIndex = 136;
            this.lbl_fehlermeldung.Text = "Tragen sie was ein!";
            this.lbl_fehlermeldung.Visible = false;
            // 
            // btn_anzeigen
            // 
            this.btn_anzeigen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_anzeigen.Location = new System.Drawing.Point(649, 377);
            this.btn_anzeigen.Name = "btn_anzeigen";
            this.btn_anzeigen.Size = new System.Drawing.Size(129, 33);
            this.btn_anzeigen.TabIndex = 135;
            this.btn_anzeigen.Text = "Hinzufügen";
            this.btn_anzeigen.UseVisualStyleBackColor = true;
            this.btn_anzeigen.Click += new System.EventHandler(this.btn_anzeigen_Click);
            // 
            // tbx_pid
            // 
            this.tbx_pid.Location = new System.Drawing.Point(31, 125);
            this.tbx_pid.Name = "tbx_pid";
            this.tbx_pid.Size = new System.Drawing.Size(121, 20);
            this.tbx_pid.TabIndex = 134;
            // 
            // tbx_fertdat
            // 
            this.tbx_fertdat.Location = new System.Drawing.Point(30, 337);
            this.tbx_fertdat.Name = "tbx_fertdat";
            this.tbx_fertdat.Size = new System.Drawing.Size(121, 20);
            this.tbx_fertdat.TabIndex = 133;
            // 
            // tbx_sonstige2
            // 
            this.tbx_sonstige2.Location = new System.Drawing.Point(478, 178);
            this.tbx_sonstige2.Name = "tbx_sonstige2";
            this.tbx_sonstige2.Size = new System.Drawing.Size(121, 20);
            this.tbx_sonstige2.TabIndex = 132;
            // 
            // tbx_sonstige1
            // 
            this.tbx_sonstige1.Location = new System.Drawing.Point(477, 109);
            this.tbx_sonstige1.Name = "tbx_sonstige1";
            this.tbx_sonstige1.Size = new System.Drawing.Size(121, 20);
            this.tbx_sonstige1.TabIndex = 129;
            // 
            // tbx_abnahme_dat
            // 
            this.tbx_abnahme_dat.Location = new System.Drawing.Point(262, 191);
            this.tbx_abnahme_dat.Name = "tbx_abnahme_dat";
            this.tbx_abnahme_dat.Size = new System.Drawing.Size(121, 20);
            this.tbx_abnahme_dat.TabIndex = 128;
            // 
            // tbx_bemerkung
            // 
            this.tbx_bemerkung.Location = new System.Drawing.Point(262, 338);
            this.tbx_bemerkung.Name = "tbx_bemerkung";
            this.tbx_bemerkung.Size = new System.Drawing.Size(121, 20);
            this.tbx_bemerkung.TabIndex = 127;
            // 
            // tbx_chargeid
            // 
            this.tbx_chargeid.Location = new System.Drawing.Point(262, 269);
            this.tbx_chargeid.Name = "tbx_chargeid";
            this.tbx_chargeid.Size = new System.Drawing.Size(121, 20);
            this.tbx_chargeid.TabIndex = 126;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(259, 234);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(113, 20);
            this.label10.TabIndex = 125;
            this.label10.Text = "P_charge_id";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(259, 308);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(122, 20);
            this.label9.TabIndex = 124;
            this.label9.Text = "P_bemerkung";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(475, 148);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(112, 20);
            this.label8.TabIndex = 123;
            this.label8.Text = "P_sonstige2";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(258, 89);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(207, 20);
            this.label7.TabIndex = 122;
            this.label7.Text = "P_fertigstellung_zeit_id";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(259, 162);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(142, 20);
            this.label6.TabIndex = 121;
            this.label6.Text = "P_abnahme_dat";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(474, 76);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(112, 20);
            this.label5.TabIndex = 120;
            this.label5.Text = "P_sonstige1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(27, 307);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(177, 20);
            this.label4.TabIndex = 119;
            this.label4.Text = "P_fertigstellung_dat";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(28, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 20);
            this.label3.TabIndex = 118;
            this.label3.Text = "Prob_id";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(28, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 20);
            this.label2.TabIndex = 117;
            this.label2.Text = "P_id";
            // 
            // lbl_abnahmeid
            // 
            this.lbl_abnahmeid.AutoSize = true;
            this.lbl_abnahmeid.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_abnahmeid.Location = new System.Drawing.Point(655, 164);
            this.lbl_abnahmeid.Name = "lbl_abnahmeid";
            this.lbl_abnahmeid.Size = new System.Drawing.Size(130, 17);
            this.lbl_abnahmeid.TabIndex = 156;
            this.lbl_abnahmeid.Text = "Tragen sie was ein!";
            this.lbl_abnahmeid.Visible = false;
            // 
            // tbx_abnahme_id
            // 
            this.tbx_abnahme_id.Location = new System.Drawing.Point(658, 178);
            this.tbx_abnahme_id.Name = "tbx_abnahme_id";
            this.tbx_abnahme_id.Size = new System.Drawing.Size(121, 20);
            this.tbx_abnahme_id.TabIndex = 155;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(655, 148);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(111, 20);
            this.label15.TabIndex = 154;
            this.label15.Text = "Abnahme_id";
            // 
            // lbl_eingang
            // 
            this.lbl_eingang.AutoSize = true;
            this.lbl_eingang.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_eingang.Location = new System.Drawing.Point(27, 252);
            this.lbl_eingang.Name = "lbl_eingang";
            this.lbl_eingang.Size = new System.Drawing.Size(130, 17);
            this.lbl_eingang.TabIndex = 159;
            this.lbl_eingang.Text = "Tragen sie was ein!";
            this.lbl_eingang.Visible = false;
            // 
            // tbx_eingang
            // 
            this.tbx_eingang.Location = new System.Drawing.Point(30, 266);
            this.tbx_eingang.Name = "tbx_eingang";
            this.tbx_eingang.Size = new System.Drawing.Size(121, 20);
            this.tbx_eingang.TabIndex = 158;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(27, 236);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(96, 20);
            this.label17.TabIndex = 157;
            this.label17.Text = "P_eingang";
            // 
            // cbx_abnahme_id
            // 
            this.cbx_abnahme_id.FormattingEnabled = true;
            this.cbx_abnahme_id.Location = new System.Drawing.Point(657, 204);
            this.cbx_abnahme_id.Name = "cbx_abnahme_id";
            this.cbx_abnahme_id.Size = new System.Drawing.Size(121, 21);
            this.cbx_abnahme_id.TabIndex = 160;
            // 
            // cbx_fertzeitid
            // 
            this.cbx_fertzeitid.FormattingEnabled = true;
            this.cbx_fertzeitid.Location = new System.Drawing.Point(262, 129);
            this.cbx_fertzeitid.Name = "cbx_fertzeitid";
            this.cbx_fertzeitid.Size = new System.Drawing.Size(121, 21);
            this.cbx_fertzeitid.TabIndex = 161;
            // 
            // cbx_prob
            // 
            this.cbx_prob.FormattingEnabled = true;
            this.cbx_prob.Location = new System.Drawing.Point(32, 190);
            this.cbx_prob.Name = "cbx_prob";
            this.cbx_prob.Size = new System.Drawing.Size(121, 21);
            this.cbx_prob.TabIndex = 162;
            // 
            // hinzufügenarbeitskartekopf
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(855, 427);
            this.Controls.Add(this.cbx_prob);
            this.Controls.Add(this.cbx_fertzeitid);
            this.Controls.Add(this.cbx_abnahme_id);
            this.Controls.Add(this.lbl_eingang);
            this.Controls.Add(this.tbx_eingang);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.lbl_abnahmeid);
            this.Controls.Add(this.tbx_abnahme_id);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.lbl_abgeschlossen);
            this.Controls.Add(this.tbx_abgeschlossen);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.lbl_sonstige3);
            this.Controls.Add(this.tbx_sonstige3);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.lbl_anzahl);
            this.Controls.Add(this.tbx_anzahl);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.lbl_sonstige2);
            this.Controls.Add(this.lbl_abnahmedat);
            this.Controls.Add(this.lbl_charge);
            this.Controls.Add(this.lbl_sonstige1);
            this.Controls.Add(this.lbl_bemerkung);
            this.Controls.Add(this.lbl_fertzeitid);
            this.Controls.Add(this.lbl_fertdatum);
            this.Controls.Add(this.lbl_prob);
            this.Controls.Add(this.lbl_fehlermeldung);
            this.Controls.Add(this.btn_anzeigen);
            this.Controls.Add(this.tbx_pid);
            this.Controls.Add(this.tbx_fertdat);
            this.Controls.Add(this.tbx_sonstige2);
            this.Controls.Add(this.tbx_sonstige1);
            this.Controls.Add(this.tbx_abnahme_dat);
            this.Controls.Add(this.tbx_bemerkung);
            this.Controls.Add(this.tbx_chargeid);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Name = "hinzufügenarbeitskartekopf";
            this.Text = "hinzufügenarbeitskartekopf";
            this.Load += new System.EventHandler(this.hinzufügenarbeitskartekopf_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_abgeschlossen;
        private System.Windows.Forms.TextBox tbx_abgeschlossen;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lbl_sonstige3;
        private System.Windows.Forms.TextBox tbx_sonstige3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lbl_anzahl;
        private System.Windows.Forms.TextBox tbx_anzahl;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lbl_sonstige2;
        private System.Windows.Forms.Label lbl_abnahmedat;
        private System.Windows.Forms.Label lbl_charge;
        private System.Windows.Forms.Label lbl_sonstige1;
        private System.Windows.Forms.Label lbl_bemerkung;
        private System.Windows.Forms.Label lbl_fertzeitid;
        private System.Windows.Forms.Label lbl_fertdatum;
        private System.Windows.Forms.Label lbl_prob;
        private System.Windows.Forms.Label lbl_fehlermeldung;
        private System.Windows.Forms.Button btn_anzeigen;
        private System.Windows.Forms.TextBox tbx_pid;
        private System.Windows.Forms.TextBox tbx_fertdat;
        private System.Windows.Forms.TextBox tbx_sonstige2;
        private System.Windows.Forms.TextBox tbx_sonstige1;
        private System.Windows.Forms.TextBox tbx_abnahme_dat;
        private System.Windows.Forms.TextBox tbx_bemerkung;
        private System.Windows.Forms.TextBox tbx_chargeid;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_abnahmeid;
        private System.Windows.Forms.TextBox tbx_abnahme_id;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lbl_eingang;
        private System.Windows.Forms.TextBox tbx_eingang;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox cbx_abnahme_id;
        private System.Windows.Forms.ComboBox cbx_fertzeitid;
        private System.Windows.Forms.ComboBox cbx_prob;
    }
}