﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH
{
    public partial class Bearbeitenangebot : Form
    {
        OleDbCommand cmd = null;


        private readonly string connectionString;
        private readonly OleDbConnection con = new OleDbConnection();
        private DataGridViewRow selectedRow;

        public DataGridViewRow UpdatedRow { get; private set; }
        public Bearbeitenangebot(DataGridViewRow selectedRow, string connectionString)
        {
            InitializeComponent();
            this.selectedRow = selectedRow;
            this.connectionString = connectionString;
        }

        private void Bearbeitenangebot_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = connectionString;
                con.Open();

                // Hier rufe ich eine Methode auf, um die Daten in den Textboxen anzuzeigen
                AnzeigenDerDaten();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler: " + ex.Message);
            }
        }
        private void AnzeigenDerDaten()
        {
            try
            {
               
                tbx_id.Text = selectedRow.Cells["Ang_id"].Value.ToString();
                tbx_pe_typ_id.Text = selectedRow.Cells["Pe_typ_id"].Value.ToString();
                tbx_preis.Text = selectedRow.Cells["Rp_preis"].Value.ToString();
                tbx_menge.Text = selectedRow.Cells["Menge"].Value.ToString();
                kommentar.Text = selectedRow.Cells["Kommentar"].Value.ToString();
              
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler beim Anzeigen der Daten: " + ex.Message);
            }
        }

        private void BearbeitungAbschließen()
        {
            try
            {
                // Überprüfe, ob alle Textboxen ausgefüllt sind
                if (string.IsNullOrEmpty(tbx_pe_typ_id.Text) || string.IsNullOrEmpty(tbx_preis.Text) || string.IsNullOrEmpty(tbx_menge.Text) || string.IsNullOrEmpty(kommentar.Text) || string.IsNullOrEmpty(tbx_id.Text))
                {
                    // Zeige eine Meldung an, dass alle Felder ausgefüllt werden müssen
                    MessageBox.Show("Bitte füllen Sie alle Felder aus.", "Fehlende Informationen", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    // Führe das Update nur aus, wenn alle Felder ausgefüllt sind
                    cmd = new OleDbCommand("UPDATE Angebotposition SET Pe_typ_id='" + Convert.ToInt32(tbx_pe_typ_id.Text) + "', Rp_preis=" + Convert.ToInt32(tbx_preis.Text) + ", Menge='" + Convert.ToInt32(tbx_menge.Text) + "',Kommentar='" + kommentar.Text + "' WHERE Ang_id=" + tbx_id.Text, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Erfolgreich bearbeitet!");

                    // Setze UpdatedRow auf die aktualisierte Zeile
                    UpdatedRow = selectedRow;

                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                meldung();
            }

        }
        public void meldung()
        {
            try
            {


                List<string> numericFieldsKunden = new List<string>();

            
                if (!int.TryParse(tbx_id.Text, out _)) numericFieldsKunden.Add("Ang_id");
                if (!int.TryParse(tbx_preis.Text, out _)) numericFieldsKunden.Add("Rp_preis");
                if (!int.TryParse(tbx_menge.Text, out _)) numericFieldsKunden.Add("Menge");
                if (!int.TryParse(tbx_pe_typ_id.Text, out _)) numericFieldsKunden.Add("Pe_typ_id");

               
                if (numericFieldsKunden.Any())
                {
                    MessageBox.Show($"Bitte geben Sie numerische Werte für die folgenden Felder ein: {string.Join(", ", numericFieldsKunden)}");
                    return; 
                }

                if (string.IsNullOrWhiteSpace(tbx_id.Text)
                    || string.IsNullOrWhiteSpace(tbx_pe_typ_id.Text)
                    || string.IsNullOrWhiteSpace(tbx_preis.Text)
                    || string.IsNullOrWhiteSpace(tbx_menge.Text)
                    || string.IsNullOrWhiteSpace(kommentar.Text))
                {

                    MessageBox.Show("Bitte füllen Sie alle erforderlichen Felder aus.");
                    return; 
                }

                MessageBox.Show("Erfolgreich");
            }
            catch (Exception a)
            {
                MessageBox.Show("Ein Fehler ist aufgetreten: " + a.Message);
            }



        }

        private void button1_Click(object sender, EventArgs e)
        {
            BearbeitungAbschließen();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
