﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace kunzecordingsSTARGMBH {
    public partial class Ansprechspartnerhiinzufügen : Form {
        private string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Kunze.accdb;";
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;
        public Ansprechspartnerhiinzufügen() {
            InitializeComponent();
        }

        private void Ansprechspartnerhiinzufügen_Load(object sender, EventArgs e) {
            LoadData();
        }
        private void LoadData() {
            using (OleDbConnection connection = new OleDbConnection(connectionString)) {
                connection.Open();
                string query = "SELECT Anspr_id, Anspr_vname, Anspr_nname, Anspr_tel, Anspr_email, Anspr_position FROM Ansprechspartner";

                using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection)) {
                    dataSet = new DataSet();
                    adapter.Fill(dataSet, "DeineTabelle");
                    dghinzufügen.DataSource = dataSet.Tables["DeineTabelle"];
                }
            }
                dghinzufügen.Columns["Anspr_id"].HeaderText = "Nummer";
                dghinzufügen.Columns["Anspr_vname"].HeaderText = "Vorname";
                dghinzufügen.Columns["Anspr_nname"].HeaderText = "Nachname";
                dghinzufügen.Columns["Anspr_tel"].HeaderText = "Telefon";
                dghinzufügen.Columns["Anspr_email"].HeaderText = "Email";
                dghinzufügen.Columns["Anspr_position"].HeaderText = "Position";
        }

        private void dghinzufügen_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            if (e.RowIndex >= 0) {
                // Hier bekommst du den ausgewählten Mitarbeiter
                DataGridViewRow selectedRow = dghinzufügen.Rows[e.RowIndex];

                // Öffne ein Formular zum Bearbeiten mit den Daten der ausgewählten Zeile
                hinzufügenansprechspartner bearbeitenForm = new hinzufügenansprechspartner(selectedRow);
                DialogResult result = bearbeitenForm.ShowDialog();

                // Wenn die Bearbeitung abgeschlossen ist, lade die aktualisierten Daten
                if (result == DialogResult.OK) {
                    LoadData();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
